#!/usr/bin/env python3
"""Roblox 2012 assets -> PS2 data.  usage: convert_roblox.py <'Roblox 2012 popular assets' dir> <project dir>"""
import sys, os, re, struct, math, subprocess, json, glob
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image, ImageDraw
R, P = sys.argv[1], sys.argv[2]
STUDIO = glob.glob(R + '/Roblox studio 2012/*/content')[0]
MAXPARTS = int(os.environ.get('MAXPARTS', 3500))
# ---------------- BrickColor palette (subset, original RGB values) ----------------
BC = {1:(242,243,243),2:(161,165,162),3:(249,233,153),5:(215,197,154),6:(194,218,184),9:(232,186,200),11:(128,187,219),12:(203,132,66),18:(204,142,105),21:(196,40,28),22:(196,112,160),23:(13,105,172),24:(245,205,48),25:(98,71,50),26:(27,42,53),27:(109,110,110),28:(40,127,71),29:(161,196,140),36:(163,162,165),37:(75,151,75),38:(160,95,53),39:(193,202,222),40:(236,236,236),41:(205,84,75),42:(193,223,240),43:(123,182,232),44:(247,241,141),45:(180,210,228),47:(217,133,108),48:(132,182,141),49:(248,241,132),50:(236,232,222),100:(238,196,182),101:(218,134,122),102:(110,153,202),103:(199,193,183),104:(107,50,124),105:(226,155,64),106:(218,133,65),107:(0,143,156),108:(104,92,67),110:(67,84,147),111:(191,183,177),112:(104,116,172),113:(228,173,200),115:(199,210,60),116:(85,165,175),118:(183,215,213),119:(164,189,71),120:(217,228,167),121:(231,172,103),123:(211,111,76),124:(146,57,120),125:(234,184,146),133:(213,115,61),135:(116,134,157),136:(135,124,144),140:(32,58,86),141:(39,70,45),143:(207,226,247),145:(121,136,161),146:(149,142,163),147:(147,135,103),148:(87,88,87),149:(22,29,50),150:(171,173,172),151:(120,144,130),153:(149,121,119),154:(123,46,47),157:(255,246,123),158:(225,164,194),168:(117,108,98),176:(151,105,91),178:(180,128,255),179:(137,135,136),180:(215,169,75),190:(249,214,46),191:(232,171,45),192:(105,64,40),193:(207,96,36),194:(163,162,165),195:(70,103,164),196:(35,71,139),198:(142,66,133),199:(99,95,98),200:(130,138,93),208:(229,228,223),209:(176,142,68),210:(112,149,120),211:(121,181,181),212:(159,195,233),213:(108,129,183),216:(143,76,42),217:(124,92,70),218:(150,112,159),219:(107,98,155),220:(167,169,206),221:(205,98,152),222:(228,173,200),223:(220,144,149),224:(240,213,160),225:(235,184,127),226:(253,234,140),232:(125,187,221),268:(52,43,117),301:(80,109,84),302:(91,93,105),303:(0,16,176),304:(44,101,29),305:(82,124,174),306:(51,88,130),307:(16,42,220),308:(61,21,133),309:(52,142,64),310:(91,154,76),311:(159,161,172),312:(89,34,89),313:(31,128,29),314:(159,173,192),315:(9,137,207),316:(123,0,123),317:(124,156,107),318:(138,171,133),319:(185,196,177),320:(202,203,209),321:(167,94,155),322:(123,47,123),323:(148,190,129),324:(168,189,153),325:(223,223,222),327:(151,0,0),328:(177,229,166),329:(152,194,219),330:(255,152,220),331:(255,89,89),332:(117,0,0),333:(239,184,56),334:(248,217,109),335:(231,231,236),336:(199,212,228),337:(255,148,148),338:(190,104,98),339:(86,36,36),340:(241,231,199),341:(254,243,187),342:(224,178,208),343:(212,144,189),344:(150,85,85),345:(143,76,42),346:(211,190,150),347:(226,220,188),348:(237,234,234),349:(233,218,218),350:(136,62,62),351:(188,155,93),352:(199,172,120),353:(202,191,163),354:(187,179,178),355:(108,88,75),356:(160,132,79),357:(149,137,136),358:(171,168,158),359:(175,148,131),360:(150,103,102),361:(86,66,54),362:(126,104,63),363:(105,102,92),364:(90,76,66),365:(106,57,9),1001:(248,248,248),1002:(205,205,205),1003:(17,17,17),1004:(255,0,0),1005:(255,176,0),1006:(180,128,255),1007:(163,75,75),1008:(193,190,66),1009:(255,255,0),1010:(0,0,255),1011:(0,32,96),1012:(33,84,185),1013:(4,175,236),1014:(170,85,0),1015:(170,0,170),1016:(255,102,204),1017:(255,175,0),1018:(18,238,212),1019:(0,255,255),1020:(0,255,0),1021:(58,125,21),1022:(127,142,100),1023:(140,91,159),1024:(175,221,255),1025:(255,201,201),1026:(177,167,255),1027:(159,243,233),1028:(204,255,102),1029:(255,255,204),1030:(255,204,153),1031:(98,37,209),1032:(255,0,191)}
KILLRE = re.compile(r'(kill|lava|lethal|death|deadly|poison|acid|spike|explod|fire|laser|trap)', re.I)
SHAPE = {'Part':1,'WedgePart':3,'CornerWedgePart':4,'TrussPart':1,'SpawnLocation':1,'Seat':1,'VehicleSeat':1,'FlagStand':1,'Platform':1,'SkateboardPlatform':1}
def fl(e,t,d=0.0):
    c=e.find(t); 
    try: return float(c.text)
    except Exception: return d
def parse_map(path):
    parts=[]; spawns=[]; scripts=[]; stack=[]
    try:
        for ev,el in ET.iterparse(path,events=('end',)):
            if el.tag!='Item': continue
            cls=el.get('class'); pr=el.find('Properties')
            if cls in ('Script','LocalScript') and pr is not None:
                nm=''; src=''
                for c in pr:
                    if c.get('name')=='Name': nm=c.text or ''
                    if c.get('name')=='Source': src=c.text or ''
                scripts.append((nm,len(src.splitlines())))
            if cls in SHAPE and pr is not None:
                cf=None; sz=None; bc=194; tr=0.0; cc=True; shp=None; name=''
                for c in pr:
                    n=c.get('name'); t=c.tag
                    if t=='CoordinateFrame' and n=='CFrame': cf=[fl(c,k) for k in ('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22')]
                    elif t=='Vector3' and n and n.lower()=='size': sz=[fl(c,'X',4),fl(c,'Y',1),fl(c,'Z',2)]
                    elif t=='int' and n=='BrickColor':
                        try: bc=int(c.text)
                        except Exception: pass
                    elif t=='float' and n=='Transparency': tr=float(c.text or 0)
                    elif t=='bool' and n=='CanCollide': cc=(c.text=='true')
                    elif t=='token' and n and n.lower()=='shape': shp=int(c.text or 1)
                    elif t=='string' and n=='Name': name=c.text or ''
                if cf and sz:
                    sh=SHAPE[cls]
                    if cls=='Part' and shp is not None: sh={0:0,1:1,2:2}.get(shp,1)
                    parts.append((cf,sz,bc,tr,cc,sh,name,cls))
                    if cls=='SpawnLocation': spawns.append(cf[:3])
                el.clear()
    except ET.ParseError as e:
        print('  parse error (partial):',e)
    return parts,spawns,scripts
def export(parts):
    # keep most important parts
    def imp(p): cf,sz,bc,tr,cc,sh,nm,cls=p; v=(abs(sz[0])*abs(sz[1])*abs(sz[2]))**(1/3.); return v*(0.1 if tr>0.9 else 1)+(5 if KILLRE.search(nm) else 0)
    parts=sorted(parts,key=imp,reverse=True)[:MAXPARTS]
    buf=b''
    for cf,sz,bc,tr,cc,sh,nm,cls in parts:
        rgb=BC.get(bc,(163,162,165)); rot=[int(max(-127,min(127,round(v*127)))) for v in cf[3:12]]
        half=[int(max(1,min(32767,round(abs(s)*0.5*4)))) for s in sz]   # half size in 1/4 stud
        flags=(1 if cc else 0)|(2 if tr>0.3 else 0)|(4 if KILLRE.search(nm) else 0)
        buf+=struct.pack('<3f3h9b3BBB',cf[0],cf[1],cf[2],*half,*rot,*rgb,sh,flags)
    return buf,parts
def thumb(parts,w=96,h=64):
    S=3; im=Image.new('RGB',(w*S,h*S),(135,190,235)); d=ImageDraw.Draw(im)
    if not parts: return im.resize((w,h),Image.LANCZOS)
    xs=[p[0][0] for p in parts]; zs=[p[0][2] for p in parts]; ys=[p[0][1] for p in parts]
    cx,cz=(np.percentile(xs,3)+np.percentile(xs,97))/2,(np.percentile(zs,3)+np.percentile(zs,97))/2
    ext=max(np.percentile(xs,97)-np.percentile(xs,3),np.percentile(zs,97)-np.percentile(zs,3),60); sc=min(w*S,h*S*1.5)/ext*0.8
    items=[]
    for cf,sz,bc,tr,cc,sh,nm,cls in parts:
        if tr>0.6: continue
        x,y,z=cf[0]-cx,cf[1],cf[2]-cz; u=(x-z*0.0)*sc+w*S/2; v=h*S*0.62-(z*0.55)*sc-y*sc*0.9
        a=abs(sz[0])*sc*0.5; b=abs(sz[2])*sc*0.28; hh=abs(sz[1])*sc*0.9
        items.append((z*0.5+y*0.01,u,v,a,b,hh,BC.get(bc,(163,162,165))))
    items.sort(key=lambda t:-t[0])
    for _,u,v,a,b,hh,c in items:
        if not(-50<u<w*S+50 and -50<v<h*S+50): continue
        top=tuple(min(255,int(k*1.1)) for k in c); side=tuple(int(k*0.8) for k in c)
        d.polygon([(u-a,v),(u+a,v),(u+a,v+hh),(u-a,v+hh)],fill=side)
        d.polygon([(u-a,v),(u+a,v),(u+a-b*0.4,v-b),(u-a-b*0.4,v-b)],fill=top)
    return im.resize((w,h),Image.LANCZOS)
# ---------------- maps ----------------
mapdir=R+'/maps'; mfiles=sorted(glob.glob(mapdir+'/*.rbxl')); maps=[]; blob=b''; thumbs=[]
for f in mfiles:
    base=os.path.basename(f)[:-5]; m=re.match(r'(\d{4}) (.*)',base); year,title=(m.group(1),m.group(2)) if m else ('2010',base)
    parts,spawns,scripts=parse_map(f); data,kept=export(parts)
    sp=spawns[0] if spawns else (0,10,0)
    if not spawns and kept:
        ys=[p[0][1] for p in kept]; sp=(kept[0][0][0],max(ys)+8,kept[0][0][2])
    maps.append(dict(year=int(year),title=title,total=len(parts),kept=len(kept),off=len(blob),spawn=list(sp),scripts=len(scripts),script_names=sorted(set(s[0] for s in scripts))[:8],script_lines=sum(s[1] for s in scripts)))
    blob+=data; thumbs.append(thumb(kept)); print(f'{base[:44]:44s} parts {len(parts):7d} kept {len(kept):5d} scripts {len(scripts):4d}',flush=True)
open(P+'/data/maps.bin','wb').write(blob); json.dump(maps,open(P+'/data/maps.json','w'),indent=1)
# ---------------- items (hats) ----------------
ITEMS=sorted(glob.glob(R+'/items/*.png')); items=[]
def split_camel(s): return re.sub(r'(?<=[a-z0-9])(?=[A-Z])',' ',s).strip()
def price(n):
    l=n.lower(); base=25
    for kw,p in (('crown',500),('top hat',150),('tophat',150),('teapot',200),('gold',250),('dominus',2000),('fedora',60),('viking',90),('helm',80),('mask',75),('pumpkin',45),('visor',100),('shades',40),('sombrero',70),('cap',20),('hard hat',30),('hardhat',30),('duck',60),('sword',80),('bolt',120),('fire',100),('arrow',50),('sparkle',150),('sapphire',300),('catseye',300),('frozen',350),('secret',400)):
        if kw in l: base=p; break
    return base
for f in ITEMS:
    n=os.path.basename(f)[:-4]; nm=split_camel(n); items.append(dict(file=n,name=nm,robux=price(nm)))
json.dump(items,open(P+'/data/items.json','w'),indent=1)
# ---------------- sprite packing (T8 + CLUT) ----------------
spr=[]   # (name, atlas, image, scale)
def add(n,a,im,sc=1.0): spr.append((n,a,im,sc))
add('CURSOR','ui',Image.open(STUDIO+'/textures/ArrowCursor.png').convert('RGBA'),1.0)
for i,f in enumerate(ITEMS):
    im=Image.open(f).convert('RGBA'); add(f'IT{i}','items',im.resize((56,56),Image.LANCZOS),1.0)
for i,t in enumerate(thumbs): add(f'MP{i}','maps',t.convert('RGBA'),1.0)
def load_dds_alpha(p):
    d=open(p,'rb').read(); h,w=struct.unpack('<II',d[12:20]); bits=struct.unpack('<I',d[88:92])[0]
    arr=np.frombuffer(d[128:128+w*h*(bits//8)],dtype=np.uint8)
    if bits==8: return Image.fromarray(arr.reshape(h,w),'L')
    if bits==16: return Image.fromarray(arr.reshape(h,w,2)[...,1],'L')
    return Image.fromarray(arr.reshape(h,w,bits//8)[...,-1],'L')
def font(prefix,tag):
    base=STUDIO+'/fonts/'+prefix; img=load_dds_alpha(base+'.dds'); W,H=img.size; n=0
    for ln in open(base+'.fontdef'):
        m=re.match(r'\s*glyph (\S+) ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)',ln)
        if not m: continue
        g=m.group(1); code=ord(g) if len(g)==1 else (int(g[1:]) if g.startswith('u') and g[1:].isdigit() else None)
        if code is None or not 32<=code<127: continue
        u0,v0,u1,v1=[float(m.group(i)) for i in range(2,6)]; box=(round(u0*W),round(v0*H),max(round(u1*W),round(u0*W)+1),max(round(v1*H),round(v0*H)+1))
        a=img.crop(box); im=Image.new('RGBA',a.size,(255,255,255,0)); im.putalpha(a); add(f'{tag}{code}','fnt',im,1.0); n+=1
    return n
nfa=font('Arial-18pt','FA'); nfb=font('ArialBold-18pt','FB'); print('font glyphs',nfa,nfb)
for code in (32,):
    for tag in ('FA','FB'):
        if not any(s[0]==f'{tag}{code}' for s in spr): add(f'{tag}{code}','fnt',Image.new('RGBA',(6,4),(0,0,0,0)),1.0)
atlas={'ui':(0,256),'items':(1,512),'maps':(2,512),'fnt':(3,512)}
def pack(items,width):
    x=y=rh=0; pos=[]
    for it in items:
        w,h=it.size; w+=2; h+=2
        if x+w>width: x=0; y+=rh; rh=0
        pos.append((x+1,y+1)); x+=w; rh=max(rh,h)
    H=8
    while H<y+rh: H*=2
    return pos,H
table=[]; heights={}
for an,(aid,width) in atlas.items():
    its=[s for s in spr if s[1]==an]; ims=[(im.resize((max(1,round(im.width*sc)),max(1,round(im.height*sc))),Image.LANCZOS) if sc!=1.0 else im,im.size) for _,_,im,sc in its]
    pos,H=pack([a for a,_ in ims],width); heights[an]=H; cv=Image.new('RGBA',(width,H),(0,0,0,0))
    for (im,_),(x,y) in zip(ims,pos): cv.paste(im,(x,y))
    q=cv.quantize(colors=255,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.NONE) if an!='fnt' else None
    if q is None:   # font: 1 colour + 8-bit alpha ramp
        a=np.asarray(cv)[...,3]; idx=(a//8).astype(np.uint8); clut=np.zeros((256,4),np.uint8)
        for i in range(32): clut[i]=(255,255,255,int(i*128/31))
    else:
        pal=np.array(q.getpalette('RGBA')[:255*4],dtype=np.uint8).reshape(-1,4); clut=np.zeros((256,4),np.uint8); clut[:len(pal)]=pal; clut[:,3]=(clut[:,3].astype(int)*128//255).astype(np.uint8)
        idx=np.asarray(q).astype(np.uint8); a=np.asarray(cv)[...,3]; idx=np.where(a<8,255,idx).astype(np.uint8); clut[255]=(0,0,0,0)
    sw=np.arange(256); sw=(sw&0xE7)|((sw&0x08)<<1)|((sw&0x10)>>1); cs=np.zeros_like(clut); cs[sw]=clut
    open(f'{P}/data/tex_{an}.bin','wb').write(cs.tobytes()+idx.tobytes())
    full=clut.copy(); full[:,3]=(clut[:,3].astype(int)*255//128).clip(0,255); Image.fromarray(full[idx],'RGBA').save(f'{P}/data/prev_{an}.png')
    for (n,_,_,_),(im,osz),(x,y) in zip(its,ims,pos): table.append((n,aid,x,y,im.width,im.height,osz[0],osz[1]))
    print(an,width,H,len(its),'sprites')
names=[t[0] for t in table]
open(P+'/src/assets.h','w').write('/* generated */\n#ifndef ASSETS_H\n#define ASSETS_H\ntypedef struct { unsigned char atlas; unsigned short x,y,w,h,ow,oh; } Spr;\nenum {\n'+''.join(f' S_{n},\n' for n in names)+' S_COUNT };\nextern const Spr SPR[S_COUNT];\n#define NATLAS 4\nextern const unsigned short ATLAS_W[NATLAS],ATLAS_H[NATLAS];\n#endif\n')
open(P+'/src/assets.c','w').write('#include "assets.h"\nconst Spr SPR[S_COUNT]={\n'+''.join('{%d,%d,%d,%d,%d,%d,%d},\n'%t[1:] for t in table)+'};\nconst unsigned short ATLAS_W[NATLAS]={256,512,512,512},ATLAS_H[NATLAS]={%s};\n'%','.join(str(heights[a]) for a in atlas))
json.dump({'names':names,'table':table},open(P+'/data/sprites.json','w'))
# catalog / map index headers
with open(P+'/src/catalog.c','w') as f:
    f.write('#include "catalog.h"\nconst CatItem CATALOG[NITEMS]={\n'+''.join('{"%s",%d,S_IT%d},\n'%(it['name'].replace('"',''),it['robux'],i) for i,it in enumerate(items))+'};\n')
    f.write('const MapInfo MAPS[NMAPS]={\n'+''.join('{"%s",%d,%d,%d,%d,{%.1ff,%.1ff,%.1ff},%d,S_MP%d},\n'%(m['title'].replace('"',"'").replace('\\',''),m['year'],m['kept'],m['off'],m['scripts'],m['spawn'][0],m['spawn'][1],m['spawn'][2],m['script_lines'],i) for i,m in enumerate(maps))+'};\n')
open(P+'/src/catalog.h','w').write('#ifndef CATALOG_H\n#define CATALOG_H\n#include "assets.h"\n#define NITEMS %d\n#define NMAPS %d\ntypedef struct { const char*name; int robux; int spr; } CatItem;\ntypedef struct { const char*title; int year, nparts, off, nscripts; float spawn[3]; int script_lines; int thumb; } MapInfo;\nextern const CatItem CATALOG[NITEMS]; extern const MapInfo MAPS[NMAPS];\n#endif\n'%(len(items),len(maps)))
# ---------------- sounds ----------------
SD=STUDIO+'/sounds/'; SOUNDS=[('CLICK','button.mp3'),('HIT','hit.mp3'),('COLLIDE','collide.mp3'),('OUCH','Kid saying Ouch.mp3'),('PING','electronicpingshort.mp3'),('SWITCH','SWITCH3.mp3'),('FLASH','flashbulb.mp3'),('STEP1','bfsl-minifigfoots1.mp3'),('STEP2','bfsl-minifigfoots2.mp3'),('GRASS','grass.mp3'),('KERPLUNK','Kerplunk.mp3'),('CLICKFAST','clickfast.mp3')]
blob=b''; tab=[]
for n,fn in SOUNDS:
    p=SD+fn
    if not os.path.exists(p): print('missing',fn); tab.append((n,len(blob)//2,0)); continue
    d=subprocess.run(['ffmpeg','-v','error','-i',p,'-ac','1','-ar','11025','-t','2.0','-f','s16le','-'],capture_output=True).stdout; tab.append((n,len(blob)//2,len(d)//2)); blob+=d
for n,fn in (('MUSIC','bass.wav'),):
    p=STUDIO+'/music/'+fn; d=subprocess.run(['ffmpeg','-v','error','-i',p,'-ac','1','-ar','11025','-t','30','-f','s16le','-'],capture_output=True).stdout; tab.append((n,len(blob)//2,len(d)//2)); blob+=d
open(P+'/data/audio.bin','wb').write(blob)
open(P+'/src/audio_tab.h','w').write('#ifndef AUDIO_TAB_H\n#define AUDIO_TAB_H\ntypedef struct { unsigned int off,len; } Snd;\nenum {\n'+''.join(f' A_{n},\n' for n,_,_ in tab)+' A_COUNT };\nextern const Snd SND[A_COUNT];\n#endif\n')
open(P+'/src/audio_tab.c','w').write('#include "audio_tab.h"\nconst Snd SND[A_COUNT]={\n'+''.join('{%d,%d},\n'%(o,l) for _,o,l in tab)+'};\n')
print('maps.bin %.2f MB, audio %.2f MB, items %d, maps %d'%(len(open(P+'/data/maps.bin','rb').read())/1e6,len(blob)/1e6,len(items),len(maps)))
