#!/usr/bin/env python3
"""Renders the host draw list using the exact PS2 atlases (quantized, smoothed) -> PNG frames. 3D triangles are depth-sorted (painter)."""
import sys, json, math, os
from PIL import Image, ImageDraw
import numpy as np
P, frames_txt, outdir = sys.argv[1:4]
tab=json.load(open(P+'/data/sprites.json'))['table']; AN=['ui','items','maps','fnt']; at=[Image.open(f'{P}/data/prev_{a}.png').convert('RGBA') for a in AN]; cache={}
def sprite(i):
    if i not in cache: n,a,x,y,w,h,ow,oh=tab[i]; cache[i]=at[a].crop((x,y,x+w,y+h))
    return cache[i]
fl=[];cur=None;pend=None
for ln in open(frames_txt):
    if ln.startswith('N '): pend=ln.split()[1]
    elif ln.startswith('F'): cur=[]; fl.append((pend,cur)); pend=None
    elif cur is not None: cur.append(ln.split())
S=2
def col(h): v=int(h,16); return ((v>>24)&255,(v>>16)&255,(v>>8)&255,v&255)
def render(cmds):
    cv=Image.new('RGBA',(640*S,448*S),(0,0,0,255)); vp=(0,0,640,448); buf=[]
    def flush():
        nonlocal buf
        if not buf: return
        buf.sort(key=lambda t:-t[0]); lay=Image.new('RGBA',cv.size,(0,0,0,0)); d=ImageDraw.Draw(lay)
        for _,pts,c in buf: d.polygon(pts,fill=c)
        box=tuple(int(v*S) for v in vp); m=Image.new('L',cv.size,0); ImageDraw.Draw(m).rectangle(box,fill=255); lay.putalpha(Image.fromarray(np.minimum(np.asarray(lay)[...,3],np.asarray(m))))
        cv.alpha_composite(lay); buf=[]
    for c in cmds:
        k=c[0]
        if k=='3':
            v=[float(x) for x in c[1:10]]; r,g,b,a=col(c[10]); buf.append(((v[2]+v[5]+v[8])/3,[(v[0]*S,v[1]*S),(v[3]*S,v[4]*S),(v[6]*S,v[7]*S)],(r,g,b,255))); continue
        flush()
        if k=='V': vp=tuple(float(x) for x in c[1:5])
        elif k=='R':
            x0,y0,x1,y1=[float(v)*S for v in c[1:5]]; r,g,b,a=col(c[5])
            if x1>x0 and y1>y0:
                ov=Image.new('RGBA',(max(1,int(x1-x0)),max(1,int(y1-y0))),(r,g,b,a)); box=(int(x0),int(y0))
                if a==255: cv.paste(ov,box)
                else:
                    reg=cv.crop((box[0],box[1],box[0]+ov.width,box[1]+ov.height)); cv.paste(Image.alpha_composite(reg,ov),box)
        elif k=='T':
            p=[float(v)*S for v in c[1:7]]; r,g,b,a=col(c[7]); ov=Image.new('RGBA',cv.size,(0,0,0,0)); ImageDraw.Draw(ov).polygon([(p[0],p[1]),(p[2],p[3]),(p[4],p[5])],fill=(r,g,b,a)); cv.alpha_composite(ov)
        elif k=='S':
            i=int(c[1]); cx,cy,w,h,rot=[float(v) for v in c[2:7]]; r,g,b,a=col(c[7]); w*=S;h*=S;cx*=S;cy*=S
            if w<1 or h<1: continue
            im=sprite(i).resize((max(1,int(round(w))),max(1,int(round(h)))),Image.LANCZOS)
            if (r,g,b,a)!=(255,255,255,255):
                arr=np.asarray(im).astype(float); arr[...,0]*=r/255; arr[...,1]*=g/255; arr[...,2]*=b/255; arr[...,3]*=a/255; im=Image.fromarray(arr.astype(np.uint8),'RGBA')
            if abs(rot)>1e-3: im=im.rotate(-math.degrees(rot),resample=Image.BICUBIC,expand=True)
            cv.alpha_composite(im.convert('RGBA'),(0,0)) if False else cv.paste(im,(int(round(cx-im.width/2)),int(round(cy-im.height/2))),im)
    flush(); return cv.resize((640,448),Image.LANCZOS).convert('RGB')
os.makedirs(outdir,exist_ok=True)
for n,cmds in fl:
    if n: render(cmds).save(f'{outdir}/{n}.png'); print('rendered',n,len(cmds),flush=True)
