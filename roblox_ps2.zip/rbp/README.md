# ROBLOX 2012 - PlayStation 2 fan port (milestone 1)
Native EE homebrew (C + PS2SDK + gsKit + audsrv). 56 places converted from the original .rbxl files (geometry), 65 hats, website UI, accounts, economy, split-screen 1-4, bots 1-30.
Build:  docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest sh -c "apk add make && make"  -> ROBLOX.ELF   (or push to GitHub, see .github/workflows/build.yml)
Run: PCSX2 (System > Run ELF) / uLaunchELF / PS2Link.  Save: memory card slot 1, folder ROBLOXPS2.
Controls: L stick walk (menus: mouse cursor), R stick camera, X jump/click, O use item, START pause (Port Options: remap, Robux-Tix, music),
Square Safe Chat, Triangle camera zoom, L1/L2 R1/R2 rotate inventory. 2-4 players: each uses own pad (ports 1/2 + multitap).
Rebuild data: python3 tools/convert_roblox.py "<Roblox 2012 popular assets>" .     Host tests: see src/host3d.c, src/host_main.c
All Roblox content belongs to Roblox Corporation. Keep this repository private.
