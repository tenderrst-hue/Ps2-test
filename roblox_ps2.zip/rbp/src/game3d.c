/* Roblox 2012 PS2 port - 3D world: maps from .rbxl, characters, bots, collision, split-screen renderer */
#include "game3d.h"
#include "gfx.h"
#include "catalog.h"
#include "audio_tab.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
const unsigned char*maps_data;
extern const unsigned char ITEMCOL[][3];
#define GRAV 196.2f
#define WALK 16.f
#define JUMPV 53.f
static unsigned rnd(Game3D*g){ g->rng=g->rng*1664525u+1013904223u; return g->rng>>8; }
static float frnd(Game3D*g){ return (rnd(g)&0xFFFF)/65535.f; }
static void sfx(Game3D*g,int s){ if(g->nsfx<8) g->sfx[g->nsfx++]=s; }
int g3_is_battle(const char*t){ static const char*k[]={"sword","war","brawl","fight","zombie","doomspire","dog","wizard","pokemon","base","hide","freeze","mcdonald",0}; char l[64]; int i=0; for(;t[i]&&i<63;i++) l[i]=tolower((unsigned char)t[i]); l[i]=0; for(int j=0;k[j];j++) if(strstr(l,k[j])) return 1; return 0; }
void g3_viewport(int np,int i,float*x0,float*y0,float*x1,float*y1){
  if(np<=1){*x0=0;*y0=0;*x1=640;*y1=448;return;}
  if(np==2){*x0=0;*x1=640;*y0=i?224:0;*y1=i?448:224;return;}
  if(np==3){ if(i==0){*x0=0;*x1=640;*y0=0;*y1=224;} else {*x0=(i==1)?0:320;*x1=(i==1)?320:640;*y0=224;*y1=448;} return; }
  *x0=(i&1)?320:0; *x1=(i&1)?640:320; *y0=(i>>1)?224:0; *y1=(i>>1)?448:224; }
/* ---------------- map + spatial grid ---------------- */
static void part_aabb(const PartRec*p,float*lo,float*hi){ float h[3]={p->h[0]*0.25f,p->h[1]*0.25f,p->h[2]*0.25f}; for(int a=0;a<3;a++){ float e=fabsf(p->r[a*3]/127.f)*h[0]+fabsf(p->r[a*3+1]/127.f)*h[1]+fabsf(p->r[a*3+2]/127.f)*h[2]; float c=a==0?p->x:a==1?p->y:p->z; lo[a]=c-e; hi[a]=c+e; } }
static float find_ground(const Map3D*m,float x,float z,float y0){ /* highest collidable surface at/below y0+40, or -1e9 */
  float best=-1e9f; int cx=(int)((x-m->bmin[0])/m->cell),cz=(int)((z-m->bmin[2])/m->cell); int cand[512],nc=0; for(int b=0;b<m->nbig&&nc<512;b++) cand[nc++]=m->big[b];
  if(cx>=0&&cz>=0&&cx<m->gw&&cz<m->gh){ int c=cz*m->gw+cx; for(int k=m->cstart[c];k<m->cstart[c+1]&&nc<512;k++) cand[nc++]=m->cidx[k]; }
  for(int k=0;k<nc;k++){ const PartRec*p=&m->parts[cand[k]]; if(!(p->flags&1)||(p->flags&4)) continue; float lo[3],hi[3]; part_aabb(p,lo,hi); if(x<lo[0]||x>hi[0]||z<lo[2]||z>hi[2]) continue; if(hi[1]<=y0+40&&hi[1]>best) best=hi[1]; } return best; }
void g3_unload(Game3D*g){ if(g->m.cstart){ free(g->m.cstart); free(g->m.cidx); free(g->m.big); } g->m.cstart=0; g->m.cidx=0; g->m.big=0; }
void g3_load(Game3D*g,int map,int np,int nb){
  memset(g,0,sizeof*g); g->rng=777+map*13; Map3D*m=&g->m; m->map=map; m->n=MAPS[map].nparts; m->parts=(const PartRec*)(maps_data+MAPS[map].off);
  static const PartRec BASEPLATE[1]={{0,-0.5f,0,{1024,2,1024},{127,0,0,0,127,0,0,0,127},{75,151,75},1,1}}; if(m->n==0){ m->parts=BASEPLATE; m->n=1; } g->np=np; g->nb=nb; g->battle=g3_is_battle(MAPS[map].title);
  float lo[3]={1e9f,1e9f,1e9f},hi[3]={-1e9f,-1e9f,-1e9f}; for(int i=0;i<m->n;i++){ float a[3],b[3]; part_aabb(&m->parts[i],a,b); for(int k=0;k<3;k++){ if(a[k]<lo[k])lo[k]=a[k]; if(b[k]>hi[k])hi[k]=b[k]; } }
  if(m->n==0){ lo[0]=lo[1]=lo[2]=-50; hi[0]=hi[1]=hi[2]=50; }
  memcpy(m->bmin,lo,12); memcpy(m->bmax,hi,12); float ex=fmaxf(hi[0]-lo[0],hi[2]-lo[2]); m->cell=fmaxf(24.f,ex/96.f); m->gw=(int)((hi[0]-lo[0])/m->cell)+1; m->gh=(int)((hi[2]-lo[2])/m->cell)+1; if(m->gw>128)m->gw=128; if(m->gh>128)m->gh=128;
  int nc=m->gw*m->gh; int*cnt=calloc(nc+1,sizeof(int)); m->big=malloc(sizeof(int)*(m->n+1)); m->nbig=0;
  for(int pass=0;pass<2;pass++){ int*fill=calloc(nc,sizeof(int)); for(int i=0;i<m->n;i++){ const PartRec*p=&m->parts[i]; if(!(p->flags&1)&&!(p->flags&4)) continue; float a[3],b[3]; part_aabb(p,a,b);
      int x0=(int)((a[0]-lo[0])/m->cell),x1=(int)((b[0]-lo[0])/m->cell),z0=(int)((a[2]-lo[2])/m->cell),z1=(int)((b[2]-lo[2])/m->cell); if(x0<0)x0=0; if(z0<0)z0=0; if(x1>=m->gw)x1=m->gw-1; if(z1>=m->gh)z1=m->gh-1;
      if((x1-x0+1)*(z1-z0+1)>90){ if(pass==0) m->big[m->nbig++]=i; continue; }
      for(int z=z0;z<=z1;z++) for(int x=x0;x<=x1;x++){ int c=z*m->gw+x; if(pass==0) cnt[c+1]++; else m->cidx[m->cstart[c]+fill[c]++]=i; } }
    if(pass==0){ for(int c=0;c<nc;c++) cnt[c+1]+=cnt[c]; m->cstart=cnt; m->cidx=malloc(sizeof(int)*(cnt[nc]+1)); } free(fill); }
  memcpy(m->spawn,MAPS[map].spawn,12); if(MAPS[map].nparts==0){ m->spawn[0]=0; m->spawn[1]=2; m->spawn[2]=0; } if(m->spawn[1]<lo[1]+2) m->spawn[1]=lo[1]+10; m->spawn[1]+=3;
  { float gy=find_ground(m,m->spawn[0],m->spawn[2],m->spawn[1]); if(gy>-1e8f) m->spawn[1]=gy+3.5f; }
  for(int i=0;i<np;i++){ Player*p=&g->p[i]; p->c.x=m->spawn[0]+i*3; p->c.y=m->spawn[1]; p->c.z=m->spawn[2]; p->c.alive=1; p->c.hp=100; p->cdist=14; p->cpitch=0.35f; p->ntool=3; p->c.hat=-1;
    static const unsigned char cols[4][4][3]={{{245,205,47},{13,105,172},{245,205,47},{75,151,75}},{{245,205,47},{196,40,27},{245,205,47},{27,42,53}},{{245,205,47},{75,151,75},{245,205,47},{13,105,172}},{{245,205,47},{218,133,65},{245,205,47},{107,50,124}}}; memcpy(p->c.col,cols[i],12); }
  for(int i=0;i<nb;i++){ Bot*b=&g->b[i]; { float rad=8+sqrtf((float)nb)*7; for(int tr=0;tr<8;tr++){ b->c.x=m->spawn[0]+(frnd(g)-0.5f)*2*rad; b->c.z=m->spawn[2]+(frnd(g)-0.5f)*2*rad; float gy=find_ground(m,b->c.x,b->c.z,m->spawn[1]); if(gy>-1e8f&&fabsf(gy-(m->spawn[1]-3.5f))<30){ b->c.y=gy+3.5f; break; } b->c.x=m->spawn[0]+(i%5)*2; b->c.z=m->spawn[2]+(i/5)*2; b->c.y=m->spawn[1]; } } b->c.alive=1; b->c.hp=100; b->c.hat=(int)(rnd(g)%(NITEMS*2))-NITEMS; b->c.yaw=frnd(g)*6.28f;
    for(int k=0;k<4;k++) for(int j=0;j<3;j++) b->c.col[k][j]=k==0?(unsigned char)(200+rnd(g)%55):(unsigned char)(40+rnd(g)%200); b->mode=0; b->tx=b->c.x; b->tz=b->c.z; } }
/* ---------------- collision (spheres vs oriented boxes) ---------------- */
static int sphere_part(const PartRec*p,float*cx,float*cy,float*cz,float r,float*ny){
  float d[3]={*cx-p->x,*cy-p->y,*cz-p->z}; float l[3]; for(int j=0;j<3;j++) l[j]=(p->r[j]*d[0]+p->r[3+j]*d[1]+p->r[6+j]*d[2])/127.f;   /* R^T d  (R rows stored r00 r01 r02 / r10..): columns = local axes */
  float h[3]={p->h[0]*0.25f,p->h[1]*0.25f,p->h[2]*0.25f}; float q[3],df[3]; float d2=0; int inside=1;
  for(int j=0;j<3;j++){ q[j]=l[j]<-h[j]?-h[j]:(l[j]>h[j]?h[j]:l[j]); df[j]=l[j]-q[j]; d2+=df[j]*df[j]; if(df[j]!=0) inside=0; }
  if(p->shape==0){ float s=h[0]; float len=sqrtf(l[0]*l[0]+l[1]*l[1]+l[2]*l[2]); if(len>=s+r) return 0; float pen=s+r-len; if(len<1e-4f){ *cy+=pen; *ny=1; return 1; } float n[3]={l[0]/len,l[1]/len,l[2]/len}; float w[3]; for(int a=0;a<3;a++) w[a]=(p->r[a*3]*n[0]+p->r[a*3+1]*n[1]+p->r[a*3+2]*n[2])/127.f; *cx+=w[0]*pen; *cy+=w[1]*pen; *cz+=w[2]*pen; *ny=w[1]; return 1; }
  if(p->shape==3||p->shape==4){ /* wedge: slope plane from top-back to bottom-front; treat via box but lower the front-top half */ if(l[1]>h[1]*(l[2]/(h[2]+0.001f))*(-1)+0.0f && l[2]>0 && q[1]>-h[1]) { /* above slope: reduce box height linearly */ float top=h[1]-(l[2]+h[2])*(h[1]*2)/(h[2]*2+0.001f)*0.0f; (void)top; } }
  float n[3]; float pen;
  if(inside){ float m=1e9f; int ax=1; float sg=1; for(int j=0;j<3;j++){ float a=h[j]-l[j],b=l[j]+h[j]; if(a<m){m=a;ax=j;sg=1;} if(b<m){m=b;ax=j;sg=-1;} } n[0]=n[1]=n[2]=0; n[ax]=sg; pen=m+r; }
  else { float dist=sqrtf(d2); if(dist>=r) return 0; for(int j=0;j<3;j++) n[j]=df[j]/dist; pen=r-dist; }
  float w[3]; for(int a=0;a<3;a++) w[a]=(p->r[a*3]*n[0]+p->r[a*3+1]*n[1]+p->r[a*3+2]*n[2])/127.f; *cx+=w[0]*pen; *cy+=w[1]*pen; *cz+=w[2]*pen; *ny=w[1]; return 1; }
static int collide_char(Game3D*g,Char*c,int*killed){
  Map3D*m=&g->m; int grounded=0; static const float hy[3]={0.95f,2.2f,3.5f}; float rad=0.95f; *killed=0;
  for(int it=0;it<3;it++) for(int s=0;s<3;s++){ float cx=c->x,cy=c->y+hy[s],cz=c->z;
    int x=(int)((cx-m->bmin[0])/m->cell),z=(int)((cz-m->bmin[2])/m->cell); int cand[256]; int nc=0;
    for(int b=0;b<m->nbig&&nc<256;b++) cand[nc++]=m->big[b];
    if(x>=0&&z>=0&&x<m->gw&&z<m->gh){ int cc=z*m->gw+x; for(int k=m->cstart[cc];k<m->cstart[cc+1]&&nc<256;k++) cand[nc++]=m->cidx[k]; }
    for(int k=0;k<nc;k++){ const PartRec*p=&m->parts[cand[k]]; float ny=0; float ox=cx,oy=cy,oz=cz; if(sphere_part(p,&cx,&cy,&cz,rad,&ny)){ if(p->flags&4){ *killed=1; } if(!(p->flags&1)){ cx=ox;cy=oy;cz=oz; continue; } if(ny>0.55f&&s==0) grounded=1; if(ny>0.55f&&c->vy<0) c->vy=0; if(ny<-0.5f&&c->vy>0) c->vy=0; } }
    c->x=cx; c->y=cy-hy[s]; c->z=cz; }
  return grounded; }
/* ---------------- simulation ---------------- */
static void respawn(Game3D*g,Char*c){ c->x=g->m.spawn[0]+(frnd(g)-0.5f)*8; c->y=g->m.spawn[1]+2; c->z=g->m.spawn[2]+(frnd(g)-0.5f)*8; c->vx=c->vy=c->vz=0; c->hp=100; c->alive=1; }
static void damage(Game3D*g,Char*c,float d,int plr){ if(!c->alive) return; c->hp-=d; c->hurt=0.25f; if(plr) sfx(g,A_OUCH); if(c->hp<=0){ c->alive=0; c->respawn=3.f; } }
static void move_char(Game3D*g,Char*c,float dx,float dz,int jump,float dt){
  float tx=dx*WALK,tz=dz*WALK; float a=1-expf(-12*dt); c->vx+=(tx-c->vx)*a; c->vz+=(tz-c->vz)*a; c->vy-=GRAV*dt; if(c->vy<-150)c->vy=-150;
  if(jump&&c->onground){ c->vy=JUMPV; c->onground=0; }
  c->x+=c->vx*dt; c->y+=c->vy*dt; c->z+=c->vz*dt; int killed; c->onground=collide_char(g,c,&killed); if(killed&&c->alive) damage(g,c,999,0);
  if(c->y<g->m.bmin[1]-120){ damage(g,c,999,0); }
  float sp=sqrtf(c->vx*c->vx+c->vz*c->vz); if(sp>1) c->yaw=atan2f(c->vx,c->vz); if(c->onground&&sp>1) c->anim+=sp*dt*0.55f; else if(!c->onground) c->anim=0.9f; if(c->hurt>0) c->hurt-=dt; }
static Char*nearest(Game3D*g,Char*me,float*bd){ Char*best=0; float b2=*bd**bd; for(int i=0;i<g->np;i++){ Char*o=&g->p[i].c; if(o==me||!o->alive) continue; float d=(o->x-me->x)*(o->x-me->x)+(o->z-me->z)*(o->z-me->z)+(o->y-me->y)*(o->y-me->y)*0.3f; if(d<b2){b2=d;best=o;} }
  for(int i=0;i<g->nb;i++){ Char*o=&g->b[i].c; if(o==me||!o->alive) continue; float d=(o->x-me->x)*(o->x-me->x)+(o->z-me->z)*(o->z-me->z)+(o->y-me->y)*(o->y-me->y)*0.3f; if(d<b2){b2=d;best=o;} } *bd=sqrtf(b2); return best; }
void g3_step(Game3D*g,const PlayerIn*in,float dt){
  g->nsfx=0; g->t+=dt;
  for(int i=0;i<g->np;i++){ Player*p=&g->p[i]; const PlayerIn*pi=&in[i]; Char*c=&p->c;
    p->cyaw+=pi->cam_x*2.6f*dt; p->cpitch+=pi->cam_y*1.6f*dt; if(p->cpitch<-0.2f)p->cpitch=-0.2f; if(p->cpitch>1.35f)p->cpitch=1.35f; p->cdist=pi->zoom; if(p->chat>0)p->chat-=dt;
    if(pi->toolL) p->tool=(p->tool+p->ntool-1)%p->ntool; if(pi->toolR) p->tool=(p->tool+1)%p->ntool;
    if(!c->alive){ c->respawn-=dt; if(c->respawn<=0){ respawn(g,c); p->deaths++; } continue; }
    float sY=sinf(p->cyaw),cY=cosf(p->cyaw),mx=pi->mx,my=pi->my; float dx=sY*my+cY*mx, dz=cY*my-sY*mx;   /* stick up (my<0) = away from camera */
    float l=sqrtf(dx*dx+dz*dz); if(l>1){dx/=l;dz/=l;} move_char(g,c,dx,dz,pi->jump,dt); if(pi->jump&&!c->onground&&c->vy>50) sfx(g,A_SWITCH);
    if(c->onground&&sqrtf(c->vx*c->vx+c->vz*c->vz)>8&&fmodf(c->anim,3.14159f)<0.12f) sfx(g,(i&1)?A_STEP2:A_STEP1);
    c->atk-=dt; if(pi->act&&c->atk<=0){ c->atk=0.5f; float bd=5.5f+(p->tool==1?35:0); Char*t=nearest(g,c,&bd); if(t){ damage(g,t,p->tool==0?18:(p->tool==1?9:0),0); if(p->tool==2&&c->hp<100) c->hp=fminf(100,c->hp+25); if(!t->alive) p->kills++; sfx(g,A_HIT); } else sfx(g,A_FLASH); }
    if(pi->safe>0&&pi->safe<=8){ static const char*S[8]={"HELLO!","GOOD GAME","THANKS","HELP!","FOLLOW ME","I WIN!","OOPS","BYE"}; strncpy(p->say,S[pi->safe-1],27); p->chat=3.f; } }
  for(int i=0;i<g->nb;i++){ Bot*b=&g->b[i]; Char*c=&b->c; if(!c->alive){ c->respawn-=dt; if(c->respawn<=0) respawn(g,c); continue; }
    b->think-=dt; float dx=0,dz=0; int jump=0;
    if(b->think<=0){ b->think=0.6f+frnd(g)*1.5f; float bd=g->battle?70.f:30.f; Char*t=g->battle?nearest(g,c,&bd):0;
      if(t){ b->mode=1; b->tx=t->x; b->tz=t->z; } else if(!g->battle&&(i&1)&&g->np){ b->mode=2; Char*pl=&g->p[i%g->np].c; b->tx=pl->x+(frnd(g)-0.5f)*10; b->tz=pl->z+(frnd(g)-0.5f)*10; }
      else { b->mode=0; b->tx=c->x+(frnd(g)-0.5f)*60; b->tz=c->z+(frnd(g)-0.5f)*60; } }
    float ex=b->tx-c->x,ez=b->tz-c->z,d=sqrtf(ex*ex+ez*ez); if(d>2.5f){ dx=ex/d*(b->mode==1?1:0.55f); dz=ez/d; dz*=(b->mode==1?1:0.55f); }
    float sp=sqrtf(c->vx*c->vx+c->vz*c->vz); if(d>3&&sp<2) b->stuck+=dt; else b->stuck=0; if(b->stuck>0.25f){ jump=1; if(b->stuck>1.f){ b->tx=c->x+(frnd(g)-0.5f)*40; b->tz=c->z+(frnd(g)-0.5f)*40; b->stuck=0; } }
    move_char(g,c,dx,dz,jump,dt); c->atk-=dt;
    if(b->mode==1&&c->atk<=0){ float bd=5.2f; Char*t=nearest(g,c,&bd); if(t){ c->atk=0.9f; damage(g,t,12,t>=&g->p[0].c&&t<=&g->p[MAXPL-1].c); sfx(g,A_HIT); } } }
}

/* ---------------- rendering ---------------- */
typedef struct { float x,y,z; } V3;
typedef struct { float px,py,pz; float r[3][3]; float f,cxs,cys; float x0,y0,x1,y1; } Cam;   /* r rows: right, up, forward */
static void make_cam(const Game3D*g,int pl,Cam*c,float x0,float y0,float x1,float y1){
  const Player*p=&g->p[pl]; float cp=cosf(p->cpitch),sp=sinf(p->cpitch),cy=cosf(p->cyaw),sy=sinf(p->cyaw); float tx=p->c.x,ty=p->c.y+3.2f,tz=p->c.z;
  c->px=tx+sy*cp*p->cdist; c->py=ty+sp*p->cdist; c->pz=tz+cy*cp*p->cdist; V3 f={tx-c->px,ty-c->py,tz-c->pz}; float l=sqrtf(f.x*f.x+f.y*f.y+f.z*f.z); f.x/=l;f.y/=l;f.z/=l;
  V3 r={-f.z,0,f.x}; float rl=sqrtf(r.x*r.x+r.z*r.z); r.x/=rl; r.z/=rl; V3 u={r.y*f.z-r.z*f.y, r.z*f.x-r.x*f.z, r.x*f.y-r.y*f.x};
  c->r[0][0]=r.x;c->r[0][1]=r.y;c->r[0][2]=r.z; c->r[1][0]=u.x;c->r[1][1]=u.y;c->r[1][2]=u.z; c->r[2][0]=f.x;c->r[2][1]=f.y;c->r[2][2]=f.z;
  c->x0=x0;c->y0=y0;c->x1=x1;c->y1=y1; c->f=(x1-x0)*0.5f/tanf(0.60f); c->cxs=(x0+x1)*0.5f; c->cys=(y0+y1)*0.5f; }
static V3 to_cam(const Cam*c,float x,float y,float z){ float dx=x-c->px,dy=y-c->py,dz=z-c->pz; V3 o={dx*c->r[0][0]+dy*c->r[0][1]+dz*c->r[0][2], dx*c->r[1][0]+dy*c->r[1][1]+dz*c->r[1][2], dx*c->r[2][0]+dy*c->r[2][1]+dz*c->r[2][2]}; return o; }
#define NEARZ 0.5f
#define FARZ 420.f
static int tri_budget;
static void poly(const Cam*c,const V3*v,int n,float sh,const unsigned char*rgb){
  V3 in[10],out[10]; int m=0; for(int i=0;i<n;i++) in[i]=v[i];
  for(int i=0;i<n;i++){ V3 a=in[i],b=in[(i+1)%n]; int ia=a.z>=NEARZ,ib=b.z>=NEARZ; if(ia) out[m++]=a; if(ia!=ib){ float t=(NEARZ-a.z)/(b.z-a.z); V3 q={a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,NEARZ}; out[m++]=q; } }
  if(m<3) return; float X[10],Y[10],Z[10]; for(int i=0;i<m;i++){ X[i]=c->cxs+out[i].x/out[i].z*c->f; Y[i]=c->cys-out[i].y/out[i].z*c->f; Z[i]=(out[i].z-NEARZ)/(FARZ-NEARZ); if(Z[i]>1)Z[i]=1; }
  float mnx=1e9f,mxx=-1e9f,mny=1e9f,mxy=-1e9f; for(int i=0;i<m;i++){ if(X[i]<mnx)mnx=X[i]; if(X[i]>mxx)mxx=X[i]; if(Y[i]<mny)mny=Y[i]; if(Y[i]>mxy)mxy=Y[i]; } if(mxx<c->x0||mnx>c->x1||mxy<c->y0||mny>c->y1) return;
  unsigned col=RGBA((int)(rgb[0]*sh>255?255:rgb[0]*sh),(int)(rgb[1]*sh>255?255:rgb[1]*sh),(int)(rgb[2]*sh>255?255:rgb[2]*sh),255);
  for(int i=1;i+1<m;i++){ gfx_tri3(X[0],Y[0],Z[0],X[i],Y[i],Z[i],X[i+1],Y[i+1],Z[i+1],col); tri_budget--; } }
static const float LIGHT[3]={0.34f,0.86f,0.38f};
static void face(const Cam*c,V3 w0,V3 w1,V3 w2,V3 w3,V3 n,const unsigned char*rgb){
  V3 ctr={(w0.x+w1.x+w2.x+w3.x)*0.25f,(w0.y+w1.y+w2.y+w3.y)*0.25f,(w0.z+w1.z+w2.z+w3.z)*0.25f}; if(n.x*(c->px-ctr.x)+n.y*(c->py-ctr.y)+n.z*(c->pz-ctr.z)<=0) return;
  float d=n.x*LIGHT[0]+n.y*LIGHT[1]+n.z*LIGHT[2]; float sh=0.50f+0.50f*(d>0?d:0)+0.08f*(n.y<-0.5f?-1:0); V3 cv[4]={to_cam(c,w0.x,w0.y,w0.z),to_cam(c,w1.x,w1.y,w1.z),to_cam(c,w2.x,w2.y,w2.z),to_cam(c,w3.x,w3.y,w3.z)}; poly(c,cv,4,sh,rgb); }
/* generic oriented solid: axes ax,ay,az (world unit vectors), centre, half sizes */
static void draw_solid(const Cam*c,V3 ctr,V3 ax,V3 ay,V3 az,float hx,float hy,float hz,const unsigned char*rgb,int shape){
  #define PT(sx,sy,sz) ((V3){ctr.x+ax.x*(sx)*hx+ay.x*(sy)*hy+az.x*(sz)*hz, ctr.y+ax.y*(sx)*hx+ay.y*(sy)*hy+az.y*(sz)*hz, ctr.z+ax.z*(sx)*hx+ay.z*(sy)*hy+az.z*(sz)*hz})
  #define NEG(a) ((V3){-a.x,-a.y,-a.z})
  if(shape==0){ V3 P[6]={PT(1,0,0),PT(-1,0,0),PT(0,1,0),PT(0,-1,0),PT(0,0,1),PT(0,0,-1)}; static const int T[8][3]={{0,2,4},{4,2,1},{1,2,5},{5,2,0},{4,3,0},{1,3,4},{5,3,1},{0,3,5}};
    for(int i=0;i<8;i++){ V3 a=P[T[i][0]],b=P[T[i][1]],cc=P[T[i][2]]; V3 e1={b.x-a.x,b.y-a.y,b.z-a.z},e2={cc.x-a.x,cc.y-a.y,cc.z-a.z}; V3 n={e1.y*e2.z-e1.z*e2.y,e1.z*e2.x-e1.x*e2.z,e1.x*e2.y-e1.y*e2.x}; float l=sqrtf(n.x*n.x+n.y*n.y+n.z*n.z)+1e-6f; n.x/=l;n.y/=l;n.z/=l;
      V3 g={(a.x+b.x+cc.x)/3,(a.y+b.y+cc.y)/3,(a.z+b.z+cc.z)/3}; if(n.x*(g.x-ctr.x)+n.y*(g.y-ctr.y)+n.z*(g.z-ctr.z)<0){ n.x=-n.x;n.y=-n.y;n.z=-n.z; } if(n.x*(c->px-g.x)+n.y*(c->py-g.y)+n.z*(c->pz-g.z)<=0) continue;
      float d=n.x*LIGHT[0]+n.y*LIGHT[1]+n.z*LIGHT[2]; V3 cv[3]={to_cam(c,a.x,a.y,a.z),to_cam(c,b.x,b.y,b.z),to_cam(c,cc.x,cc.y,cc.z)}; poly(c,cv,3,0.5f+0.5f*(d>0?d:0),rgb); } return; }
  if(shape==2){ V3 R0[8],R1[8]; for(int i=0;i<8;i++){ float a=i*0.785398f,cy=cosf(a),sz=sinf(a); R0[i]=PT(-1,cy,sz); R1[i]=PT(1,cy,sz); }
    for(int i=0;i<8;i++){ int j=(i+1)&7; float a=(i+0.5f)*0.785398f; V3 n={ay.x*cosf(a)+az.x*sinf(a),ay.y*cosf(a)+az.y*sinf(a),ay.z*cosf(a)+az.z*sinf(a)}; face(c,R0[i],R0[j],R1[j],R1[i],n,rgb); }
    for(int s=0;s<2;s++){ V3*R=s?R1:R0; V3 n=s?ax:NEG(ax); V3 ct=PT(s?1:-1,0,0); if(n.x*(c->px-ct.x)+n.y*(c->py-ct.y)+n.z*(c->pz-ct.z)<=0) continue; V3 cv[8]; for(int i=0;i<8;i++) cv[i]=to_cam(c,R[i].x,R[i].y,R[i].z); float d=n.x*LIGHT[0]+n.y*LIGHT[1]+n.z*LIGHT[2]; poly(c,cv,8,0.5f+0.5f*(d>0?d:0),rgb); } return; }
  if(shape==3||shape==4){ V3 A0=PT(-1,-1,1),B0=PT(-1,-1,-1),C0=PT(-1,1,-1),A1=PT(1,-1,1),B1=PT(1,-1,-1),C1=PT(1,1,-1);
    face(c,A0,A1,B1,B0,NEG(ay),rgb); face(c,B0,B1,C1,C0,NEG(az),rgb);
    { float sl=hy*hz; V3 n={ay.x*hz+az.x*hy,ay.y*hz+az.y*hy,ay.z*hz+az.z*hy}; float l=sqrtf(n.x*n.x+n.y*n.y+n.z*n.z)+1e-6f; n.x/=l;n.y/=l;n.z/=l; (void)sl; face(c,A0,C0,C1,A1,n,rgb); }
    for(int s=0;s<2;s++){ V3 n=s?ax:NEG(ax); V3 ct=PT(s?1:-1,0,0); if(n.x*(c->px-ct.x)+n.y*(c->py-ct.y)+n.z*(c->pz-ct.z)<=0) continue; V3 t[3]; if(s){t[0]=A1;t[1]=B1;t[2]=C1;} else {t[0]=A0;t[1]=B0;t[2]=C0;} V3 cv[3]={to_cam(c,t[0].x,t[0].y,t[0].z),to_cam(c,t[1].x,t[1].y,t[1].z),to_cam(c,t[2].x,t[2].y,t[2].z)}; float d=n.x*LIGHT[0]+n.y*LIGHT[1]+n.z*LIGHT[2]; poly(c,cv,3,0.5f+0.5f*(d>0?d:0),rgb); } return; }
  V3 p000=PT(-1,-1,-1),p100=PT(1,-1,-1),p010=PT(-1,1,-1),p110=PT(1,1,-1),p001=PT(-1,-1,1),p101=PT(1,-1,1),p011=PT(-1,1,1),p111=PT(1,1,1);
  face(c,p001,p101,p111,p011,az,rgb); face(c,p100,p000,p010,p110,NEG(az),rgb); face(c,p101,p100,p110,p111,ax,rgb); face(c,p000,p001,p011,p010,NEG(ax),rgb); face(c,p011,p111,p110,p010,ay,rgb); face(c,p000,p100,p101,p001,NEG(ay),rgb); }
static void draw_char(const Cam*c,const Char*ch){
  float sy=sinf(ch->yaw),cy=cosf(ch->yaw); V3 ax={cy,0,-sy},ay={0,1,0},az={sy,0,cy}; float sw=sinf(ch->anim)*0.85f; float hurt=ch->hurt>0?90.f:0.f;
  unsigned char cols[4][3]; for(int k=0;k<4;k++) for(int j=0;j<3;j++){ int v=ch->col[k][j]+(int)hurt; cols[k][j]=v>255?255:v; }
  if(!ch->alive) return;
  /* ox, pivot y (top of limb), half sizes, colour slot, swing */
  static const float T[6][6]={{0,5.0f,1.0f,0.5f,0.5f,0},{0,4.0f,1.0f,1.0f,0.5f,1},{-1.5f,4.0f,0.5f,1.0f,0.5f,2},{1.5f,4.0f,0.5f,1.0f,0.5f,2},{-0.5f,2.0f,0.5f,1.0f,0.5f,3},{0.5f,2.0f,0.5f,1.0f,0.5f,3}};
  for(int i=0;i<6;i++){ float s=i==2?sw:(i==3?-sw:(i==4?-sw:(i==5?sw:0))); float cs=cosf(s),sn=sinf(s);
    V3 ly={ay.x*cs+az.x*sn,ay.y*cs+az.y*sn,ay.z*cs+az.z*sn},lz={az.x*cs-ay.x*sn,az.y*cs-ay.y*sn,az.z*cs-ay.z*sn};
    float hy=T[i][4]; if(i==0) hy=0.5f; V3 piv={ch->x+ax.x*T[i][0],ch->y+T[i][1],ch->z+ax.z*T[i][0]}; float hh=(i==0)?0.5f:T[i][3]; float hx=(i==0)?1.0f:T[i][2]; float hz=0.5f; (void)hy;
    V3 ctr={piv.x-ly.x*hh,piv.y-ly.y*hh,piv.z-ly.z*hh}; draw_solid(c,ctr,ax,ly,lz,hx,hh,hz,cols[(int)T[i][5]],1); }
  if(ch->hat>=0&&ch->hat<NITEMS){ const unsigned char*hc=ITEMCOL[ch->hat]; draw_solid(c,(V3){ch->x,ch->y+5.45f,ch->z},ax,ay,az,0.62f,0.45f,0.62f,hc,2); draw_solid(c,(V3){ch->x,ch->y+5.08f,ch->z},ax,ay,az,0.98f,0.08f,0.98f,hc,2); } }
void g3_render(Game3D*g,int pl,float x0,float y0,float x1,float y1){
  Cam c; make_cam(g,pl,&c,x0,y0,x1,y1); gfx_viewport(x0,y0,x1,y1);
  for(int i=0;i<10;i++){ float t=i/9.f; gfx_rect(x0,y0+(y1-y0)*i/10.f,x1,y0+(y1-y0)*(i+1)/10.f+1,RGBA((int)(70+t*120),(int)(140+t*85),(int)(225+t*22),255)); }
  tri_budget=g->np>=3?700:(g->np==2?1100:1600); const Map3D*m=&g->m; float far=g->np>=3?180.f:260.f;
  for(int pass=0;pass<2;pass++) for(int i=0;i<m->n&&tri_budget>0;i++){ const PartRec*p=&m->parts[i]; float h0=p->h[0]*0.25f,h1=p->h[1]*0.25f,h2=p->h[2]*0.25f; float sz=h0>h1?(h0>h2?h0:h2):(h1>h2?h1:h2);
    float dx=p->x-c.px,dy=p->y-c.py,dz=p->z-c.pz; float d=sqrtf(dx*dx+dy*dy+dz*dz); if(d-sz*1.8f>far+sz*3) continue; float lim=pass==0?60.f+sz*2:far+sz*4; if(pass==0?(d-sz*1.7f>lim):(d-sz*1.7f<=60.f+sz*2)) continue; if(d-sz*1.7f>lim) continue;
    float fwd=dx*c.r[2][0]+dy*c.r[2][1]+dz*c.r[2][2]; if(fwd<-sz*1.8f) continue; float proj=sz*1.8f/(fwd>1?fwd:1)*c.f; if(proj<(pass?1.6f:0.8f)&&fwd>0) continue;
    V3 ax={p->r[0]/127.f,p->r[3]/127.f,p->r[6]/127.f},ay={p->r[1]/127.f,p->r[4]/127.f,p->r[7]/127.f},az={p->r[2]/127.f,p->r[5]/127.f,p->r[8]/127.f};
    if(p->flags&2){ unsigned char t[3]={(unsigned char)(p->rgb[0]/2+110),(unsigned char)(p->rgb[1]/2+120),(unsigned char)(p->rgb[2]/2+130)}; draw_solid(&c,(V3){p->x,p->y,p->z},ax,ay,az,h0,h1,h2,t,p->shape==0?0:p->shape); }
    else draw_solid(&c,(V3){p->x,p->y,p->z},ax,ay,az,h0,h1,h2,p->rgb,p->shape); }
  for(int i=0;i<g->np;i++) if(i!=pl||1){ if(g->p[i].c.alive||1) draw_char(&c,&g->p[i].c); }
  for(int i=0;i<g->nb;i++){ const Char*b=&g->b[i].c; float dx=b->x-c.px,dz=b->z-c.pz; if(dx*dx+dz*dz<90.f*90.f&&b->alive) draw_char(&c,b); } }
int g3_project(const Game3D*g,int pl,float x,float y,float z,float x0,float y0,float x1,float y1,float*sx,float*sy){
  Cam c; make_cam(g,pl,&c,x0,y0,x1,y1); V3 v=to_cam(&c,x,y,z); if(v.z<NEARZ) return 0; *sx=c.cxs+v.x/v.z*c.f; *sy=c.cys-v.y/v.z*c.f; return 1; }

void g3_draw_preview(const Char*ch,float yaw,float x0,float y0,float x1,float y1){
  Char c=*ch; c.alive=1; c.yaw=yaw; c.x=0; c.y=0; c.z=0; c.anim=0; c.hurt=0; Cam cam; float h=y1-y0; cam.px=0; cam.py=3.0f; cam.pz=11.5f; cam.r[0][0]=1;cam.r[0][1]=0;cam.r[0][2]=0; cam.r[1][0]=0;cam.r[1][1]=1;cam.r[1][2]=0; cam.r[2][0]=0;cam.r[2][1]=0;cam.r[2][2]=-1;
  cam.x0=x0;cam.y0=y0;cam.x1=x1;cam.y1=y1; cam.f=h*0.5f/tanf(0.42f); cam.cxs=(x0+x1)*0.5f; cam.cys=(y0+y1)*0.5f; gfx_viewport(x0,y0,x1,y1); tri_budget=400; draw_char(&cam,&c); }
