#include "app.h"
#include <stdio.h>
#include <time.h>
#ifndef PS2
static const char*SAVEFILE="save.dat";
int plat_today_host(void); int plat_today(void){ return plat_today_host(); }
int plat_save_write(const void*d,int n){ FILE*f=fopen(SAVEFILE,"wb"); if(!f) return 0; fwrite(d,1,n,f); fclose(f); return 1; }
int plat_save_read(void*d,int n){ FILE*f=fopen(SAVEFILE,"rb"); if(!f) return 0; int r=(int)fread(d,1,n,f); fclose(f); return r==n; }
#endif
