#ifndef CATALOG_H
#define CATALOG_H
#include "assets.h"
#define NITEMS 65
#define NMAPS 56
typedef struct { const char*name; int robux; int spr; } CatItem;
typedef struct { const char*title; int year, nparts, off, nscripts; float spawn[3]; int script_lines; int thumb; } MapInfo;
extern const CatItem CATALOG[NITEMS]; extern const MapInfo MAPS[NMAPS];
#endif
