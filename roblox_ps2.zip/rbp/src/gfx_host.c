#include "gfx.h"
#include <stdio.h>
FILE*gfx_out;
void gfx_begin(void){ if(gfx_out) fprintf(gfx_out,"F\n"); } void gfx_end(void){}
void gfx_spr(int s,float cx,float cy,float w,float h,float r,unsigned c){ if(gfx_out) fprintf(gfx_out,"S %d %.1f %.1f %.1f %.1f %.3f %08x\n",s,cx,cy,w,h,r,c); }
void gfx_rect(float a,float b,float c2,float d,unsigned c){ if(gfx_out) fprintf(gfx_out,"R %.1f %.1f %.1f %.1f %08x\n",a,b,c2,d,c); }
void gfx_tri(float a,float b,float c2,float d,float e,float f,unsigned c){ if(gfx_out) fprintf(gfx_out,"T %.1f %.1f %.1f %.1f %.1f %.1f %08x\n",a,b,c2,d,e,f,c); }
void gfx_viewport(float a,float b,float c2,float d){ if(gfx_out) fprintf(gfx_out,"V %.0f %.0f %.0f %.0f\n",a,b,c2,d); }
void gfx_tri3(float a,float b,float c1,float d,float e,float f,float g,float h,float i,unsigned c){ if(gfx_out) fprintf(gfx_out,"3 %.1f %.1f %.3f %.1f %.1f %.3f %.1f %.1f %.3f %08x\n",a,b,c1,d,e,f,g,h,i,c); }
void gfx_clear_depth(void){}
