/* PS2: memory-card save (mc0:ROBLOXPS2/save.dat) + calendar day for the daily Tix reward */
#include <kernel.h>
#include <stdio.h>
#include <time.h>
#include <libmc.h>
#include "app.h"
static int mc_ready=0;
static void mc_prep(void){ if(mc_ready) return; mcInit(MC_TYPE_XMC); mc_ready=1; }
int plat_today(void){ time_t t=time(NULL); return (int)(t/86400); }
int plat_save_write(const void*d,int n){ mc_prep(); int r,res; mcMkDir(0,0,"ROBLOXPS2"); mcSync(0,NULL,&res); FILE*f=fopen("mc0:ROBLOXPS2/save.dat","wb"); if(!f) return 0; r=(int)fwrite(d,1,n,f); fclose(f); return r==n; }
int plat_save_read(void*d,int n){ mc_prep(); FILE*f=fopen("mc0:ROBLOXPS2/save.dat","rb"); if(!f) return 0; int r=(int)fread(d,1,n,f); fclose(f); return r==n; }
