/* scripted, click-driven run of the real UI: sign up -> shop -> play -> split screen; asserts logic, dumps draw lists */
#include "app.h"
#include "catalog.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern FILE*gfx_out; extern const unsigned char*maps_data;
static App A; static Pad P[MAXPL]; static int today=20000; static int fails=0;
int plat_today_host(void){ return today; }
#define CHECK(c,msg) do{ if(!(c)){ printf("FAIL: %s\n",msg); fails++; } else printf("ok:   %s\n",msg); }while(0)
static void tick(float s){ for(int i=0;i<(int)(s*60);i++){ for(int k=0;k<MAXPL;k++) P[k].pressed=0; app_update(&A,P,1/60.f); app_draw(&A); } }
static void press(int bit){ memset(P,0,sizeof P); P[0].pressed=1u<<bit; if(bit==B_X) P[0].held=1u<<B_X; app_update(&A,P,1/60.f); app_draw(&A); P[0].pressed=0; P[0].held=0; tick(0.03f); }
static void click(float x,float y){ A.cx=x; A.cy=y; memset(P,0,sizeof P); app_update(&A,P,1/60.f); app_draw(&A); P[0].pressed=1<<B_X; P[0].held=1<<B_X; app_update(&A,P,1/60.f); app_draw(&A); P[0].pressed=0; P[0].held=0; tick(0.05f); }
static void frame(const char*n){ fprintf(gfx_out,"N %s\n",n); app_draw(&A); }
int main(){ remove("save.dat"); FILE*f=fopen("../data/maps.bin","rb"); fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET); unsigned char*buf=malloc(n); fread(buf,1,n,f); maps_data=buf; fclose(f);
  gfx_out=fopen("../data/frames.txt","w"); app_init(&A); tick(0.1f); frame("boot"); tick(2.6f); CHECK(A.sc==SC_LANDING,"boot -> landing page"); frame("landing");
  click(320,258); CHECK(A.sc==SC_REG1,"Sign Up opens registration (gender + birthday)"); click(150+210+50,180); CHECK(A.reg_gender==1,"choose Girl"); click(150+50,180); A.reg_m=4; A.reg_d=13; A.reg_y=15; frame("reg1");
  click(320,382); CHECK(A.sc==SC_REG2,"Continue -> nickname + password step"); frame("reg2_empty");
  strcpy(A.f1,"Builder"); strcpy(A.f2,"pw123"); A.focus=0; tick(0.1f); frame("keyboard"); A.focus=-1; tick(0.1f); frame("reg2_signup"); click(320,238);
  CHECK(A.logged&&A.sc==SC_HOME&&!strcmp(A.sv.acc[A.sv.cur].nick,"Builder"),"Sign Up button registers the account and logs in"); CHECK(A.sv.acc[A.sv.cur].robux==100,"new account starts with 100 Robux");
  frame("home"); click(315,181+0); /* goes nowhere important */ A.sc=SC_HOME; 
  A.sc=SC_CATALOG; A.page=0; tick(0.1f); click(24+70,82+40); CHECK(A.dlg==2,"click an item opens the buy dialog"); frame("catalog_dialog");
  int r0=A.sv.acc[A.sv.cur].robux; int price=CATALOG[A.sel_item].robux; click(385,167); CHECK(A.sv.acc[A.sv.cur].robux==r0-price&&(A.sv.acc[A.sv.cur].owned[0]&1),"buy hat with Robux (price deducted, item owned)");
  A.sv.acc[A.sv.cur].hat=0; A.sv.acc[A.sv.cur].tix=0; A.sv.acc[A.sv.cur].robux=50; A.sc=SC_HOME; A.dlg=1; tick(0.1f); frame("convert"); int rr=A.sv.acc[A.sv.cur].robux; printf("dbg sc=%d dlg=%d robux=%d tix=%d\n",A.sc,A.dlg,rr,A.sv.acc[A.sv.cur].tix); click(255,230); printf("dbg after robux=%d tix=%d\n",A.sv.acc[A.sv.cur].robux,A.sv.acc[A.sv.cur].tix); CHECK(A.sv.acc[A.sv.cur].tix==10&&A.sv.acc[A.sv.cur].robux==rr-1,"convert 1 Robux = 10 Tix"); A.dlg=0;
  A.sc=SC_AVATAR; tick(0.1f); frame("avatar"); A.sc=SC_GAMES; A.page=0; tick(0.1f); frame("games"); click(24+96,84+60); CHECK(A.sc==SC_GAMEPAGE,"click a game opens its page"); A.bots=12; A.players=1; frame("gamepage");
  A.players=4; A.bots=30; tick(0.05f); frame("gamepage4"); click(445,295); CHECK(A.sc==SC_LOADING,"Play -> loading screen"); tick(0.8f); frame("loading"); tick(1.2f); CHECK(A.sc==SC_PLAY&&A.g.np==4&&A.g.nb==30,"game starts with 4 players and 30 bots");
  CHECK(A.sv.acc[A.sv.cur].tix==20,"daily login reward +10 Tix on first play today");
  for(int i=0;i<4;i++){ P[i].ly=(i==0)?-1:0; P[i].rx=(i==1)?1:0; } tick(1.5f); P[0].ly=0; P[1].held=1<<B_X; tick(0.2f); P[1].held=0; tick(1.2f); frame("play4");
  CHECK(A.g.p[0].c.alive,"player 1 alive after walking"); 
  press(B_START); CHECK(A.paused,"START pauses"); frame("pause"); click(320,205); CHECK(A.popt==1,"Port Options opens"); frame("portopt"); int k0=A.sv.keymap[0]; click(390,132); CHECK(A.sv.keymap[0]!=k0,"remap Jump to another button (swap)"); click(320,300); CHECK(!A.sv.economy,"Robux-Tix switch OFF from pause"); frame("portopt2"); A.sv.economy=1;
  A.paused=0; A.popt=0; tick(0.05f);
  /* single player view */
  A.players=1; A.bots=10; A.sel_map=0; A.sc=SC_LOADING; A.load=0; tick(2.2f); memset(P,0,sizeof P); P[0].ly=-1; tick(2.0f); P[0].ly=0; tick(0.3f); press(B_S); frame("safechat"); press(B_DN); press(B_X); tick(0.3f); frame("play1");
  CHECK(A.g.p[0].chat>0,"safe chat message appears over the player");
  for(int m=0;m<NMAPS;m+=11){ A.sel_map=m; A.players=2; A.bots=6; A.sc=SC_LOADING; A.load=0; tick(2.4f); tick(1.0f); char nm[32]; sprintf(nm,"map%d",m); if(m==22||m==11||m==33) frame(nm); }
  /* persistence + login */
  save_check: ; App B; plat_save_read(&B.sv,sizeof B.sv); CHECK(B.sv.magic==0x52424C58&&B.sv.acc[0].used&&!strcmp(B.sv.acc[0].nick,"Builder"),"account saved to storage (memory card on PS2)");
  A.sv.acc[0].hat=0; A.logged=0; A.sc=SC_LANDING; app_init(&A); tick(2.6f); CHECK(A.sv.acc[0].used&&A.sv.acc[0].owned[0]&1,"after restart: account + purchased item are still there");
  click(320,214); CHECK(A.sc==SC_LOGIN,"Login button opens login"); strcpy(A.f1,"Builder"); strcpy(A.f2,"wrong"); A.focus=-1; tick(0.1f); click(320,207); CHECK(!A.logged,"wrong password rejected"); strcpy(A.f2,"pw123"); click(320,207); CHECK(A.logged&&A.sc==SC_HOME,"Login with the saved account works");
  today++; A.sc=SC_GAMEPAGE; A.sel_map=3; A.players=1; A.bots=3; int tx=A.sv.acc[0].tix; A.sc=SC_LOADING; A.load=0; tick(2.4f); CHECK(A.sv.acc[0].tix==tx+10,"next day: daily reward again");
  A.sv.economy=0; today++; tx=A.sv.acc[0].tix; A.sc=SC_LOADING; A.load=0; tick(2.4f); CHECK(A.sv.acc[0].tix==tx,"Robux-Tix OFF: no daily reward");
  A.sc=SC_LANDING; A.logged=0; click(320,314); CHECK(A.is_guest&&A.logged,"PlayHow guest login"); A.sc=SC_CATALOG; A.dlg=0; tick(0.1f); click(94,122); frame("guest_catalog");
  fclose(gfx_out); printf("\n%s (%d failures)\n",fails?"SOME CHECKS FAILED":"ALL CHECKS PASSED",fails); return fails?1:0; }
