#ifndef GAME3D_H
#define GAME3D_H
#define MAXPL 4
#define MAXBOT 30
#pragma pack(push,1)
typedef struct { float x,y,z; short h[3]; signed char r[9]; unsigned char rgb[3],shape,flags; } PartRec;   /* 32 bytes, h = half size in 1/4 stud */
#pragma pack(pop)
typedef struct { float x,y,z,vx,vy,vz,yaw,anim,hp,respawn,atk,hurt; int onground,alive,hat,jump; unsigned char col[4][3]; } Char;   /* col: head,torso,arms,legs */
typedef struct { Char c; float cyaw,cpitch,cdist,chat; char say[28]; int tool,ntool,pad; float mx,mz; int kills,deaths; } Player;
typedef struct { Char c; float tx,tz,think,stuck; int mode; } Bot;
typedef struct { float cx[4]; } Dummy;
typedef struct { int sx,sy,ex,ey; } Rect;
typedef struct { const PartRec*parts; int n; float bmin[3],bmax[3]; float cell; int gw,gh; int*cstart,*cidx; int*big; int nbig; float spawn[3]; int map; unsigned char*alive_dummy; } Map3D;
typedef struct { Map3D m; Player p[MAXPL]; int np; Bot b[MAXBOT]; int nb; int battle; float t; unsigned rng; int sfx[8],nsfx; } Game3D;
typedef struct { float mx,my,cam_x,cam_y,zoom; int jump,act,safe,tri,toolL,toolR; } PlayerIn;
extern const unsigned char*maps_data;
void g3_unload(Game3D*g);
void g3_load(Game3D*g,int map,int nplayers,int nbots);
void g3_step(Game3D*g,const PlayerIn*in,float dt);
void g3_render(Game3D*g,int pl,float x0,float y0,float x1,float y1);
int  g3_project(const Game3D*g,int pl,float x,float y,float z,float x0,float y0,float x1,float y1,float*sx,float*sy);
int  g3_is_battle(const char*title);
void g3_viewport(int np,int i,float*x0,float*y0,float*x1,float*y1);
void g3_draw_preview(const Char*ch,float yaw,float x0,float y0,float x1,float y1);
#endif
