#ifndef AUDIO_TAB_H
#define AUDIO_TAB_H
typedef struct { unsigned int off,len; } Snd;
enum {
 A_CLICK,
 A_HIT,
 A_COLLIDE,
 A_OUCH,
 A_PING,
 A_SWITCH,
 A_FLASH,
 A_STEP1,
 A_STEP2,
 A_GRASS,
 A_KERPLUNK,
 A_CLICKFAST,
 A_MUSIC,
 A_COUNT };
extern const Snd SND[A_COUNT];
#endif
