/* Roblox 2012 PS2 port - website screens, accounts, economy, catalog, in-game HUD and menus (English) */
#include "app.h"
#include "gfx.h"
#include "catalog.h"
#include "audio_tab.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
extern const short FA_MAP[128],FB_MAP[128];
#define W RGBA(255,255,255,255)
#define BLK RGBA(0,0,0,255)
static const char*MONTHS[12]={"January","February","March","April","May","June","July","August","September","October","November","December"};
static const unsigned char PAL[12][3]={{245,205,47},{196,40,27},{13,105,172},{75,151,75},{218,133,65},{107,50,124},{27,42,53},{242,243,243},{124,92,70},{255,176,0},{18,238,212},{163,162,165}};
static const char*BTN[4]={"X","CIRCLE","TRIANGLE","SQUARE"}; static const int BTNID[4]={B_X,B_O,B_T,B_S};
static void snd(App*a,int s){ if(a->nsnd_out<16) a->snd_out[a->nsnd_out++]=s; }
static void toast(App*a,const char*s){ strncpy(a->toast,s,39); a->toastt=3.f; }
/* ---------------- text / widgets ---------------- */
static float tw(const char*s,float k,int bold){ float w=0; for(;*s;s++){ int c=(unsigned char)*s; if(c<32||c>126)c=63; int id=(bold?FB_MAP:FA_MAP)[c]; if(id>=0) w+=(SPR[id].ow+1)*k; } return w; }
static void text(float x,float y,float k,const char*s,unsigned col,int al,int bold){ float w=tw(s,k,bold); if(al==1)x-=w/2; else if(al==2)x-=w;
  for(;*s;s++){ int c=(unsigned char)*s; if(c<32||c>126)c=63; int id=(bold?FB_MAP:FA_MAP)[c]; if(id<0) continue; const Spr*g=&SPR[id]; if(c!=32) gfx_spr(id,x+g->ow*k/2,y+g->oh*k/2,g->ow*k,g->oh*k,0,col); x+=(g->ow+1)*k; } }
static int hit(const App*a,float x0,float y0,float x1,float y1){ return a->cx>=x0&&a->cx<=x1&&a->cy>=y0&&a->cy<=y1; }
static int button(App*a,float x0,float y0,float x1,float y1,const char*s,unsigned col,unsigned tcol,float k){ int hv=hit(a,x0,y0,x1,y1); unsigned c=col; if(hv){ int r=(c>>24)&255,g=(c>>16)&255,b=(c>>8)&255; r=r*9/8>255?255:r*9/8; g=g*9/8>255?255:g*9/8; b=b*9/8>255?255:b*9/8; c=RGBA(r,g,b,255); }
  gfx_rect(x0-1,y0-1,x1+1,y1+1,RGBA(40,40,40,255)); gfx_rect(x0,y0,x1,y1,c); gfx_rect(x0,y0,x1,y0+(y1-y0)*0.45f,RGBA(255,255,255,45)); text((x0+x1)/2,(y0+y1)/2-14*k,k,s,tcol,1,1); if(hv&&a->click){ snd(a,A_CLICK); return 1; } return 0; }
static const unsigned BLUE=RGBA(45,98,179,255),GREEN=RGBA(48,150,48,255),GRAY=RGBA(190,190,190,255),RED=RGBA(190,50,40,255),NAVY=RGBA(24,52,110,255);
static void navbar(App*a){
  gfx_rect(0,0,640,448,RGBA(235,238,244,255)); gfx_rect(0,0,640,34,NAVY); gfx_rect(0,34,640,38,RGBA(15,30,70,255));
  gfx_rect(8,5,92,29,RGBA(196,40,27,255)); text(50,6,0.62f,"ROBLOX",W,1,1);
  const char*T[4]={"My ROBLOX","Games","Catalog","Help"}; Screen S[4]={SC_HOME,SC_GAMES,SC_CATALOG,SC_HELP}; float x=110;
  for(int i=0;i<4;i++){ float w=tw(T[i],0.5f,1)+18; int on=(a->sc==S[i]||(i==1&&a->sc==SC_GAMEPAGE)||(i==0&&a->sc==SC_AVATAR)); int hv=hit(a,x,0,x+w,34); if(on) gfx_rect(x,2,x+w,34,RGBA(60,120,210,255)); text(x+w/2,8,0.5f,T[i],hv?RGBA(255,230,120,255):W,1,1);
    if(hv&&a->click&&a->logged){ snd(a,A_CLICK); a->sc=S[i]; a->page=0; a->t=0; } x+=w+4; }
  if(a->logged){ Account*ac=a->is_guest?&a->guest:&a->sv.acc[a->sv.cur]; char b[48]; if(a->sv.economy&&!a->is_guest){ snprintf(b,sizeof b,"R$ %d  T$ %d",ac->robux,ac->tix); text(630,3,0.42f,b,RGBA(255,230,120,255),2,1); } text(630,18,0.42f,ac->nick,W,2,0);
    if(!a->is_guest&&0) {} }
  else { if(button(a,520,5,574,29,"Login",GREEN,W,0.42f)) { a->sc=SC_LOGIN; a->f1[0]=a->f2[0]=0; a->focus=0; a->err[0]=0; } if(button(a,578,5,634,29,"Sign Up",BLUE,W,0.42f)){ a->sc=SC_REG1; a->reg_gender=0; a->reg_m=0; a->reg_d=0; a->reg_y=20; } } }
/* ---------------- on-screen keyboard (iPhone style) ---------------- */
static void keyboard(App*a,char*buf,int maxlen){
  float y0=236; gfx_rect(0,y0-4,640,448,RGBA(205,208,214,255));
  static const char*R0="qwertyuiop",*R1="asdfghjkl",*R2="zxcvbnm",*S0="1234567890",*S1="-/:;()$&@\"",*S2=".,?!'";
  const char*r[3]={a->sym?S0:R0,a->sym?S1:R1,a->sym?S2:R2}; float kw=54,kh=44,gap=6;
  for(int row=0;row<3;row++){ int n=(int)strlen(r[row]); float x=(640-n*(kw+gap)+gap)/2+(row==2&&!a->sym?0:0); float y=y0+row*(kh+gap);
    if(row==2){ x+=(kw+gap)*0.5f; if(button(a,x-(kw+gap)*1.3f,y,x-gap-4,y+kh,a->sym?"#":(a->shift?"UP":"up"),a->shift?BLUE:RGBA(170,174,184,255),W,0.5f)) a->shift^=1; }
    for(int i=0;i<n;i++){ char s[2]={r[row][i],0}; if(a->shift&&!a->sym&&s[0]>='a'&&s[0]<='z') s[0]-=32; if(button(a,x+i*(kw+gap),y,x+i*(kw+gap)+kw,y+kh,s,W,BLK,0.62f)){ int l=(int)strlen(buf); if(l<maxlen){ buf[l]=s[0]; buf[l+1]=0; } if(a->shift) a->shift=0; } }
    if(row==2&&button(a,x+n*(kw+gap),y,x+n*(kw+gap)+kw*1.4f,y+kh,"<-",RGBA(170,174,184,255),W,0.5f)){ int l=(int)strlen(buf); if(l>0) buf[l-1]=0; } }
  float y=y0+3*(kh+gap); if(button(a,20,y,110,y+kh,a->sym?"abc":"123",RGBA(170,174,184,255),W,0.5f)) a->sym^=1; if(button(a,120,y,500,y+kh,"space",W,BLK,0.5f)){ int l=(int)strlen(buf); if(l<maxlen){ buf[l]=' '; buf[l+1]=0; } }
  if(button(a,510,y,620,y+kh,"Done",BLUE,W,0.5f)) a->focus=-1; }
static void field(App*a,float x,float y,float w,const char*label,char*buf,int idx,int pw){ text(x,y-18,0.48f,label,BLK,0,1); gfx_rect(x-1,y-1,x+w+1,y+27,a->focus==idx?RGBA(40,110,220,255):RGBA(90,90,90,255)); gfx_rect(x,y,x+w,y+26,W); char b[20]; if(pw){ int l=(int)strlen(buf); for(int i=0;i<l;i++) b[i]='*'; b[l]=0; } else strcpy(b,buf);
  text(x+6,y+3,0.55f,b,BLK,0,0); if(a->focus==idx&&((int)(a->t*2)&1)) gfx_rect(x+8+tw(b,0.55f,0),y+4,x+10+tw(b,0.55f,0),y+22,BLK); if(hit(a,x,y,x+w,y+26)&&a->click){ a->focus=idx; snd(a,A_CLICK); } }
static unsigned hashpw(const char*s){ unsigned h=2166136261u; for(;*s;s++){ h^=(unsigned char)*s; h*=16777619u; } return h; }
static void save(App*a){ a->sv.magic=0x52424C58; plat_save_write(&a->sv,sizeof a->sv); }
static Account*cur(App*a){ return a->is_guest?&a->guest:&a->sv.acc[a->sv.cur]; }
static int owned(const Account*c,int i){ return (c->owned[i>>6]>>(i&63))&1; }
/* ---------------- shared helpers ---------------- */
static void setup_char(Char*c,const Account*ac){ memset(c,0,sizeof*c); c->alive=1; c->hat=ac->hat; memcpy(c->col,ac->col,12); }
static void new_account(App*a){ int slot=-1; for(int i=0;i<4;i++) if(!a->sv.acc[i].used){slot=i;break;} if(slot<0){ strcpy(a->err,"Account slots full (4)"); return; }
  Account*c=&a->sv.acc[slot]; memset(c,0,sizeof*c); c->used=1; strncpy(c->nick,a->f1,15); c->pw=hashpw(a->f2); c->gender=a->reg_gender; c->month=a->reg_m+1; c->day=a->reg_d+1; c->year=1990+a->reg_y; c->robux=100; c->tix=0; c->hat=-1; c->last_day=0;
  static const unsigned char body[2][4][3]={{{245,205,47},{13,105,172},{245,205,47},{75,151,75}},{{245,205,47},{196,40,27},{245,205,47},{107,50,124}}}; memcpy(c->col,body[a->reg_gender],12); a->sv.cur=slot; a->logged=1; a->is_guest=0; save(a); a->sc=SC_HOME; toast(a,"Account created! Welcome to ROBLOX"); snd(a,A_PING); }
static void start_play(App*a){ a->sc=SC_LOADING; a->load=0; a->t=0; snd(a,A_SWITCH); }
static void preview(const Account*ac,float yaw,float x0,float y0,float x1,float y1){ Char c; setup_char(&c,ac); g3_draw_preview(&c,yaw,x0,y0,x1,y1); gfx_viewport(0,0,640,448); }
/* ---------------- update ---------------- */
void app_init(App*a){ memset(a,0,sizeof*a); a->cx=320; a->cy=224; a->sv.economy=1; a->sv.music=1; a->sv.keymap[0]=B_X; a->sv.keymap[1]=B_O; a->sv.keymap[2]=B_T; a->sv.keymap[3]=B_S; a->bots=8; a->players=1; a->sel_acc=0; a->focus=-1;
  SaveData tmp; if(plat_save_read(&tmp,sizeof tmp)&&tmp.magic==0x52424C58) a->sv=tmp; a->guest.used=1; a->guest.hat=-1; static const unsigned char gc[4][3]={{245,205,47},{163,162,165},{245,205,47},{99,95,98}}; memcpy(a->guest.col,gc,12); a->sc=SC_BOOT; }
static int pressed(const Pad*p,int b){ return (p->pressed>>b)&1; }
void app_update(App*a,const Pad*pads,float dt){
  a->t+=dt; a->nsnd_out=0; if(a->toastt>0) a->toastt-=dt; memcpy(a->pad,pads,sizeof(Pad)*MAXPL);
  const Pad*p0=&pads[0]; a->cx+=p0->lx*360*dt+((p0->held>>B_RT&1)-(p0->held>>B_LF&1))*360*dt; a->cy+=p0->ly*360*dt+((p0->held>>B_DN&1)-(p0->held>>B_UP&1))*360*dt; if(a->cx<0)a->cx=0; if(a->cx>639)a->cx=639; if(a->cy<0)a->cy=0; if(a->cy>447)a->cy=447;
  a->click=pressed(p0,B_X)&&a->sc!=SC_PLAY; if(a->sc==SC_PLAY&&(a->paused||a->safe_open)) a->click=pressed(p0,B_X);
  a->want_music=(a->sv.music&&a->sc!=SC_BOOT)?A_MUSIC:-1;
  if(a->sc==SC_BOOT&&a->t>2.5f){ a->sc=SC_LANDING; a->t=0; }
  if(a->sc==SC_LOADING){ a->load+=dt/1.6f; if(a->load>=1&&a->load<5){ a->load=5; Account*ac=cur(a); g3_unload(&a->g); g3_load(&a->g,a->sel_map,a->players,a->bots);
      for(int i=0;i<a->players;i++){ if(i==0||1){ setup_char(&a->g.p[i].c,i==0?ac:&a->guest); a->g.p[i].c.x=a->g.m.spawn[0]+i*3; a->g.p[i].c.y=a->g.m.spawn[1]; a->g.p[i].c.z=a->g.m.spawn[2]; a->g.p[i].c.alive=1; a->g.p[i].c.hp=100; } if(i>0){ static const unsigned char c2[4][3]={{245,205,47},{196,40,27},{245,205,47},{27,42,53}}; (void)c2; } }
      if(a->sv.economy&&!a->is_guest&&ac->last_day!=plat_today()){ ac->last_day=plat_today(); ac->tix+=10; toast(a,"Daily login reward: +10 Tix!"); snd(a,A_PING); }
      if(!a->is_guest) { ac->played[a->sel_map>>3]|=1<<(a->sel_map&7); save(a); } a->sc=SC_PLAY; a->paused=0; a->popt=0; a->t=0; } }
  if(a->sc==SC_PLAY){ Game3D*g=&a->g; const int*km=a->sv.keymap;
    if(!a->paused){ for(int i=0;i<g->np;i++){ const Pad*p=&pads[i]; PlayerIn*in=&a->in[i]; memset(in,0,sizeof*in); in->mx=p->lx; in->my=p->ly; in->cam_x=p->rx; in->cam_y=p->ry; if(a->zoomtog[i]) in->zoom=7; else in->zoom=14;
        in->jump=(p->held>>km[0])&1; in->act=(p->held>>km[1])&1; if(pressed(p,km[2])) a->zoomtog[i]^=1;
        if(pressed(p,km[3])) { if(i==0) a->safe_open^=1; } in->toolL=pressed(p,B_L1)||pressed(p,B_L2); in->toolR=pressed(p,B_R1)||pressed(p,B_R2); if(i==0&&a->safe_open){ in->mx=in->my=0; in->jump=in->act=0; if(pressed(p,B_UP)) a->safe_sel=(a->safe_sel+7)%8; if(pressed(p,B_DN)) a->safe_sel=(a->safe_sel+1)%8; if(pressed(p,B_X)){ in->safe=a->safe_sel+1; a->safe_open=0; snd(a,A_CLICK); } } }
      g3_step(g,a->in,dt); for(int i=0;i<g->nsfx;i++) snd(a,g->sfx[i]); }
    for(int i=0;i<MAXPL;i++) if(pressed(&pads[i],B_START)){ a->paused^=1; a->popt=0; break; } } }
/* ---------------- draw ---------------- */
static void bar(float x0,float y0,float x1,float y1,float f,unsigned c){ gfx_rect(x0-1,y0-1,x1+1,y1+1,BLK); gfx_rect(x0,y0,x1,y1,RGBA(60,60,60,255)); gfx_rect(x0,y0,x0+(x1-x0)*f,y1,c); }
static int slider(App*a,float x,float y,float w,const char*label,int*v,int lo,int hi){ char b[24]; snprintf(b,sizeof b,"%s: %d",label,*v); text(x,y-24,0.6f,b,BLK,0,1); gfx_rect(x,y+6,x+w,y+14,RGBA(130,130,130,255)); float f=(*v-lo)/(float)(hi-lo); gfx_rect(x+w*f-7,y-2,x+w*f+7,y+22,BLUE);
  if(hit(a,x-8,y-4,x+w+8,y+24)&&(a->pad[0].held&1)){ float t=(a->cx-x)/w; if(t<0)t=0; if(t>1)t=1; int nv=lo+(int)(t*(hi-lo)+0.5f); if(nv!=*v){ *v=nv; return 1; } }
  if(button(a,x-44,y-2,x-8,y+24,"-",GRAY,BLK,0.6f)&&*v>lo){ (*v)--; return 1; } if(button(a,x+w+8,y-2,x+w+44,y+24,"+",GRAY,BLK,0.6f)&&*v<hi){ (*v)++; return 1; } return 0; }
static void hud(App*a,int pl,float x0,float y0,float x1,float y1){ Game3D*g=&a->g; const Player*p=&g->p[pl]; char b[40];
  bar(x1-130,y0+8,x1-8,y0+20,p->c.hp<0?0:p->c.hp/100.f,p->c.hp>50?RGBA(60,200,60,255):RGBA(220,70,50,255)); text(x1-8,y0+20,0.36f,"Health",W,2,1);
  snprintf(b,sizeof b,"P%d %s",pl+1,cur(a)->nick); text(x0+8,y0+6,0.42f,pl==0?cur(a)->nick:b,W,0,1);
  static const char*TN[3]={"SWORD","SLINGSHOT","PIZZA"}; for(int i=0;i<p->ntool;i++){ float cx=(x0+x1)/2+(i-1)*60,cy=y1-20; gfx_rect(cx-26,cy-14,cx+26,cy+14,i==p->tool?RGBA(255,230,120,230):RGBA(40,40,40,200)); text(cx,cy-9,0.32f,TN[i],i==p->tool?BLK:W,1,1); }
  if(p->chat>0){ float sx,sy; if(g3_project(g,pl,p->c.x,p->c.y+6.5f,p->c.z,x0,y0,x1,y1,&sx,&sy)){ float w=tw(p->say,0.45f,1)+12; gfx_rect(sx-w/2,sy-22,sx+w/2,sy,W); gfx_rect(sx-w/2-1,sy-23,sx+w/2+1,sy+1,RGBA(0,0,0,100)); text(sx,sy-19,0.45f,p->say,BLK,1,1); } }
  if(!p->c.alive){ gfx_rect(x0,y0,x1,y1,RGBA(0,0,0,120)); text((x0+x1)/2,(y0+y1)/2-12,0.8f,"You died! Respawning...",W,1,1); }
  for(int i=0;i<g->nb;i++){ const Char*c=&g->b[i].c; if(!c->alive) continue; float dx=c->x-p->c.x,dz=c->z-p->c.z; if(dx*dx+dz*dz>60*60) continue; float sx,sy; if(g3_project(g,pl,c->x,c->y+6.2f,c->z,x0,y0,x1,y1,&sx,&sy)&&sx>x0&&sx<x1&&sy>y0&&sy<y1){ snprintf(b,sizeof b,"Bot%d",i+1); text(sx,sy-8,0.34f,b,W,1,0); bar(sx-18,sy+4,sx+18,sy+8,c->hp/100.f,RGBA(60,200,60,255)); } } }
void app_draw(App*a){
  gfx_begin(); Account*ac=cur(a); char b[96];
  switch(a->sc){
  case SC_BOOT: gfx_rect(0,0,640,448,RGBA(25,25,25,255)); gfx_rect(220,170,420,230,RGBA(196,40,27,255)); text(320,176,1.5f,"ROBLOX",W,1,1); text(320,250,0.5f,"PS2 FAN PORT - 2012 EDITION",RGBA(200,200,200,255),1,0); bar(240,300,400,308,a->t/2.5f,RGBA(60,150,230,255)); break;
  case SC_LANDING: navbar(a); gfx_rect(0,38,640,448,RGBA(245,247,250,255)); gfx_rect(150,70,490,400,RGBA(215,215,215,255)); gfx_rect(152,72,488,398,RGBA(238,238,238,255)); text(320,84,1.1f,"Welcome to ROBLOX",BLK,1,1);
    text(320,138,0.55f,"Build, play and explore classic places!",RGBA(60,60,60,255),1,0);
    if(button(a,200,180,440,224,"Login",GREEN,W,0.9f)){ a->sc=SC_LOGIN; a->f1[0]=a->f2[0]=0; a->focus=0; a->err[0]=0; }
    if(button(a,200,236,440,280,"Sign Up",BLUE,W,0.9f)){ a->sc=SC_REG1; a->reg_gender=0; a->reg_m=0; a->reg_d=0; a->reg_y=20; }
    if(button(a,200,292,440,336,"PlayHow (Guest)",RGBA(120,120,130,255),W,0.8f)){ a->logged=1; a->is_guest=1; snprintf(a->guest.nick,16,"Guest %d",1000+(int)(a->t*977)%9000); a->sc=SC_HOME; snd(a,A_PING); }
    text(320,348,0.38f,"Guests can play, but cannot save, buy items or use Robux/Tix",RGBA(90,90,90,255),1,0); break;
  case SC_LOGIN: navbar(a); text(320,52,1.0f,"Member Login",BLK,1,1);
    { int n=0; for(int i=0;i<4;i++) if(a->sv.acc[i].used){ float y=92+n*30; int on=(a->sel_acc==i); if(button(a,40,y,200,y+26,a->sv.acc[i].nick,on?BLUE:GRAY,on?W:BLK,0.5f)){ a->sel_acc=i; strncpy(a->f1,a->sv.acc[i].nick,15); a->focus=1; } n++; } if(!n) text(120,100,0.42f,"No saved accounts",RGBA(90,90,90,255),1,0); }
    field(a,260,100,300,"Username",a->f1,0,0); field(a,260,152,300,"Password",a->f2,1,1); if(a->focus==0) keyboard(a,a->f1,12); else if(a->focus==1) keyboard(a,a->f2,12);
    if(a->focus<0){ if(button(a,260,190,380,224,"Login",GREEN,W,0.7f)){ int ok=0; for(int i=0;i<4;i++) if(a->sv.acc[i].used&&!strcmp(a->sv.acc[i].nick,a->f1)&&a->sv.acc[i].pw==hashpw(a->f2)){ a->sv.cur=i; a->logged=1; a->is_guest=0; a->sc=SC_HOME; ok=1; save(a); snd(a,A_PING); toast(a,"Logged in"); } if(!ok){ strcpy(a->err,"Wrong username or password"); snd(a,A_COLLIDE); } }
      if(button(a,392,190,500,224,"Back",GRAY,BLK,0.6f)) a->sc=SC_LANDING; if(a->err[0]) text(260,232,0.45f,a->err,RED,0,1); }
    else if(button(a,560,190,630,224,"Back",GRAY,BLK,0.5f)) a->sc=SC_LANDING; break;
  case SC_REG1: navbar(a); text(320,50,0.9f,"Create a Free ROBLOX Account",BLK,1,1); text(320,86,0.5f,"Choose your character",RGBA(60,60,60,255),1,1);
    for(int g=0;g<2;g++){ float x=150+g*210; Account pa; memset(&pa,0,sizeof pa); pa.hat=-1; static const unsigned char body[2][4][3]={{{245,205,47},{13,105,172},{245,205,47},{75,151,75}},{{245,205,47},{196,40,27},{245,205,47},{107,50,124}}}; memcpy(pa.col,body[g],12);
      gfx_rect(x-3,108,x+103,258,a->reg_gender==g?RGBA(40,110,220,255):RGBA(160,160,160,255)); gfx_rect(x,111,x+100,255,RGBA(190,225,250,255)); preview(&pa,a->t*1.2f,x,111,x+100,255); if(hit(a,x,111,x+100,255)&&a->click){ a->reg_gender=g; snd(a,A_CLICK); } text(x+50,262,0.55f,g?"Girl":"Boy",BLK,1,1); }
    text(60,300,0.5f,"Birthday",BLK,0,1); { int v; const char*lab[3]={"Month","Day","Year"}; for(int k=0;k<3;k++){ float x=140+k*150; text(x+55,290,0.4f,lab[k],RGBA(80,80,80,255),1,0); if(button(a,x,306,x+28,332,"<",GRAY,BLK,0.5f)){ if(k==0) a->reg_m=(a->reg_m+11)%12; else if(k==1) a->reg_d=(a->reg_d+30)%31; else a->reg_y=(a->reg_y+39)%40; }
      if(k==0) snprintf(b,sizeof b,"%s",MONTHS[a->reg_m]); else if(k==1) snprintf(b,sizeof b,"%d",a->reg_d+1); else snprintf(b,sizeof b,"%d",1990+a->reg_y); gfx_rect(x+30,306,x+112,332,W); text(x+71,309,0.5f,b,BLK,1,0);
      if(button(a,x+114,306,x+142,332,">",GRAY,BLK,0.5f)){ if(k==0) a->reg_m=(a->reg_m+1)%12; else if(k==1) a->reg_d=(a->reg_d+1)%31; else a->reg_y=(a->reg_y+1)%40; } (void)v; } }
    if(button(a,230,360,410,404,"Continue",GREEN,W,0.8f)){ a->sc=SC_REG2; a->f1[0]=a->f2[0]=0; a->focus=0; a->err[0]=0; } if(button(a,20,360,120,404,"Back",GRAY,BLK,0.6f)) a->sc=a->logged?SC_HOME:SC_LANDING; break;
  case SC_REG2: navbar(a); text(320,48,0.9f,"Choose a Nickname and Password",BLK,1,1); field(a,150,96,340,"Nickname (shown in games)",a->f1,0,0); field(a,150,150,340,"Password (to log in again)",a->f2,1,1);
    if(a->focus==0) keyboard(a,a->f1,12); else if(a->focus==1) keyboard(a,a->f2,12);
    if(a->focus<0){ int okn=strlen(a->f1)>=3,okp=strlen(a->f2)>=4; text(320,186,0.4f,"Nickname: 3-12 letters / numbers   Password: 4-12 characters",RGBA(80,80,80,255),1,0);
      if(button(a,230,214,410,262,"Sign Up",okn&&okp?GREEN:RGBA(150,150,150,255),W,0.9f)){ if(okn&&okp){ int dup=0; for(int i=0;i<4;i++) if(a->sv.acc[i].used&&!strcmp(a->sv.acc[i].nick,a->f1)) dup=1; if(dup){ strcpy(a->err,"That nickname is taken"); } else new_account(a); } else strcpy(a->err,"Nickname or password too short"); }
      if(button(a,20,214,120,262,"Back",GRAY,BLK,0.6f)) a->sc=SC_REG1; if(a->err[0]) text(320,276,0.5f,a->err,RED,1,1); } break;
  case SC_HOME: navbar(a); gfx_rect(20,50,640-20,70,RGBA(220,226,238,255)); snprintf(b,sizeof b,"Hello, %s!",ac->nick); text(30,50,0.65f,b,NAVY,0,1);
    gfx_rect(30,84,200,330,RGBA(190,225,250,255)); preview(ac,a->t*0.8f,30,84,200,330); if(button(a,30,336,200,366,"Edit Character",BLUE,W,0.55f)) a->sc=SC_AVATAR;
    if(a->is_guest){ text(230,90,0.55f,"You are playing as a Guest.",BLK,0,1); text(230,116,0.42f,"Guests can play places and use Safe Chat, but progress, items and",RGBA(70,70,70,255),0,0); text(230,134,0.42f,"Robux / Tix are not saved. Sign up to keep your stuff!",RGBA(70,70,70,255),0,0); if(button(a,230,160,400,196,"Sign Up",BLUE,W,0.6f)){ a->sc=SC_REG1; a->logged=0; a->reg_gender=0; a->reg_y=20; } }
    else { if(a->sv.economy){ snprintf(b,sizeof b,"Robux: %d      Tix: %d",ac->robux,ac->tix); text(230,90,0.6f,b,BLK,0,1); if(button(a,230,126,420,158,"Convert R$ to Tix",GREEN,W,0.5f)) a->dlg=1; } else text(230,90,0.5f,"Robux-Tix is OFF: all items are free",RGBA(90,90,90,255),0,1);
      int np=0; for(int i=0;i<NMAPS;i++) if((ac->played[i>>3]>>(i&7))&1) np++; snprintf(b,sizeof b,"Places visited: %d / %d",np,NMAPS); text(230,176,0.5f,b,BLK,0,0); int no=0; for(int i=0;i<NITEMS;i++) no+=owned(ac,i); snprintf(b,sizeof b,"Items owned: %d / %d",no,NITEMS); text(230,200,0.5f,b,BLK,0,0); }
    if(button(a,230,250,400,286,"Play Games",GREEN,W,0.6f)) a->sc=SC_GAMES; if(button(a,230,296,400,332,"Catalog",BLUE,W,0.6f)) a->sc=SC_CATALOG;
    if(button(a,420,250,610,286,a->sv.economy?"Robux-Tix: ON":"Robux-Tix: OFF",a->sv.economy?GREEN:RED,W,0.5f)){ a->sv.economy^=1; save(a); } if(button(a,420,296,610,332,"Music",a->sv.music?GREEN:RED,W,0.5f)){ a->sv.music^=1; save(a); }
    if(button(a,230,376,400,408,"Log Out",RGBA(120,120,130,255),W,0.5f)){ a->logged=0; a->is_guest=0; a->sc=SC_LANDING; save(a); }
    if(a->dlg==1){ gfx_rect(0,0,640,448,RGBA(0,0,0,150)); gfx_rect(170,120,470,300,W); text(320,130,0.7f,"Convert Robux to Tix",BLK,1,1); text(320,170,0.5f,"1 Robux = 10 Tix",RGBA(60,60,60,255),1,0); if(button(a,190,210,320,250,"Convert 1 R$",GREEN,W,0.5f)&&ac->robux>=1){ ac->robux--; ac->tix+=10; snd(a,A_PING); save(a); } if(button(a,330,210,450,250,"Convert 10 R$",GREEN,W,0.5f)&&ac->robux>=10){ ac->robux-=10; ac->tix+=100; snd(a,A_PING); save(a); } if(button(a,260,262,380,292,"Close",GRAY,BLK,0.5f)) a->dlg=0; } break;
  case SC_AVATAR: navbar(a); text(30,46,0.7f,"Edit Character",NAVY,0,1); gfx_rect(30,84,190,330,RGBA(190,225,250,255)); preview(ac,a->t*0.8f,30,84,190,330);
    { static const char*PN[4]={"Head","Torso","Arms","Legs"}; for(int k=0;k<4;k++){ float y=90+k*40; text(210,y+3,0.5f,PN[k],BLK,0,1); for(int c=0;c<12;c++){ float x=290+c*26; gfx_rect(x-1,y-1,x+23,y+23,hit(a,x,y,x+22,y+22)?BLK:RGBA(120,120,120,255)); gfx_rect(x,y,x+22,y+22,RGBA(PAL[c][0],PAL[c][1],PAL[c][2],255)); if(hit(a,x,y,x+22,y+22)&&a->click){ memcpy(ac->col[k],PAL[c],3); snd(a,A_CLICK); if(!a->is_guest) save(a); } } }
      text(210,258,0.5f,"Hats (owned)",BLK,0,1); int n=0; for(int i=-1;i<NITEMS;i++){ if(i>=0&&!owned(ac,i)) continue; float x=210+(n%9)*46,y=278+(n/9)*46; if(n>=27) break; gfx_rect(x-1,y-1,x+43,y+43,(ac->hat==i)?RGBA(40,110,220,255):RGBA(150,150,150,255)); gfx_rect(x,y,x+42,y+42,W); if(i>=0) gfx_spr(CATALOG[i].spr,x+21,y+21,40,40,0,W); else text(x+21,y+10,0.4f,"None",BLK,1,0); if(hit(a,x,y,x+42,y+42)&&a->click){ ac->hat=i; snd(a,A_CLICK); if(!a->is_guest) save(a); } n++; } }
    if(button(a,30,340,190,372,"Done",GREEN,W,0.5f)) a->sc=SC_HOME; break;
  case SC_GAMES: navbar(a); text(30,46,0.7f,"Games",NAVY,0,1); { int per=6; int pages=(NMAPS+per-1)/per; for(int i=0;i<per;i++){ int m=a->page*per+i; if(m>=NMAPS) break; float x=24+(i%3)*204,y=84+(i/3)*150; int hv=hit(a,x,y,x+192,y+138); gfx_rect(x-2,y-2,x+194,y+140,hv?RGBA(40,110,220,255):RGBA(180,180,190,255)); gfx_rect(x,y,x+192,y+140,W); gfx_spr(MAPS[m].thumb,x+96,y+49,176,117,0,W); snprintf(b,sizeof b,"%.26s",MAPS[m].title); text(x+4,y+110,0.4f,b,RGBA(20,60,160,255),0,1); snprintf(b,sizeof b,"Created %d",MAPS[m].year); text(x+4,y+124,0.32f,b,RGBA(90,90,90,255),0,0);
      if(hv&&a->click){ a->sel_map=m; a->sc=SC_GAMEPAGE; snd(a,A_CLICK); } }
    if(button(a,230,384,290,414,"<",GRAY,BLK,0.6f)&&a->page>0) a->page--; snprintf(b,sizeof b,"Page %d / %d",a->page+1,pages); text(320,390,0.5f,b,BLK,1,1); if(button(a,350,384,410,414,">",GRAY,BLK,0.6f)&&a->page<pages-1) a->page++; } break;
  case SC_GAMEPAGE: navbar(a); { const MapInfo*m=&MAPS[a->sel_map]; text(30,46,0.7f,m->title,NAVY,0,1); gfx_rect(28,82,252,226,BLK); gfx_rect(30,84,250,224,W); gfx_spr(m->thumb,140,154,216,144,0,W);
    snprintf(b,sizeof b,"Created: %d   Parts: %d",m->year,m->nparts); text(30,236,0.42f,b,BLK,0,0); snprintf(b,sizeof b,"Scripts in original: %d (%d lines)",m->nscripts,m->script_lines); text(30,254,0.42f,b,RGBA(90,90,90,255),0,0); text(30,272,0.4f,g3_is_battle(m->title)?"Battle place: bots will fight you":"Bots will wander and help",RGBA(90,90,90,255),0,0);
    gfx_rect(276,82,624,330,RGBA(225,228,236,255)); slider(a,330,126,230,"BOTS",&a->bots,1,30); slider(a,330,206,230,"MULTIPLAYER",&a->players,1,4);
    text(330,240,0.38f,a->players==1?"1 player: one full screen":(a->players==2?"2 players: screen split in two":(a->players==3?"3 players: three-way split":"4 players: four-way split")),RGBA(70,70,70,255),0,0);
    if(button(a,330,272,560,318,"Play",GREEN,W,0.9f)){ start_play(a); } if(button(a,30,340,130,372,"Back",GRAY,BLK,0.5f)) a->sc=SC_GAMES; } break;
  case SC_CATALOG: navbar(a); text(30,46,0.7f,"Catalog - Hats",NAVY,0,1); { int per=12; int pages=(NITEMS+per-1)/per; for(int i=0;i<per;i++){ int it=a->page*per+i; if(it>=NITEMS) break; float x=24+(i%4)*152,y=82+(i/4)*100; int hv=hit(a,x,y,x+142,y+92); gfx_rect(x-1,y-1,x+143,y+93,hv?RGBA(40,110,220,255):RGBA(180,180,190,255)); gfx_rect(x,y,x+142,y+92,W); gfx_spr(CATALOG[it].spr,x+30,y+34,56,56,0,W);
      snprintf(b,sizeof b,"%.16s",CATALOG[it].name); text(x+60,y+4,0.34f,b,RGBA(20,60,160,255),0,1); if(owned(ac,it)&&!a->is_guest) text(x+60,y+30,0.4f,"OWNED",RGBA(30,140,30,255),0,1); else if(a->sv.economy){ snprintf(b,sizeof b,"R$ %d",CATALOG[it].robux); text(x+60,y+26,0.4f,b,RGBA(30,140,30,255),0,1); snprintf(b,sizeof b,"T$ %d",CATALOG[it].robux*10); text(x+60,y+44,0.4f,b,RGBA(190,130,10,255),0,1); } else text(x+60,y+30,0.4f,"FREE",RGBA(30,140,30,255),0,1);
      if(hv&&a->click&&!a->dlg){ a->sel_item=it; a->dlg=2; snd(a,A_CLICK); } }
    if(button(a,230,384,290,414,"<",GRAY,BLK,0.6f)&&a->page>0) a->page--; snprintf(b,sizeof b,"Page %d / %d",a->page+1,pages); text(320,390,0.5f,b,BLK,1,1); if(button(a,350,384,410,414,">",GRAY,BLK,0.6f)&&a->page<pages-1) a->page++; }
    if(a->dlg==2){ int it=a->sel_item; gfx_rect(0,0,640,448,RGBA(0,0,0,150)); gfx_rect(150,90,490,340,W); gfx_spr(CATALOG[it].spr,230,170,110,110,0,W); text(300,110,0.5f,CATALOG[it].name,BLK,0,1);
      if(a->is_guest){ text(320,250,0.45f,"Sign up to get items!",RED,1,1); } else if(owned(ac,it)){ text(300,150,0.5f,"You own this item.",RGBA(30,140,30,255),0,1); if(button(a,300,190,470,226,"Wear it",GREEN,W,0.5f)){ ac->hat=it; save(a); a->dlg=0; toast(a,"Equipped!"); } }
      else if(!a->sv.economy){ text(300,150,0.5f,"FREE",RGBA(30,140,30,255),0,1); if(button(a,300,190,470,226,"Get it free",GREEN,W,0.5f)){ ac->owned[it>>6]|=1ull<<(it&63); save(a); snd(a,A_PING); toast(a,"Added to your items"); } }
      else { int r=CATALOG[it].robux,t=r*10; snprintf(b,sizeof b,"Buy with R$ %d",r); if(button(a,300,150,470,184,b,ac->robux>=r?GREEN:RGBA(150,150,150,255),W,0.45f)&&ac->robux>=r){ ac->robux-=r; ac->owned[it>>6]|=1ull<<(it&63); save(a); snd(a,A_PING); toast(a,"Purchased with Robux!"); a->dlg=0; }
        snprintf(b,sizeof b,"Buy with T$ %d",t); if(button(a,300,192,470,226,b,ac->tix>=t?RGBA(200,140,20,255):RGBA(150,150,150,255),W,0.45f)&&ac->tix>=t){ ac->tix-=t; ac->owned[it>>6]|=1ull<<(it&63); save(a); snd(a,A_PING); toast(a,"Purchased with Tix!"); a->dlg=0; } }
      if(button(a,300,290,470,322,"Close",GRAY,BLK,0.5f)) a->dlg=0; } break;
  case SC_HELP: navbar(a); text(30,46,0.7f,"Help",NAVY,0,1); { static const char*H[]={"Left stick: walk (menus: move the mouse cursor)","Right stick: turn camera","X: jump (menus: click)    O: use item / attack","START: pause menu with Port Options","Square: Safe Chat    Triangle: camera zoom","L1/L2 and R1/R2: rotate inventory left / right","Settings: Robux-Tix ON/OFF, controls remap, music","Multiplayer 2-4: each player uses their own controller",0}; for(int i=0;H[i];i++) text(40,90+i*30,0.52f,H[i],BLK,0,0); } break;
  case SC_LOADING: gfx_rect(0,0,640,448,RGBA(30,34,44,255)); gfx_rect(200,60,440,120,RGBA(196,40,27,255)); text(320,66,1.5f,"ROBLOX",W,1,1); snprintf(b,sizeof b,"Now loading: %.28s",MAPS[a->sel_map].title); text(320,170,0.7f,b,W,1,1); snprintf(b,sizeof b,"%d bots - %d player%s",a->bots,a->players,a->players>1?"s":""); text(320,204,0.5f,b,RGBA(200,200,200,255),1,0); bar(170,300,470,314,a->load>1?1:a->load,RGBA(60,150,230,255)); text(320,324,0.4f,"Loading, please wait...",RGBA(180,180,180,255),1,0); break;
  case SC_PLAY: { Game3D*g=&a->g; for(int i=0;i<g->np;i++){ float x0,y0,x1,y1; g3_viewport(g->np,i,&x0,&y0,&x1,&y1); g3_render(g,i,x0,y0,x1,y1); gfx_viewport(0,0,640,448); hud(a,i,x0,y0,x1,y1); if(g->np>1){ gfx_rect(x0,y0,x1,y0+1,BLK); gfx_rect(x0,y0,x0+1,y1,BLK); } }
    if(a->safe_open){ gfx_rect(200,90,440,330,RGBA(0,0,0,190)); text(320,96,0.55f,"Safe Chat",W,1,1); static const char*S[8]={"HELLO!","GOOD GAME","THANKS","HELP!","FOLLOW ME","I WIN!","OOPS","BYE"}; for(int i=0;i<8;i++){ if(i==a->safe_sel) gfx_rect(210,124+i*24,430,146+i*24,RGBA(60,120,210,255)); text(320,126+i*24,0.45f,S[i],W,1,1); } }
    if(a->paused){ gfx_rect(0,0,640,448,RGBA(0,0,0,150)); gfx_rect(180,70,460,380,RGBA(35,40,55,245)); gfx_rect(180,70,460,76,RGBA(196,40,27,255));
      if(!a->popt){ text(320,86,0.8f,"Game Paused",W,1,1); if(button(a,210,130,430,172,"Resume",GREEN,W,0.7f)) a->paused=0; if(button(a,210,184,430,226,"Port Options",BLUE,W,0.7f)) a->popt=1; if(button(a,210,238,430,280,"Leave Game",RED,W,0.7f)){ a->sc=SC_GAMES; a->paused=0; } }
      else { text(320,80,0.7f,"Port Options",W,1,1); static const char*L[4]={"Jump","Use / Attack","Camera zoom","Safe Chat"}; for(int i=0;i<4;i++){ float y=116+i*40; text(200,y+4,0.5f,L[i],W,0,1); int id=a->sv.keymap[i]; int bi=0; for(int k=0;k<4;k++) if(BTNID[k]==id) bi=k; if(button(a,340,y,440,y+32,BTN[bi],RGBA(70,90,140,255),W,0.4f)){ int nb=(bi+1)%4; int other=-1; for(int j=0;j<4;j++) if(j!=i&&a->sv.keymap[j]==BTNID[nb]) other=j; if(other>=0) a->sv.keymap[other]=id; a->sv.keymap[i]=BTNID[nb]; save(a); } }
        if(button(a,200,284,440,316,a->sv.economy?"Robux-Tix: ON":"Robux-Tix: OFF",a->sv.economy?GREEN:RED,W,0.5f)){ a->sv.economy^=1; save(a); toast(a,a->sv.economy?"Paid content enabled":"Everything is free (no daily reward)"); } if(button(a,200,322,440,350,a->sv.music?"Music: ON":"Music: OFF",a->sv.music?GREEN:RED,W,0.45f)){ a->sv.music^=1; save(a); } if(button(a,330,354,440,378,"Back",GRAY,BLK,0.4f)) a->popt=0; } } } break; }
  if(a->toastt>0){ float w=tw(a->toast,0.5f,1)+24; gfx_rect(320-w/2,400,320+w/2,430,RGBA(20,20,20,220)); text(320,406,0.5f,a->toast,W,1,1); }
  { const Spr*c=&SPR[S_CURSOR]; float k=0.5f; gfx_spr(S_CURSOR,a->cx+c->ow*k/2,a->cy+c->oh*k/2,c->ow*k,c->oh*k,0,W); } gfx_end(); }
