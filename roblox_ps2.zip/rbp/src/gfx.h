#ifndef GFX_H
#define GFX_H
#define RGBA(r,g,b,a) (((unsigned)(r)<<24)|((unsigned)(g)<<16)|((unsigned)(b)<<8)|(unsigned)(a))
void gfx_begin(void); void gfx_end(void);
void gfx_spr(int spr,float cx,float cy,float w,float h,float rot,unsigned rgba);
void gfx_rect(float x0,float y0,float x1,float y1,unsigned rgba);
void gfx_tri(float x0,float y0,float x1,float y1,float x2,float y2,unsigned rgba);
void gfx_viewport(float x0,float y0,float x1,float y1);              /* clip rect for following draws; 0,0,640,448 = full */
void gfx_tri3(float x0,float y0,float z0,float x1,float y1,float z1,float x2,float y2,float z2,unsigned rgba); /* z: 0 near .. 1 far, depth tested */
void gfx_clear_depth(void);
#endif
