#ifndef APP_H
#define APP_H
#include "game3d.h"
enum { B_X,B_O,B_T,B_S,B_L1,B_R1,B_L2,B_R2,B_START,B_UP,B_DN,B_LF,B_RT,B_COUNT };
typedef struct { float lx,ly,rx,ry; unsigned held,pressed; int connected; } Pad;
typedef struct { char nick[16]; unsigned pw; int gender,month,day,year; int robux,tix; unsigned long long owned[2]; int hat; unsigned char col[4][3]; int last_day; int used; unsigned char played[8]; } Account;
typedef struct { unsigned magic; Account acc[4]; int cur; int economy, music; int keymap[4]; } SaveData;       /* keymap: jump, act, tri, safe -> button id */
typedef enum { SC_BOOT, SC_LANDING, SC_LOGIN, SC_REG1, SC_REG2, SC_HOME, SC_GAMES, SC_GAMEPAGE, SC_CATALOG, SC_AVATAR, SC_HELP, SC_LOADING, SC_PLAY } Screen;
typedef struct {
  Screen sc; float t; float cx,cy; SaveData sv; Account guest; int is_guest; int logged;
  char f1[16],f2[16]; int focus,shift,sym; int reg_gender,reg_m,reg_d,reg_y; int sel_acc;
  int page, sel_map, bots, players; int sel_item; int dlg; float load; int paused, popt, safe_open, safe_sel;
  Game3D g; PlayerIn in[MAXPL]; Pad pad[MAXPL]; char toast[40]; float toastt; int snd_out[16], nsnd_out; int want_music, click, quit_to_menu; int hold; float chatmenu; int zoomtog[MAXPL]; int dirty; char err[40];
} App;
void app_init(App*a); void app_update(App*a,const Pad*pads,float dt); void app_draw(App*a);
int plat_today(void); int plat_save_write(const void*d,int n); int plat_save_read(void*d,int n);
#endif
