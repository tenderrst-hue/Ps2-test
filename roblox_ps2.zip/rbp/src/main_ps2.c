/* Roblox 2012 - PS2 fan port: entry point. Up to 4 controllers (2 ports + multitap). */
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include <libmtap.h>
#include <string.h>
#include "app.h"
#include "audio.h"
#include "gfx_ps2.h"
extern const unsigned char maps_bin[];
static char padbuf[4][256] __attribute__((aligned(64))); static int pport[4],pslot[4],npad=0; static unsigned prevb[4];
static float axis(int v){ float f=(v-128)/128.f; if(f>-0.18f&&f<0.18f) return 0; return f>0?(f-0.18f)/0.82f:(f+0.18f)/0.82f; }
static const unsigned MAPB[B_COUNT]={PAD_CROSS,PAD_CIRCLE,PAD_TRIANGLE,PAD_SQUARE,PAD_L1,PAD_R1,PAD_L2,PAD_R2,PAD_START,PAD_UP,PAD_DOWN,PAD_LEFT,PAD_RIGHT};
int main(void){
  SifInitRpc(0); SifLoadModule("rom0:SIO2MAN",0,NULL); SifLoadModule("rom0:PADMAN",0,NULL); SifLoadModule("rom0:MTAPMAN",0,NULL); SifLoadModule("rom0:XMCMAN",0,NULL); SifLoadModule("rom0:XMCSERV",0,NULL);
  mtapInit(); mtapPortOpen(0); mtapPortOpen(1); padInit(0);
  for(int port=0;port<2;port++){ int slots=(mtapGetConnection(port)==1)?mtapGetSlotNumber(port):1; for(int s=0;s<slots&&npad<4;s++){ pport[npad]=port; pslot[npad]=s; padPortOpen(port,s,padbuf[npad]); npad++; } }
  { int t=0; while(t<200000&&padGetState(pport[0],pslot[0])!=PAD_STATE_STABLE&&padGetState(pport[0],pslot[0])!=PAD_STATE_FINDCTP1) t++; }
  for(int i=0;i<npad;i++) padSetMainMode(pport[i],pslot[i],PAD_MMODE_DUALSHOCK,PAD_MMODE_LOCK);
  maps_data=maps_bin; gfx_ps2_init(); audio_init();
  static App app; app_init(&app); float dt=gfx_ps2_is_pal()?1.f/50.f:1.f/60.f; int music=-2; Pad pads[MAXPL];
  for(;;){
    memset(pads,0,sizeof pads);
    for(int i=0;i<npad&&i<MAXPL;i++){ struct padButtonStatus b; if(padGetState(pport[i],pslot[i])==PAD_STATE_STABLE&&padRead(pport[i],pslot[i],&b)){ unsigned now=0xffff^b.btns,edge=now&~prevb[i]; prevb[i]=now; Pad*p=&pads[i]; p->connected=1;
        p->lx=axis(b.ljoy_h); p->ly=axis(b.ljoy_v); p->rx=axis(b.rjoy_h); p->ry=axis(b.rjoy_v); for(int k=0;k<B_COUNT;k++){ if(now&MAPB[k]) p->held|=1u<<k; if(edge&MAPB[k]) p->pressed|=1u<<k; } } }
    app_update(&app,pads,dt); for(int i=0;i<app.nsnd_out;i++) audio_sfx(app.snd_out[i]); if(app.want_music!=music){ music=app.want_music; audio_music(music); }
    app_draw(&app); audio_update(); }
  return 0; }
