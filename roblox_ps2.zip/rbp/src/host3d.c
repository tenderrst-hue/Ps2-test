/* headless 3D test: load every map, walk, jump, bots, split screen budget */
#include "game3d.h"
#include "catalog.h"
#include "gfx.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
static long ntri;
void gfx_begin(void){} void gfx_end(void){} void gfx_spr(int a,float b,float c,float d,float e,float f,unsigned g){} void gfx_rect(float a,float b,float c,float d,unsigned e){} void gfx_tri(float a,float b,float c,float d,float e,float f,unsigned g){} void gfx_viewport(float a,float b,float c,float d){} void gfx_clear_depth(void){}
void gfx_tri3(float a,float b,float c,float d,float e,float f,float g,float h,float i,unsigned j){ ntri++; }
int main(){ FILE*f=fopen("../data/maps.bin","rb"); fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET); unsigned char*buf=malloc(n); fread(buf,1,n,f); maps_data=buf;
  int bad=0; static Game3D G;
  for(int m=0;m<NMAPS;m++){ g3_load(&G,m,2,10); PlayerIn in[4]={{0}}; in[0].zoom=in[1].zoom=14; in[0].my=0;
    float y0=G.p[0].c.y; int stuck=0; for(int s=0;s<60*4;s++){ if(s==120) in[0].jump=1; else in[0].jump=0; g3_step(&G,in,1/60.f); }
    int fell=G.p[0].c.y<G.m.bmin[1]-50; int nan=isnan(G.p[0].c.x)||isnan(G.p[0].c.y);
    ntri=0; clock_t t0=clock(); for(int v=0;v<2;v++){ float a,b,c,d; g3_viewport(2,v,&a,&b,&c,&d); g3_render(&G,v,a,b,c,d); } double ms=(clock()-t0)*1000.0/CLOCKS_PER_SEC;
    printf("%2d %-42s parts %4d  spawn y=%.1f -> y=%.1f hp=%.0f alive=%d  tris(2 views)=%ld render=%.1fms%s%s\n",m,MAPS[m].title,G.m.n,y0,G.p[0].c.y,G.p[0].c.hp,G.p[0].c.alive,ntri,ms,fell?"  FELL":"",nan?"  NAN":""); if(fell||nan) bad++; }
  printf("maps with problems: %d\n",bad);
  /* 30 bots on a battle map */
  g3_load(&G,2,4,30); PlayerIn in[4]={{0}}; for(int i=0;i<4;i++) in[i].zoom=14; clock_t t0=clock(); for(int s=0;s<600;s++) g3_step(&G,in,1/60.f); printf("30 bots + 4 players: 600 steps = %.0f ms (%.2f ms/step)\n",(clock()-t0)*1000.0/CLOCKS_PER_SEC,(clock()-t0)*1000.0/CLOCKS_PER_SEC/600);
  int alive=0; for(int i=0;i<30;i++) alive+=G.b[i].c.alive; printf("bots alive after 10s: %d/30 battle=%d\n",alive,G.battle); return bad?1:0; }
