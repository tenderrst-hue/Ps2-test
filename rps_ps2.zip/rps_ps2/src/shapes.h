#ifndef SHAPES_H
#define SHAPES_H
typedef struct { signed char x0,y0,x1,y1; unsigned char col; } SRect;   /* 32x32 grid; col 0 main,1 shade,2 accent */
extern const SRect *SHAPE[3]; extern const int SHAPE_N[3];
extern const SRect ROBOT_EXTRA[]; extern const int ROBOT_EXTRA_N;
#endif
