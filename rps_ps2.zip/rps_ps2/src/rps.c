#include "rps.h"
#include <string.h>
void rps_init(Rps*r){ memset(r,0,sizeof*r); r->ph=S_TITLE; r->rng=0xC0FFEEu; }
static Gesture rnd3(Rps*r){ r->rng=r->rng*1664525u+1013904223u; return (Gesture)((r->rng>>16)%3); }
Result rps_judge(Gesture p, Gesture b){ if(p==b) return R_DRAW; return ((p-b+3)%3==1)?R_PLAYER:R_BOT; }
int rps_word(float t){ int w=(int)(t/BEAT); return w>3?3:w; }
Result rps_final(const Rps*r){ return r->score_p==r->score_b?R_DRAW:(r->score_p>r->score_b?R_PLAYER:R_BOT); }
void rps_update(Rps*r, const Input*in, float dt){
  r->seedctr++;                                  /* player timing feeds the RNG */
  switch(r->ph){
  case S_TITLE:
    if(in->confirm){ r->score_p=r->score_b=0; r->round=0; r->cursor=0; r->rng^=r->seedctr*2654435761u; r->ph=S_PICK; } break;
  case S_PICK:
    if(in->left)  r->cursor=(r->cursor+2)%3;
    if(in->right) r->cursor=(r->cursor+1)%3;
    if(in->confirm){ r->rng+=r->seedctr*7919u; r->pl=(Gesture)r->cursor; r->bot=rnd3(r); r->t=0; r->ph=S_COUNT; } break;
  case S_COUNT:
    r->t+=dt; if(r->t>=COUNT_TIME){ r->res=rps_judge(r->pl,r->bot);
      if(r->res==R_PLAYER) r->score_p++; else if(r->res==R_BOT) r->score_b++; r->t=0; r->ph=S_REVEAL; } break;
  case S_REVEAL:
    r->t+=dt; if(r->t>=REVEAL_TIME){ r->round++; r->t=0; r->ph=(r->round>=ROUNDS)?S_FINAL:S_PICK; } break;
  case S_FINAL:
    r->t+=dt; if(in->confirm) r->ph=S_TITLE; break;
  }
}
