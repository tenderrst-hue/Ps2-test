#ifndef RPS_H
#define RPS_H
typedef enum { G_ROCK=0, G_PAPER=1, G_SCISSORS=2 } Gesture;
typedef enum { S_TITLE, S_PICK, S_COUNT, S_REVEAL, S_FINAL } Phase;
typedef enum { R_DRAW, R_PLAYER, R_BOT } Result;
typedef struct { int left, right, confirm; } Input;          /* one-frame button edges */
typedef struct { Phase ph; int round; int cursor; Gesture pl, bot; Result res;
                 int score_p, score_b; float t; unsigned rng, seedctr; } Rps;
#define ROUNDS 3
#define BEAT 0.6f
#define COUNT_TIME 2.6f
#define REVEAL_TIME 2.2f
void   rps_init(Rps*r);
void   rps_update(Rps*r, const Input*in, float dt);
Result rps_judge(Gesture p, Gesture b);
int    rps_word(float t);                    /* 0 ROCK, 1 PAPER, 2 SCISSORS, 3 SHOOT */
Result rps_final(const Rps*r);               /* overall winner after 3 rounds */
#endif
