#include "scene.h"
#include "gfx.h"
#include "shapes.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
static const unsigned char FONT[39][7]={
{0x0E,0x11,0x11,0x1F,0x11,0x11,0x11},{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E},{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E},{0x1E,0x11,0x11,0x11,0x11,0x11,0x1E},
{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F},{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10},{0x0E,0x11,0x10,0x17,0x11,0x11,0x0F},{0x11,0x11,0x11,0x1F,0x11,0x11,0x11},
{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E},{0x07,0x02,0x02,0x02,0x02,0x12,0x0C},{0x11,0x12,0x14,0x18,0x14,0x12,0x11},{0x10,0x10,0x10,0x10,0x10,0x10,0x1F},
{0x11,0x1B,0x15,0x15,0x11,0x11,0x11},{0x11,0x11,0x19,0x15,0x13,0x11,0x11},{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E},{0x1E,0x11,0x11,0x1E,0x10,0x10,0x10},
{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D},{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11},{0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E},{0x1F,0x04,0x04,0x04,0x04,0x04,0x04},
{0x11,0x11,0x11,0x11,0x11,0x11,0x0E},{0x11,0x11,0x11,0x11,0x11,0x0A,0x04},{0x11,0x11,0x11,0x15,0x15,0x15,0x0A},{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11},
{0x11,0x11,0x0A,0x04,0x04,0x04,0x04},{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F},
{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},{0x1F,0x02,0x04,0x02,0x01,0x11,0x0E},
{0,0,0,0,0,0,0},{0x04,0x04,0x04,0x04,0x04,0x00,0x04},{0x00,0x04,0x00,0x00,0x00,0x04,0x00},{0,0,0,0x1F,0,0,0}};
static const unsigned char *glyph(char c){ if(c>='A'&&c<='Z')return FONT[c-'A']; if(c>='0'&&c<='3')return FONT[26+c-'0']; if(c=='!')return FONT[31]; if(c==':')return FONT[32]; if(c=='-')return FONT[33]; return FONT[30]; }
static void text(int x,int y,int sc,const char*s,unsigned col){
  for(;*s;s++,x+=6*sc){ const unsigned char*g=glyph(*s);
    for(int ry=0;ry<7;ry++){ int cx=0; while(cx<5){ if(g[ry]&(0x10>>cx)){ int e=cx; while(e<5&&(g[ry]&(0x10>>e)))e++; gfx_rect(x+cx*sc,y+ry*sc,x+e*sc,y+(ry+1)*sc,col); cx=e; } else cx++; } } } }
static int tw(const char*s,int sc){ return (int)strlen(s)*6*sc-sc; }
static void textc(int cx,int y,int sc,const char*s,unsigned col){ int w=tw(s,sc); text(cx-w/2+sc/2,y,sc,s,col); text(0,0,0,"",0); }
static void textc_sh(int cx,int y,int sc,const char*s,unsigned col){ textc(cx+sc,y+sc,sc,s,0x101020); textc(cx,y,sc,s,col); }
static const unsigned PAL[2][4]={{0xF0C498,0xC88C64,0xFFE1C8,0x462319},{0xA0AAB9,0x697382,0xE62828,0x141923}};
static void shape(int x,int y,int sc,int g,int robot,int flip){
  const SRect*S=SHAPE[g]; int n=SHAPE_N[g];
  for(int pass=0;pass<2;pass++) for(int i=0;i<n+(robot&&pass?ROBOT_EXTRA_N:0);i++){
    const SRect*r=i<n?&S[i]:&ROBOT_EXTRA[i-n]; int x0=flip?32-r->x1:r->x0, x1=flip?32-r->x0:r->x1;
    if(pass==0){ if(r->col==0&&i<n) gfx_rect(x+(x0-1)*sc,y+(r->y0-1)*sc,x+(x1+1)*sc,y+(r->y1+1)*sc,PAL[robot][3]); }
    else gfx_rect(x+x0*sc,y+r->y0*sc,x+x1*sc,y+r->y1*sc,PAL[robot][r->col]); } }
static float bump(float t){ float p=fmodf(t,BEAT)/BEAT; return p<0.2f?p/0.2f:(p<0.45f?1-(p-0.2f)/0.25f:0); }
static const char*WORDS[4]={"ROCK","PAPER","SCISSORS","SHOOT!"}; static const char*NAMES[3]={"ROCK","PAPER","SCISSORS"};
void scene_draw(const Rps*r){
  gfx_rect(0,0,320,224,0x1B1F3B); gfx_rect(0,0,320,50,0x232A52); gfx_rect(0,50,320,90,0x2B3566); gfx_rect(0,90,320,136,0x34417C);
  for(int i=0;i<20;i++) gfx_rect(i*16,136,i*16+16,142,(i&1)?0x4A4A5C:0x3C3C4E);
  gfx_rect(0,142,320,224,0x14162B);
  char b[32];
  if(r->ph==S_TITLE){
    textc_sh(160,18,3,"ROCK PAPER",0xFFD84A); textc_sh(160,44,3,"SCISSORS",0xFFD84A);
    shape(40,70,2,0,0,0); shape(216,70,2,0,1,1);
    textc_sh(160,100,1,"HUMAN VS ROBOT",0xFFFFFF);
    textc_sh(160,170,2,"3 ROUNDS",0x8AE6FF);
    if(((r->seedctr/30)&1)==0){ textc_sh(160,196,2,"PRESS X",0xFFFFFF); } return; }
  int pg=G_ROCK, bg_=G_ROCK, dxo=0, dyo=0, shake=0;
  if(r->ph==S_COUNT){ float k=bump(r->t); dyo=(int)(k*14); dxo=(int)(k*8); if(r->t>=BEAT*3+0.3f){ dyo=0;dxo=0;} }
  if(r->ph==S_REVEAL){ pg=r->pl; bg_=r->bot; shake=(r->t<0.3f)?((int)(r->t*60)&1)*2:0; }
  shape(34+dxo,34+dyo+shake,3,pg,0,0); shape(190-dxo,34+dyo-shake,3,bg_,1,1);
  snprintf(b,sizeof b,"YOU %d",r->score_p); text(6,6,2,b,0x8AE6FF);
  snprintf(b,sizeof b,"BOT %d",r->score_b); text(314-tw(b,2),6,2,b,0xFF7070);
  if(r->ph!=S_FINAL){ snprintf(b,sizeof b,"ROUND %d",(r->round<ROUNDS?r->round:ROUNDS-1)+1); textc_sh(160,6,1,b,0xFFFFFF); }
  if(r->ph==S_COUNT){ textc_sh(160,24,2,WORDS[rps_word(r->t)],0xFFD84A); }
  if(r->ph==S_REVEAL){ const char*m=r->res==R_DRAW?"DRAW!":(r->res==R_PLAYER?"YOU WIN!":"BOT WINS!"); unsigned c=r->res==R_DRAW?0xFFFFFF:(r->res==R_PLAYER?0x6CFF6C:0xFF6060); textc_sh(160,24,2,m,c); }
  if(r->ph==S_PICK) textc_sh(160,24,1,"PICK YOUR MOVE",0xFFD84A);
  if(r->ph==S_FINAL){
    const char*m=rps_final(r)==R_DRAW?"DRAW!":(rps_final(r)==R_PLAYER?"YOU WIN!":"BOT WINS!"); unsigned c=rps_final(r)==R_DRAW?0xFFFFFF:(rps_final(r)==R_PLAYER?0x6CFF6C:0xFF6060);
    gfx_rect(40,20,280,128,0x0B0D1E); gfx_rect(42,22,278,126,0x20264D);
    textc_sh(160,40,3,m,c); snprintf(b,sizeof b,"%d - %d",r->score_p,r->score_b); textc_sh(160,78,3,b,0xFFFFFF);
    if(((r->seedctr/30)&1)==0) textc_sh(160,108,1,"PRESS X TO PLAY AGAIN",0xFFD84A); }
  for(int i=0;i<3;i++){ int bx=44+i*82, by=141; int sel=(r->ph==S_PICK&&r->cursor==i), locked=(r->ph!=S_PICK&&r->pl==i);
    unsigned fc=locked?0x6CFF6C:(sel?0xFFD84A:0x4A5080); int th=(sel||locked)?3:1;
    gfx_rect(bx-th,by-th,bx+68+th,by+68+th,fc); gfx_rect(bx,by,bx+68,by+68,0x20264D);
    shape(bx+2,by+2,2,i,0,0); textc_sh(bx+34,by+71,1,NAMES[i],(sel||locked)?0xFFFFFF:0x9098C0); }
}
