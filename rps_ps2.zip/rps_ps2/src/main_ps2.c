/* Rock Paper Scissors - runs natively on PS2 (EE). Build: see README. */
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include <string.h>
#include "rps.h"
#include "scene.h"
#include "gfx_ps2.h"
static char padbuf[256] __attribute__((aligned(64)));
int main(void){
  SifInitRpc(0);
  SifLoadModule("rom0:SIO2MAN", 0, NULL);
  SifLoadModule("rom0:PADMAN", 0, NULL);
  padInit(0); padPortOpen(0, 0, padbuf);
  while(padGetState(0,0) != PAD_STATE_STABLE && padGetState(0,0) != PAD_STATE_FINDCTP1) ;
  gfx_ps2_init();
  float dt = gfx_ps2_is_pal() ? 1.0f/50.0f : 1.0f/60.0f;
  Rps game; rps_init(&game);
  unsigned prev = 0;
  for(;;){
    Input in; memset(&in, 0, sizeof in);
    struct padButtonStatus b;
    if(padGetState(0,0) == PAD_STATE_STABLE && padRead(0,0,&b)){
      unsigned now = 0xffff ^ b.btns, edge = now & ~prev; prev = now;
      in.left = (edge & PAD_LEFT) != 0; in.right = (edge & PAD_RIGHT) != 0;
      in.confirm = (edge & (PAD_CROSS | PAD_START)) != 0;
    }
    rps_update(&game, &in, dt);
    gfx_ps2_begin(); scene_draw(&game); gfx_ps2_end();
  }
  return 0;
}
