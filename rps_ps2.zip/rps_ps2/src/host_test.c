#include "rps.h"
#include "scene.h"
#include "shapes.h"
#include <stdio.h>
#include <stdlib.h>
void dump(const char*p);
static void step(Rps*r,Input in,int frames){ for(int i=0;i<frames;i++){ rps_update(r,&in,1/60.f); in=(Input){0}; } }
int main(void){
  /* 1. judge table */
  int exp[3][3]={{R_DRAW,R_BOT,R_PLAYER},{R_PLAYER,R_DRAW,R_BOT},{R_BOT,R_PLAYER,R_DRAW}};   /* [player][bot] */
  for(int p=0;p<3;p++)for(int b=0;b<3;b++) if(rps_judge(p,b)!=exp[p][b]){printf("judge fail %d %d\n",p,b);return 1;}
  /* 2. shapes inside 32x32 */
  for(int g=0;g<3;g++)for(int i=0;i<SHAPE_N[g];i++){const SRect*s=&SHAPE[g][i]; if(s->x0<1||s->y0<1||s->x1>31||s->y1>32||s->x0>=s->x1||s->y0>=s->y1){printf("bad rect g%d i%d\n",g,i);return 1;}}
  /* 3. full-game simulation with random humans */
  int pickc[3]={0},games=0,w=0,l=0,d=0; srand(7);
  for(int n=0;n<4000;n++){ Rps r; rps_init(&r); r.seedctr=rand(); int rounds=0, frames=0;
    step(&r,(Input){0,0,1},1); if(r.ph!=S_PICK){puts("start fail");return 1;}
    while(r.ph!=S_FINAL && frames<60*60){ Input in={0}; int ph=r.ph;
      if(ph==S_PICK){ int k=rand()%4; in.left=k==0; in.right=k==1; in.confirm=k>=2; }
      rps_update(&r,&in,1/60.f); frames++;
      if(ph==S_COUNT&&r.ph==S_REVEAL){ rounds++; pickc[r.bot]++;
        if(r.res!=rps_judge(r.pl,r.bot)){puts("result mismatch");return 1;} }
      if(r.cursor<0||r.cursor>2){puts("cursor oob");return 1;} }
    if(r.ph!=S_FINAL||rounds!=ROUNDS||r.round!=ROUNDS||r.score_p+r.score_b>ROUNDS){printf("flow fail ph=%d rounds=%d\n",r.ph,rounds);return 1;}
    Result f=rps_final(&r); if(f==R_PLAYER)w++; else if(f==R_BOT)l++; else d++; games++;
    step(&r,(Input){0,0,1},1); if(r.ph!=S_TITLE){puts("restart fail");return 1;} }
  int tot=pickc[0]+pickc[1]+pickc[2]; printf("games=%d  player=%d bot=%d draw=%d | bot picks R/P/S = %.1f%% %.1f%% %.1f%%\n",games,w,l,d,100.*pickc[0]/tot,100.*pickc[1]/tot,100.*pickc[2]/tot);
  for(int g=0;g<3;g++) if(pickc[g]*100.0/tot<30||pickc[g]*100.0/tot>37){puts("bot not uniform");return 1;}
  /* 4. render sample frames */
  Rps r; rps_init(&r); scene_draw(&r); dump("f_title.ppm");
  step(&r,(Input){0,0,1},1); step(&r,(Input){0,1,0},1); scene_draw(&r); dump("f_pick.ppm");
  step(&r,(Input){0,0,1},1); step(&r,(Input){0},40); scene_draw(&r); dump("f_count.ppm");
  step(&r,(Input){0},60*2); scene_draw(&r); dump("f_reveal.ppm");
  r.pl=G_PAPER; r.bot=G_ROCK; r.res=R_PLAYER; scene_draw(&r); dump("f_reveal2.ppm");
  r.pl=G_SCISSORS; r.bot=G_PAPER; scene_draw(&r); dump("f_reveal3.ppm");
  r.ph=S_FINAL; r.score_p=2; r.score_b=1; scene_draw(&r); dump("f_final.ppm");
  puts("ALL TESTS PASSED"); return 0; }
