#include "gfx.h"
#include <stdio.h>
unsigned FB[224][320];
void gfx_rect(int x0,int y0,int x1,int y1,unsigned rgb){ if(x0<0)x0=0; if(y0<0)y0=0; if(x1>320)x1=320; if(y1>224)y1=224; for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++)FB[y][x]=rgb; }
void dump(const char*p){ FILE*f=fopen(p,"wb"); fprintf(f,"P6\n320 224\n255\n"); for(int y=0;y<224;y++)for(int x=0;x<320;x++){unsigned c=FB[y][x]; fputc(c>>16,f);fputc((c>>8)&255,f);fputc(c&255,f);} fclose(f); }
