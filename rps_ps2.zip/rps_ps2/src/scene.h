#ifndef SCENE_H
#define SCENE_H
#include "rps.h"
void scene_draw(const Rps*r);
#endif
