#ifndef GFX_H
#define GFX_H
void gfx_rect(int x0,int y0,int x1,int y1,unsigned rgb);   /* logical 320x224 pixels */
#endif
