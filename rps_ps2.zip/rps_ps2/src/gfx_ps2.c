/* PS2 backend: draws the 320x224 logical screen as 2x2 blocks with gsKit */
#include <kernel.h>
#include <gsKit.h>
#include <dmaKit.h>
#include "gfx.h"
#include "gfx_ps2.h"
static GSGLOBAL *gs; static int F=2, offy=0;
void gfx_ps2_init(void){
  gs = gsKit_init_global();
  gs->DoubleBuffering = GS_SETTING_ON; gs->ZBuffering = GS_SETTING_OFF; gs->PrimAlphaEnable = GS_SETTING_OFF;
  dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC, D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1<<DMA_CHANNEL_GIF);
  dmaKit_chan_init(DMA_CHANNEL_GIF);
  gsKit_init_screen(gs); gsKit_mode_switch(gs, GS_ONESHOT);
  F = gs->Width/320; if(F<1) F=1; offy = (gs->Height - 224*F)/2; if(offy<0) offy=0;
}
int gfx_ps2_is_pal(void){ return gs->Mode == GS_MODE_PAL; }
void gfx_ps2_begin(void){ gsKit_clear(gs, GS_SETREG_RGBAQ(0,0,0,0x80,0x00)); }
void gfx_ps2_end(void){ gsKit_queue_exec(gs); gsKit_sync_flip(gs); }
void gfx_rect(int x0,int y0,int x1,int y1,unsigned rgb){
  if(x1<=x0||y1<=y0) return;
  gsKit_prim_sprite(gs, x0*F, y0*F+offy, x1*F, y1*F+offy, 1, GS_SETREG_RGBAQ((rgb>>16)&255,(rgb>>8)&255,rgb&255,0x80,0x00));
}
