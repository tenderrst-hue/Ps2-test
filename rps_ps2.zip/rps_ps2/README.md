# Rock Paper Scissors for PlayStation 2 (native EE homebrew)
Human hand vs robot hand, 3 rounds, bot picks at random. Controls: D-pad L/R choose, X (or START) confirm.
## Build the ELF (no setup besides Docker)
    docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest make      -> RPS.ELF
Or push this folder to GitHub: the included workflow builds RPS.ELF and attaches it as an artifact.
## Run
PCSX2 (needs a PS2 BIOS): System > Run ELF.  Real PS2: via uLaunchELF / PS2Link / FreeMCBoot.
## Host test (logic + software render to PPM, no PS2 needed)
    cd src && gcc -O2 rps.c shapes.c scene.c gfx_host.c host_test.c -lm -o t && ./t
## Notes
All art is drawn from code (rect lists in shapes.c, 5x7 font in scene.c) - no external assets to load.
