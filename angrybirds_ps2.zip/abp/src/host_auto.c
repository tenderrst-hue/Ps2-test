#include "game.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
static World W,T;
static void shoot(World*w,int ang,int pl){ Pad p={0}; float a=ang*3.14159f/180; p.pressed=1; p.lx=-cosf(a)*pl/115.f; p.ly=sinf(a)*pl/115.f; world_control(w,&p,0,0,1,1/60.f); p.pressed=0; p.released=1; world_control(w,&p,0,0,1,1/60.f); }
static void settle(World*w){ Pad p={0}; for(int s=0;s<60*16&&w->ps!=PS_AIM&&w->ps!=PS_WON&&w->ps!=PS_LOST;s++){ world_step(w,1/60.f); world_control(w,&p,0,0,1,1/60.f); } }
int main(int argc,char**argv){ int won=0; int only=argc>1?atoi(argv[1]):-1;
  for(int lv=0;lv<NLEVELS;lv++){ if(only>=0&&lv!=only) continue; world_load(&W,lv); int shots=0;
    while(W.ps==PS_AIM&&shots<8){ int bs=-1,ba=0,bp=0; for(int ang=0;ang<=70;ang+=2) for(int pl=70;pl<=115;pl+=15){ T=W; shoot(&T,ang,pl); settle(&T); int sc=T.score+(T.pigs0-T.pigs)*100; if(T.ps==PS_WON) sc+=999999; if(sc>bs){bs=sc;ba=ang;bp=pl;} }
      shoot(&W,ba,bp); settle(&W); shots++; if(W.ps==PS_WON||W.ps==PS_LOST) break; }
    printf("L%02d %s  shots=%d pigs left=%d/%d score=%d stars=%d (max %d)\n",lv+1,W.ps==PS_WON?"WON ":"lost",shots,W.pigs,W.pigs0,W.score,W.stars,W.maxscore); if(W.ps==PS_WON) won++; fflush(stdout); }
  printf("won %d levels by greedy no-ability autoplay\n",won); return 0; }
