#include "gfx.h"
#include <stdio.h>
FILE*gfx_out;
void gfx_begin(void){ if(gfx_out) fprintf(gfx_out,"F\n"); } void gfx_end(void){}
void gfx_spr(int s,float cx,float cy,float w,float h,float r,unsigned c){ if(gfx_out) fprintf(gfx_out,"S %d %.2f %.2f %.2f %.2f %.4f %08x\n",s,cx,cy,w,h,r,c); }
void gfx_rect(float a,float b,float c2,float d,unsigned c){ if(gfx_out) fprintf(gfx_out,"R %.2f %.2f %.2f %.2f %08x\n",a,b,c2,d,c); }
void gfx_tri(float a,float b,float c2,float d,float e,float f,unsigned c){ if(gfx_out) fprintf(gfx_out,"T %.2f %.2f %.2f %.2f %.2f %.2f %08x\n",a,b,c2,d,e,f,c); }
