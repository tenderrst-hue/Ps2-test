/* headless demo: scripted play-through that dumps draw lists for the preview renderer */
#include "app.h"
#include <stdio.h>
#include <math.h>
extern FILE*gfx_out;
static App A; static Pad P0;
static void run(float sec,Pad p){ for(int i=0;i<(int)(sec*60);i++){ app_update(&A,&p,1/60.f); p.pressed=p.released=0; } }
static void frame(const char*name){ fprintf(gfx_out,"N %s\n",name); app_draw(&A); }
static Pad tap(void){ Pad p=P0; p.pressed=1; return p; }
static void at(float x,float y){ A.cx=x; A.cy=y; }
static int try_shot(int lv,int ang,int pl){ static World W; world_load(&W,lv); Pad p={0}; float a=ang*3.14159f/180; p.pressed=1; p.lx=-cosf(a)*pl/115.f; p.ly=sinf(a)*pl/115.f; world_control(&W,&p,0,0,1,1/60.f); p.pressed=0; p.released=1; world_control(&W,&p,0,0,1,1/60.f); p.released=0;
  for(int s=0;s<60*14&&W.ps!=PS_AIM&&W.ps!=PS_WON&&W.ps!=PS_LOST;s++){ world_step(&W,1/60.f); world_control(&W,&p,0,0,1,1/60.f); } return W.pigs0-W.pigs; }
int main(int argc,char**argv){
  gfx_out=fopen(argc>1?argv[1]:"frames.txt","w"); app_init(&A);
  A.cx=320; A.cy=224; run(0.2f,P0); frame("splash"); run(3.2f,P0); frame("menu");
  at(320,385); run(0.1f,tap()); run(0.2f,P0); frame("episodes");
  at(62,205); run(0.1f,tap()); run(0.2f,P0); at(250,250); frame("levels");
  A.stars[0]=3; A.stars[1]=2; A.stars[2]=1;
  at(44,414); run(0.1f,tap()); run(0.1f,P0); at(44,414); run(0.1f,tap()); run(0.1f,P0);          /* levels -> episodes -> menu */
  at(48,400); run(0.1f,tap()); run(0.1f,P0); at(250,240); frame("settings");                       /* menu -> settings */
  A.ctrl_alt=0; at(300,315); run(0.1f,tap()); run(0.1f,P0); at(320,200); frame("credits0"); run(0.1f,tap()); run(0.5f,P0); A.credit_y=330; run(0.1f,P0); frame("credits_mid"); A.credit_y=760; run(0.1f,P0); frame("credits_egg");
  /* level 1: find a winning shot, then play it with the mouse scheme */
  int ba=0,bp=0,bk=-1; for(int ang=0;ang<=60;ang+=1) for(int pl=70;pl<=115;pl+=5){ int k=try_shot(0,ang,pl); if(k>bk){bk=k;ba=ang;bp=pl;} }
  fprintf(stderr,"L1 best shot: angle %d pull %d killed %d\n",ba,bp,bk);
  A.sc=SC_LEVELS; A.mountains_on=1; at(120,120); run(0.1f,tap()); run(0.2f,P0); frame("level_start");
  { World*w=&A.w; float rx,ry; world_to_screen(w,0,143,&rx,&ry); at(rx,ry); run(0.05f,P0); run(0.05f,tap());
    float a=ba*3.14159f/180; float tx,ty; world_to_screen(w,-cosf(a)*bp,143-sinf(a)*bp,&tx,&ty); for(int i=0;i<30;i++){ A.cx+=(tx-A.cx)*0.2f; A.cy+=(ty-A.cy)*0.2f; Pad p=P0; app_update(&A,&p,1/60.f); }
    Pad d=P0; d.down=1; for(int i=0;i<4;i++){ at(tx,ty); app_update(&A,&d,1/60.f); } frame("aim"); Pad r=P0; r.released=1; at(tx,ty); app_update(&A,&r,1/60.f); run(0.55f,P0); frame("flight"); run(1.0f,P0); frame("impact"); }
  for(int i=0;i<60*14&&A.w.ps!=PS_WON&&A.w.ps!=PS_LOST;i++) run(1/60.f,P0); run(1.5f,P0); frame("result");
  fprintf(stderr,"result ps=%d stars=%d score=%d\n",A.w.ps,A.w.stars,A.w.score);
  /* a bigger level for the screenshot */
  A.sc=SC_PLAY; world_load(&A.w,9); A.w.cam.camx=500; A.w.cam.zoom=0.5f; run(0.1f,P0); A.w.cam.camx=420; frame("level10");
  fclose(gfx_out); return 0; }
