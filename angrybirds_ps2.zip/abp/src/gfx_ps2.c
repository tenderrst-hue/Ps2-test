/* PS2 renderer (gsKit): 640x448 logical screen, 8-bit CLUT atlases in VRAM, bilinear filtering, alpha blending */
#include <kernel.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include <gsKit.h>
#include <dmaKit.h>
#include "gfx.h"
#include "assets.h"
#include "gfx_ps2.h"
extern unsigned char tex_blk[], tex_chr[], tex_ui[], tex_bg[], tex_spl[], tex_fnt[];
static unsigned char*TEXDATA[NATLAS]={tex_blk,tex_chr,tex_ui,tex_bg,tex_spl,tex_fnt};
static const int TEXORDER[NATLAS]={0,1,2,3,4,5};
static GSGLOBAL*gs; static GSTEXTURE tex[NATLAS]; static float FX=1.f,FY=1.f;
void gfx_ps2_init(void){
  gs=gsKit_init_global(); gs->PSM=GS_PSM_CT16; gs->PSMZ=GS_PSMZ_16; gs->DoubleBuffering=GS_SETTING_ON; gs->ZBuffering=GS_SETTING_OFF; gs->PrimAlphaEnable=GS_SETTING_ON;
  dmaKit_init(D_CTRL_RELE_OFF,D_CTRL_MFD_OFF,D_CTRL_STS_UNSPEC,D_CTRL_STD_OFF,D_CTRL_RCYC_8,1<<DMA_CHANNEL_GIF);
  dmaKit_chan_init(DMA_CHANNEL_GIF); gsKit_init_screen(gs); gsKit_mode_switch(gs,GS_ONESHOT);
  gsKit_set_primalpha(gs,GS_SETREG_ALPHA(0,1,0,1,0),0);
  FX=gs->Width/640.f; FY=gs->Height/448.f;
  for(int i=0;i<NATLAS;i++){ int a=TEXORDER[i]; int w=ATLAS_W[a],h=ATLAS_H[a]; unsigned char*buf=(unsigned char*)memalign(128,1024+w*h); memcpy(buf,TEXDATA[a],1024+w*h);
    GSTEXTURE*t=&tex[a]; memset(t,0,sizeof*t); t->Width=w; t->Height=h; t->PSM=GS_PSM_T8; t->ClutPSM=GS_PSM_CT32; t->Clut=(u32*)buf; t->Mem=(u32*)(buf+1024); t->Filter=GS_FILTER_LINEAR;
    t->VramClut=gsKit_vram_alloc(gs,gsKit_texture_size(16,16,GS_PSM_CT32),GSKIT_ALLOC_USERBUFFER); t->Vram=gsKit_vram_alloc(gs,gsKit_texture_size(w,h,GS_PSM_T8),GSKIT_ALLOC_USERBUFFER);
    gsKit_texture_upload(gs,t); } }
int gfx_ps2_is_pal(void){ return gs->Mode==GS_MODE_PAL; }
void gfx_begin(void){ gsKit_clear(gs,GS_SETREG_RGBAQ(0,0,0,0x80,0)); }
void gfx_end(void){ gsKit_queue_exec(gs); gsKit_sync_flip(gs); }
static u64 C(unsigned c){ int r=(c>>24)&255,g=(c>>16)&255,b=(c>>8)&255,a=c&255; return GS_SETREG_RGBAQ(r*128/255,g*128/255,b*128/255,a*128/255,0); }
void gfx_rect(float x0,float y0,float x1,float y1,unsigned c){ gsKit_prim_sprite(gs,x0*FX,y0*FY,x1*FX,y1*FY,1,C(c)); }
void gfx_tri(float x0,float y0,float x1,float y1,float x2,float y2,unsigned c){ gsKit_prim_triangle(gs,x0*FX,y0*FY,x1*FX,y1*FY,x2*FX,y2*FY,1,C(c)); }
void gfx_spr(int id,float cx,float cy,float w,float h,float rot,unsigned c){
  const Spr*s=&SPR[id]; GSTEXTURE*t=&tex[s->atlas]; float u0=s->x+0.5f,v0=s->y+0.5f,u1=s->x+s->w-0.5f,v1=s->y+s->h-0.5f; float hw=w*0.5f,hh=h*0.5f;
  if(rot>-0.001f&&rot<0.001f){ gsKit_prim_sprite_texture(gs,t,(cx-hw)*FX,(cy-hh)*FY,u0,v0,(cx+hw)*FX,(cy+hh)*FY,u1,v1,1,C(c)); return; }
  float co=cosf(rot),si=sinf(rot); float px[4]={-hw,hw,-hw,hw},py[4]={-hh,-hh,hh,hh}; float X[4],Y[4];
  for(int i=0;i<4;i++){ X[i]=(cx+px[i]*co-py[i]*si)*FX; Y[i]=(cy+px[i]*si+py[i]*co)*FY; }
  gsKit_prim_quad_texture_3d(gs,t,X[0],Y[0],1,u0,v0, X[1],Y[1],1,u1,v0, X[2],Y[2],1,u0,v1, X[3],Y[3],1,u1,v1, C(c)); }
