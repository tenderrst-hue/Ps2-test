/* Angry Birds PS2 fan port - screens, HUD, menus (English only) */
#include "app.h"
#include "gfx.h"
#include "audio_tab.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#define WHITE RGBA(255,255,255,255)
static void snd(App*a,int s){ if(a->nsnd_out<16) a->snd_out[a->nsnd_out++]=s; }
static void spr(int id,float cx,float cy,float k,float rot,unsigned col){ gfx_spr(id,cx,cy,SPR[id].ow*k,SPR[id].oh*k,rot,col); }
static float tw(const char*s,float k){ float w=0; for(;*s;s++){ int c=*s; if(c<32||c>126)c=63; w+=(SPR[S_F_32+c-32].ow+3)*k; } return w; }
static void text(float x,float y,float k,const char*s,unsigned col,int align){ float w=tw(s,k); if(align==1)x-=w/2; else if(align==2)x-=w;
  for(;*s;s++){ int c=*s; if(c<32||c>126)c=63; const Spr*g=&SPR[S_F_32+c-32]; if(c!=32) gfx_spr(S_F_32+c-32,x+g->ow*k/2,y+g->oh*k/2,g->ow*k,g->oh*k,0,col); x+=(g->ow+3)*k; } }
static void shadow(float x,float y,float k,const char*s,unsigned col,int al){ text(x+1.5f,y+1.5f,k,s,RGBA(0,0,0,150),al); text(x,y,k,s,col,al); }
static int inside(const App*a,float cx,float cy,float w,float h){ return a->cx>=cx-w/2&&a->cx<=cx+w/2&&a->cy>=cy-h/2&&a->cy<=cy+h/2; }
static int button(App*a,const Pad*p,int id,float cx,float cy,float k){ int hov=inside(a,cx,cy,SPR[id].ow*k,SPR[id].oh*k); spr(id,cx,cy,hov?k*1.1f:k,0,WHITE); if(hov&&p&&p->pressed){ a->clicked=1; snd(a,A_SEL); return 1; } return 0; }
void app_init(App*a){ memset(a,0,sizeof*a); a->sc=SC_SPLASH; a->cx=320; a->cy=224; a->music_on=1; a->mountains_on=1; a->want_music=-1; a->music_cur=-2; }
static int unlocked(const App*a){ int n=1; for(int i=0;i<15&&a->stars[i]>0;i++) n++; return n>15?15:n; }
static void go(App*a,Screen s){ a->sc=s; a->t=0; }
static void start_level(App*a,int lv){ world_load(&a->w,lv); a->sel_level=lv; a->paused=0; a->sc=SC_PLAY; a->t=0; snd(a,A_START); }
void app_click(App*a,const Pad*p);
void app_update(App*a,const Pad*p,float dt){
  a->t+=dt; a->nsnd_out=0; a->clicked=0; if(a->sc==SC_PLAY&&p->start&&a->w.ps!=PS_WON&&a->w.ps!=PS_LOST) a->paused^=1;
  a->cx+=(p->lx+(p->rt-p->lf))*380*dt; a->cy+=(p->ly+(p->dn-p->up))*380*dt; if(a->cx<0)a->cx=0; if(a->cx>639)a->cx=639; if(a->cy<0)a->cy=0; if(a->cy>447)a->cy=447;
  if(a->sc==SC_PLAY&&!a->paused&&!(a->w.ps==PS_WON||a->w.ps==PS_LOST)){ world_step(&a->w,dt); world_control(&a->w,p,a->cx,a->cy,a->ctrl_alt,dt); for(int i=0;i<a->w.nsnd;i++) snd(a,a->w.snd[i]); }
  else if(a->sc==SC_PLAY){ if(!a->paused) world_step(&a->w,dt); for(int i=0;i<a->w.nsnd;i++) snd(a,a->w.snd[i]); }
  if(a->sc==SC_CREDITS&&a->credit_run) a->credit_y+=42*dt;
  a->want_music=a->music_on?((a->sc==SC_PLAY)?A_MUS_GAME:(a->sc==SC_SPLASH?-1:A_MUS_MENU)):-1;
  if(a->sc==SC_SPLASH&&(a->t>3.f||p->pressed)){ go(a,SC_MENU); }
  if(a->sc==SC_PLAY&&a->w.ps==PS_WON&&a->w.stars>a->stars[a->w.level]) a->stars[a->w.level]=a->w.stars;
  app_click(a,p);
}
static void backdrop(App*a,float camx,float zoom,int game){
  float gy=game?372:392; for(int i=0;i<10;i++){ float t=i/9.f; gfx_rect(0,i*gy/10,640,(i+1)*gy/10+1,RGBA((int)(62+t*128),(int)(150+t*72),(int)(216+t*12),255)); } gfx_spr(S_BG_SKY,320,gy/2,640,gy,0,RGBA(255,255,255,120));
  if(a->mountains_on){ for(int i=0;i<3;i++) gfx_spr(S_BG_HILLS,i*440-fmodf(camx*0.15f+4400,440)+220,gy-34,484*0.95f,46*1.4f,0,RGBA(255,255,255,170)); 
    for(int i=0;i<4;i++){ float x=i*300-fmodf(camx*0.3f*zoom+9999*300,300); gfx_spr(S_BG_STUMP,x+60,gy-36,62*0.7f,112*0.7f,0,RGBA(255,255,255,255)); } }
  gfx_rect(0,gy,640,448,RGBA(120,138,40,255)); gfx_rect(0,gy+34,640,448,RGBA(96,86,32,255)); gfx_rect(0,gy+90,640,448,RGBA(70,58,28,255));
  for(int i=-1;i<4;i++) gfx_spr(S_BG_GRASS,i*336*0.9f-fmodf(camx*zoom,336*0.9f)+168*0.9f,gy+2,336*0.9f,25*0.9f,0,WHITE);
}
static void cursor(App*a){ float x=a->cx,y=a->cy; gfx_tri(x-1,y-1,x-1,y+25,x+17,y+19,RGBA(0,0,0,255)); gfx_tri(x+1.5f,y+3.5f,x+1.5f,y+19.5f,x+12.5f,y+15.5f,WHITE); gfx_rect(x+6,y+14,x+10,y+27,RGBA(0,0,0,255)); gfx_rect(x+7,y+15,x+9,y+25,WHITE); }
static void draw_world(App*a);
static void popup(float cx,float cy,float w,float h){ gfx_rect(cx-w/2-3,cy-h/2-3,cx+w/2+3,cy+h/2+3,RGBA(30,40,60,255)); gfx_rect(cx-w/2,cy-h/2,cx+w/2,cy+h/2,RGBA(40,55,85,245)); gfx_rect(cx-w/2,cy-h/2,cx+w/2,cy-h/2+8,RGBA(250,170,30,255)); }
static const char*CRED[]={"ANGRY BIRDS","","VPlayStation2FanPort","","ORIGINAL GAME","ROVIO ENTERTAINMENT","","ANGRY BIRDS AND ALL RELATED","CHARACTERS AND ASSETS ARE","TRADEMARKS OF ROVIO","","THIS IS AN UNOFFICIAL","NON COMMERCIAL FAN PORT","","TUTORIAL EPISODE","","MUSIC AND SOUND","FROM THE ORIGINAL GAME","","THANK YOU FOR PLAYING","",0};
void app_draw(App*a){
  gfx_begin(); World*w=&a->w; char b[64]; const Pad*P=0; (void)P;
  switch(a->sc){
  case SC_SPLASH: gfx_rect(0,0,640,448,RGBA(0,0,0,255)); gfx_spr(S_SPLASH,320,224,640,448,0,RGBA(255,255,255,a->t<0.5f?(int)(a->t*510):255)); break;
  case SC_MENU: backdrop(a,0,1,0); spr(S_U_LOGO,320,66,0.62f,0,WHITE);
    spr(S_U_CARD0,320,235,0.5f,0,WHITE); shadow(320,342,0.42f,"EPISODES",WHITE,1); spr(S_U_PLAY,320,385,0.62f,0,WHITE);
    spr(S_U_GEAR,48,400,0.5f,0,WHITE); shadow(48,424,0.3f,"SETTINGS",WHITE,1); break;
  case SC_EPISODES: backdrop(a,0,1,0); shadow(320,14,0.5f,"CHOOSE EPISODE",WHITE,1);
    for(int i=0;i<7;i++){ float cx=62+i*86; int lk=i>0; spr(i==0?S_U_CARD0:S_U_CARD1+i-1,cx,205,0.5f,0,lk?RGBA(120,120,120,255):WHITE);
      if(lk){ spr(S_U_LOCK,cx,200,0.45f,0,WHITE); shadow(cx,300,0.26f,"COMING",RGBA(255,230,120,255),1); shadow(cx,316,0.26f,"SOON",RGBA(255,230,120,255),1); }
      else { shadow(cx,326,0.3f,"TUTORIAL",WHITE,1); int s=0; for(int k=0;k<15;k++) s+=a->stars[k]; snprintf(b,sizeof b,"%d/45",s); shadow(cx,346,0.3f,b,WHITE,1); } }
    break;
  case SC_LEVELS: backdrop(a,0,1,0); shadow(320,14,0.5f,"TUTORIAL",WHITE,1); { int un=unlocked(a);
    for(int i=0;i<15;i++){ float cx=120+(i%5)*100,cy=120+(i/5)*100; int ok=i<un; spr(ok?S_U_TILE:S_U_TILE_G,cx,cy,0.62f,0,ok?WHITE:RGBA(110,110,110,255));
      if(ok){ snprintf(b,sizeof b,"%d",i+1); shadow(cx,cy-16,0.5f,b,WHITE,1); for(int s=0;s<3;s++) spr(s<a->stars[i]?S_U_STAR:S_U_STAR_OFF,cx-17+s*17,cy+22,0.27f,0,WHITE); } else spr(S_U_LOCK,cx,cy,0.3f,0,WHITE); } } break;
  case SC_SETTINGS: backdrop(a,0,1,0); popup(320,225,430,300); shadow(320,86,0.5f,"SETTINGS",WHITE,1);
    spr(S_U_SOUND,150,150,0.55f,0,a->music_on?WHITE:RGBA(110,110,110,255)); shadow(195,138,0.4f,"MUSIC",WHITE,0); shadow(450,138,0.4f,a->music_on?"ON":"OFF",a->music_on?RGBA(120,255,120,255):RGBA(255,110,110,255),0);
    spr(S_U_MOUNT,150,205,0.55f,0,a->mountains_on?WHITE:RGBA(110,110,110,255)); shadow(195,193,0.4f,"MOUNTAINS",WHITE,0); shadow(450,193,0.4f,a->mountains_on?"ON":"OFF",a->mountains_on?RGBA(120,255,120,255):RGBA(255,110,110,255),0);
    spr(S_U_PAD,150,260,0.55f,0,WHITE); shadow(195,248,0.4f,"CONTROLS",WHITE,0); shadow(450,248,0.4f,a->ctrl_alt?"STICK":"MOUSE",RGBA(255,230,120,255),0);
    spr(S_U_INFO,150,315,0.55f,0,WHITE); shadow(195,303,0.4f,"CREDITS",WHITE,0); break;
  case SC_CREDITS: backdrop(a,0,1,0); { float y=440-a->credit_y; for(int i=0;CRED[i];i++,y+=26){ if(y>-30&&y<448) shadow(320,y,i==0?0.55f:0.38f,CRED[i],i==2?RGBA(255,220,90,255):WHITE,1); }
      float ey=y+30; if(ey>-130&&ey<460){ spr(S_U_EGG,320,ey+50,0.9f,0,WHITE); shadow(320,ey+125,0.36f,"PlayStation2Port:VLaD",WHITE,1); }
      if(!a->credit_run&&a->credit_y==0) shadow(320,410,0.3f,"PRESS X TO CONTINUE",RGBA(255,230,120,255),1); } break;
  case SC_PLAY: draw_world(a); break; }
  if(a->sc!=SC_SPLASH&&a->sc!=SC_PLAY){ if(a->sc!=SC_MENU) spr(S_U_BACK,44,414,0.5f,0,WHITE); }
  cursor(a); gfx_end(); (void)w; }
static void draw_world(App*a){
  World*w=&a->w; float z=w->cam.zoom; char b[64]; backdrop(a,w->cam.camx,z,1);
  float sx,sy; world_to_screen(w,0.f,0,&sx,&sy);
  /* sling back arm, bird on sling, front arm */
  float bx=0+w->pull_x, by=143+w->pull_y; float rx,ry; world_to_screen(w,0,118.f,&rx,&ry); float lx,ly; world_to_screen(w,-6,118.f+45,&lx,&ly); float rx2,ry2; world_to_screen(w,10,118.f+45,&rx2,&ry2);
  spr(S_C_SLING_STEM,rx,ry+ SPR[S_C_SLING_STEM].oh*z*0.5f-20*z,z*0.95f,0,WHITE);
  spr(S_C_SLING_ARM,lx-8*z,ly-10*z,z*0.95f,0.35f,RGBA(190,190,190,255));
  for(int i=0;i<w->nb;i++){ const Body*o=&w->b[i]; if(!o->alive||o->kind==K_GROUND) continue; float x,y; world_to_screen(w,o->x,o->y,&x,&y); int st=0; float r=o->hp/o->hp0; if(o->kind!=K_BIRD) st=r>0.66f?0:(r>0.33f?1:2);
    int id=o->spr[st]; float rot=-(o->rot+o->srot); if(o->kind==K_BIRD||o->kind==K_EGG) gfx_spr(id,x,y,o->r*2.4f*z,o->r*2.4f*z*SPR[id].oh/SPR[id].ow,rot,WHITE); else if(o->kind==K_PIG) gfx_spr(id,x,y,o->r*2.6f*z,o->r*2.6f*z*SPR[id].oh/SPR[id].ow,rot,WHITE); else gfx_spr(id,x,y,SPR[id].ow*z*(o->srot?1:1),SPR[id].oh*z,rot,WHITE); }
  if(w->ps==PS_AIM&&w->bird_i<w->nbirds){ int t=w->birds[w->bird_i]; static const int BS_[6]={S_C_RED,S_C_BLUE,S_C_YELLOW,S_C_BLACK,S_C_WHITE,S_C_BIG}; int id=BS_[t]; float x,y; world_to_screen(w,bx,by,&x,&y);
    float k=SPR[id].ow*0.4f*2.4f*z; if(w->dragging){ float ax,ay; world_to_screen(w,-4,118.f+60,&ax,&ay); gfx_tri(ax,ay-3,ax,ay+3,x,y,RGBA(60,30,20,255)); float cx2,cy2; world_to_screen(w,12,118.f+60,&cx2,&cy2); gfx_tri(cx2,cy2-3,cx2,cy2+3,x,y,RGBA(60,30,20,255));
      for(int d=1;d<=14;d++){ float tt=d*0.075f; float vx=-w->pull_x*12.5f,vy=-w->pull_y*12.5f; float px,py; world_to_screen(w,bx+vx*tt,by+vy*tt-0.5f*LV_GRAV*tt*tt,&px,&py); gfx_rect(px-2,py-2,px+2,py+2,RGBA(255,255,255,200)); } }
    gfx_spr(id,x,y,k,k*SPR[id].oh/SPR[id].ow,0,WHITE); }
  spr(S_C_SLING_ARM,rx2+14*z,ry2-4*z,z*0.95f,-0.2f,WHITE);
  for(int i=0;i<MAXFX;i++){ const Fx*f=&w->fx[i]; if(f->life<=0) continue; float x,y; world_to_screen(w,f->x,f->y,&x,&y); float al=f->life/f->max; if(f->text){ snprintf(b,sizeof b,"%d",f->text); text(x,y-(1-al)*30,0.32f,b,RGBA(255,255,255,(int)(255*al)),1); } else { float k=f->sc*z*(1.4f-al*0.4f); gfx_spr(f->spr,x,y,SPR[f->spr].ow*k,SPR[f->spr].oh*k,f->rot,RGBA(255,255,255,(int)(255*al))); } }
  /* HUD */
  spr(S_U_LIST,34,34,0.4f,0,WHITE); snprintf(b,sizeof b,"%d",w->score); shadow(626,8,0.5f,b,WHITE,2); shadow(626,32,0.26f,"SCORE",RGBA(255,230,120,255),2);
  for(int i=w->bird_i;i<w->nbirds;i++){ static const int BS2[6]={S_C_RED,S_C_BLUE,S_C_YELLOW,S_C_BLACK,S_C_WHITE,S_C_BIG}; int id=BS2[w->birds[i]]; spr(id,30+(i-w->bird_i)*34,400,0.55f,0,WHITE); }
  if(a->paused){ popup(320,224,300,170); shadow(320,150,0.5f,"PAUSED",WHITE,1); spr(S_U_PLAY,250,230,0.7f,0,WHITE); spr(S_U_RESTART,320,230,0.55f,0,WHITE); spr(S_U_LIST,390,230,0.55f,0,WHITE); }
  if(w->ps==PS_WON){ popup(320,224,320,250); shadow(320,120,0.5f,"LEVEL CLEARED!",WHITE,1); for(int s=0;s<3;s++){ float al=a->w.endtimer>0.3f*(s+1)?1:0; if(s<w->stars&&al) spr(S_U_STAR,262+s*58,176,0.85f,0,WHITE); else spr(S_U_STAR_OFF,262+s*58,176,1.0f,0,RGBA(255,255,255,120)); }
    snprintf(b,sizeof b,"%d",w->score); shadow(320,218,0.55f,b,WHITE,1); spr(S_U_LIST,258,300,0.5f,0,WHITE); spr(S_U_RESTART,320,300,0.5f,0,WHITE); if(w->level<14) spr(S_U_NEXT,382,300,0.5f,0,WHITE); }
  if(w->ps==PS_LOST){ popup(320,224,320,200); shadow(320,150,0.5f,"LEVEL FAILED",RGBA(255,120,120,255),1); spr(S_U_LIST,280,250,0.55f,0,WHITE); spr(S_U_RESTART,360,250,0.55f,0,WHITE); }
}
/* second pass: click handling needs hit tests identical to the drawing above */
void app_click(App*a,const Pad*p){
  if(!p->pressed) return; a->clicked=0;
  #define HIT(cx,cy,w_,h_) inside(a,cx,cy,w_,h_)
  if(a->sc!=SC_MENU&&a->sc!=SC_PLAY&&a->sc!=SC_SPLASH&&HIT(44,414,60,52)){ snd(a,A_BACK); go(a,a->sc==SC_EPISODES?SC_MENU:a->sc==SC_LEVELS?SC_EPISODES:SC_MENU); if(a->sc==SC_MENU&&0) {} return; }
  switch(a->sc){
   case SC_MENU: if(HIT(320,235,90,250)||HIT(320,385,60,60)){ snd(a,A_OK); go(a,SC_EPISODES); } else if(HIT(48,400,60,60)){ snd(a,A_OK); go(a,SC_SETTINGS); } break;
   case SC_EPISODES: if(HIT(62,205,86,250)){ snd(a,A_OK); go(a,SC_LEVELS); } break;
   case SC_LEVELS: { int un=unlocked(a); for(int i=0;i<un;i++) if(HIT(120+(i%5)*100,120+(i/5)*100,70,70)){ start_level(a,i); return; } } break;
   case SC_SETTINGS: if(HIT(300,150,330,50)){ a->music_on^=1; snd(a,A_SEL); } else if(HIT(300,205,330,50)){ a->mountains_on^=1; snd(a,A_SEL); } else if(HIT(300,260,330,50)){ a->ctrl_alt^=1; snd(a,A_SEL); } else if(HIT(300,315,330,50)){ snd(a,A_OK); a->credit_y=0; a->credit_run=0; go(a,SC_CREDITS); } break;
   case SC_CREDITS: if(HIT(320,200,640,300)){ a->credit_run^=1; snd(a,A_SEL); } break;
   case SC_PLAY: { World*w=&a->w;
     if(a->paused){ if(HIT(250,230,60,60)) a->paused=0; else if(HIT(320,230,60,60)) start_level(a,w->level); else if(HIT(390,230,60,60)){ go(a,SC_LEVELS); } }
     else if(w->ps==PS_WON){ if(HIT(258,300,60,60)) go(a,SC_LEVELS); else if(HIT(320,300,60,60)) start_level(a,w->level); else if(w->level<14&&HIT(382,300,60,60)) start_level(a,w->level+1); }
     else if(w->ps==PS_LOST){ if(HIT(280,250,60,60)) go(a,SC_LEVELS); else if(HIT(360,250,60,60)) start_level(a,w->level); }
     else if(HIT(34,34,50,50)) a->paused=1; } break;
   default: break; } }
