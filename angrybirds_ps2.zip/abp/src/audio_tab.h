#ifndef AUDIO_TAB_H
#define AUDIO_TAB_H
typedef struct { unsigned int off, len; } Snd;
enum {
 A_STRETCH,
 A_LAUNCH,
 A_RED_YELL,
 A_WOOD_HIT,
 A_WOOD_HIT2,
 A_WOOD_DMG,
 A_WOOD_DIE,
 A_ICE_HIT,
 A_ICE_HIT2,
 A_ICE_DIE,
 A_STONE_HIT,
 A_STONE_DIE,
 A_PIG_HIT,
 A_PIG_DMG,
 A_PIG_DIE,
 A_PIG_OINK,
 A_BIRD_HIT,
 A_BIRD_HIT2,
 A_TNT,
 A_STAR1,
 A_STAR2,
 A_STAR3,
 A_WIN,
 A_LOSE,
 A_START,
 A_SEL,
 A_OK,
 A_BACK,
 A_SUPER,
 A_MUS_MENU,
 A_MUS_GAME,
 A_MUS_WIN,
 A_COUNT };
extern const Snd SND[A_COUNT];
#endif
