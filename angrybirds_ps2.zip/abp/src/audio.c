/* software mixer: mono 16-bit 11025 Hz, music + 8 sfx voices, pushed to audsrv */
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <audsrv.h>
#include <string.h>
#include "audio.h"
#include "audio_tab.h"
extern unsigned char audio_bin[], audsrv_irx[]; extern unsigned int size_audsrv_irx;
typedef struct { const short*p; int n,pos; } Voice;
static Voice vo[8]; static Voice mu; static int mu_on=0;
void audio_init(void){
  SifLoadModule("rom0:LIBSD",0,NULL); SifExecModuleBuffer(audsrv_irx,size_audsrv_irx,0,NULL,NULL);
  if(audsrv_init()!=0) return; struct audsrv_fmt_t f; f.freq=11025; f.bits=16; f.channels=1; audsrv_set_format(&f); audsrv_set_volume(MAX_VOLUME); }
void audio_sfx(int id){ if(id<0||id>=A_COUNT||SND[id].len==0) return; int k=0,best=0; for(int i=0;i<8;i++){ if(vo[i].pos>=vo[i].n){ k=i; best=1; break; } } if(!best) k=0;
  vo[k].p=(const short*)audio_bin+SND[id].off; vo[k].n=SND[id].len; vo[k].pos=0; }
void audio_music(int id){ if(id<0||id>=A_COUNT){ mu_on=0; return; } mu.p=(const short*)audio_bin+SND[id].off; mu.n=SND[id].len; mu.pos=0; mu_on=1; }
void audio_update(void){
  static short buf[512];
  for(int blk=0;blk<3;blk++){ if(audsrv_available()<(int)sizeof buf+256) break;
    for(int i=0;i<512;i++){ int s=0; if(mu_on){ s+=mu.p[mu.pos]*6/10; if(++mu.pos>=mu.n) mu.pos=0; }
      for(int v=0;v<8;v++) if(vo[v].pos<vo[v].n) s+=vo[v].p[vo[v].pos++]; if(s>32767)s=32767; if(s<-32768)s=-32768; buf[i]=(short)s; }
    audsrv_play_audio((char*)buf,sizeof buf); } }
