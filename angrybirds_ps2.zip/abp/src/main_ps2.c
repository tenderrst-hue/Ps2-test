/* Angry Birds (Tutorial) - PS2 fan port entry point */
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include <string.h>
#include "app.h"
#include "audio.h"
#include "gfx_ps2.h"
static char padbuf[256] __attribute__((aligned(64)));
static float axis(int v){ float f=(v-128)/128.f; if(f>-0.18f&&f<0.18f) return 0; return f>0?(f-0.18f)/0.82f:(f+0.18f)/0.82f; }
int main(void){
  SifInitRpc(0); SifLoadModule("rom0:SIO2MAN",0,NULL); SifLoadModule("rom0:PADMAN",0,NULL);
  padInit(0); padPortOpen(0,0,padbuf); { int t=0; while(padGetState(0,0)!=PAD_STATE_STABLE&&padGetState(0,0)!=PAD_STATE_FINDCTP1&&t<200000) t++; }
  padSetMainMode(0,0,PAD_MMODE_DUALSHOCK,PAD_MMODE_LOCK);
  gfx_ps2_init(); audio_init();
  static App app; app_init(&app); float dt=gfx_ps2_is_pal()?1.f/50.f:1.f/60.f; unsigned prev=0; int music=-2;
  for(;;){
    Pad p; memset(&p,0,sizeof p); struct padButtonStatus b;
    if(padGetState(0,0)==PAD_STATE_STABLE&&padRead(0,0,&b)){ unsigned now=0xffff^b.btns,edge=now&~prev,rel=prev&~now; prev=now;
      p.lx=axis(b.ljoy_h); p.ly=axis(b.ljoy_v); p.rx=axis(b.rjoy_h); p.ry=axis(b.rjoy_v);
      p.down=(now&PAD_CROSS)!=0; p.pressed=(edge&PAD_CROSS)!=0; p.released=(rel&PAD_CROSS)!=0; p.start=(edge&PAD_START)!=0;
      p.up=(now&PAD_UP)!=0; p.dn=(now&PAD_DOWN)!=0; p.lf=(now&PAD_LEFT)!=0; p.rt=(now&PAD_RIGHT)!=0; }
    app_update(&app,&p,dt);
    for(int i=0;i<app.nsnd_out;i++) audio_sfx(app.snd_out[i]);
    if(app.want_music!=music){ music=app.want_music; audio_music(music); }
    app_draw(&app); audio_update(); }
  return 0; }
