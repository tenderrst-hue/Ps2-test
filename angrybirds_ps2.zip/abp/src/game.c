/* Angry Birds PS2 fan port - physics + gameplay core (platform independent, host-testable) */
#include "game.h"
#include "audio_tab.h"
#include <math.h>
#include <string.h>
#define GRAV LV_GRAV
#define PI 3.14159265f
typedef struct { V2 p,n; float sep; int id; float Pn,Pt,mN,mT,bias; V2 r1,r2; } Ct;
typedef struct { int a,b,n; Ct c[2]; } Arb;
static Arb arbA[1500], arbB[1500]; static Arb*arb=arbA,*arbOld=arbB; static int narb,narbOld;
static float dq[MAXB];
static inline V2 v2(float x,float y){ V2 r={x,y}; return r; }
static inline float dot(V2 a,V2 b){ return a.x*b.x+a.y*b.y; }
static inline float crs(V2 a,V2 b){ return a.x*b.y-a.y*b.x; }
static void Q(World*w,int s){ if(w->nsnd<16) w->snd[w->nsnd++]=s; }
static float rnd(World*w){ w->rng=w->rng*1664525u+1013904223u; return ((w->rng>>8)&0xFFFF)/65535.f; }
/* ---------------- bodies ---------------- */
static const float DENS[3]={0.7f,0.45f,2.0f}, HP[3]={100,55,260}; static const int PTS[3]={500,500,800};
static void setmass(Body*b,float dens){ if(dens<=0){b->invm=b->invI=0;return;} float area=b->shape==SH_BOX?4*b->hw*b->hh:PI*b->r*b->r; float m=area*dens/10000.f;
  float I=b->shape==SH_BOX? m*(4*b->hw*b->hw+4*b->hh*b->hh)/12.f : 0.5f*m*b->r*b->r; b->invm=1/m; b->invI=1/I; }
static Body*newbody(World*w){ if(w->nb>=MAXB) return 0; Body*b=&w->b[w->nb++]; memset(b,0,sizeof*b); b->alive=1; b->fric=0.55f; return b; }
enum { KL_LONG,KL_MED,KL_SHORT,KL_BLK,KL_SQ,KL_TRI,KL_SSQ,KL_CIRC };
static const int BS[8][3]={{S_B_LONG_W0,S_B_LONG_I0,S_B_LONG_S0},{S_B_MED_W0,S_B_MED_I0,S_B_MED_S0},{S_B_SHORT_W0,S_B_SHORT_I0,S_B_SHORT_S0},{S_B_BLK_W0,S_B_BLK_I0,S_B_BLK_S0},
 {S_B_SQ_W0,S_B_SQ_I0,S_B_SQ_S0},{S_B_TRI_W0,S_B_TRI_I0,S_B_TRI_S0},{S_B_SSQ_W0,S_B_SSQ_I0,S_B_SSQ_S0},{S_B_CIRC_W0,S_B_CIRC_I0,S_B_CIRC_S0}};
static void blk(World*w,int kind,int mat,float x,float yb,int vert){
  Body*b=newbody(w); if(!b) return; int s0=BS[kind][mat]; float W=SPR[s0].ow,H=SPR[s0].oh;
  b->kind=K_BLOCK; b->mat=mat; b->spr[0]=s0; b->spr[1]=s0+1; b->spr[2]=s0+2; b->x=x; b->hp=b->hp0=HP[mat]*((kind==KL_LONG||kind==KL_MED)?1.15f:1.f);
  if(kind==KL_CIRC){ b->shape=SH_CIRCLE; b->r=W*0.46f; b->y=yb+b->r; }
  else { float k=kind==KL_TRI?0.8f:1.f; float hw=W*0.5f*0.97f*k, hh=H*0.5f*0.95f*k;
    if(vert){ b->hw=hh; b->hh=hw; b->srot=PI*0.5f; } else { b->hw=hw; b->hh=hh; } b->y=yb+b->hh; }
  setmass(b,DENS[mat]); }
static void pig(World*w,float x,float yb){ Body*b=newbody(w); if(!b) return; b->kind=K_PIG; b->shape=SH_CIRCLE; b->r=SPR[S_C_PIG].ow*0.31f; b->x=x; b->y=yb+b->r; b->spr[0]=S_C_PIG; b->spr[1]=S_C_PIG_HIT; b->spr[2]=S_C_PIG_HURT;
  b->hp=b->hp0=48; setmass(b,0.5f); w->pigs++; }
static void tnt(World*w,float x,float yb){ Body*b=newbody(w); if(!b) return; b->kind=K_TNT; b->shape=SH_BOX; b->hw=SPR[S_TNT].ow*0.46f; b->hh=SPR[S_TNT].oh*0.46f; b->x=x; b->y=yb+b->hh; b->spr[0]=b->spr[1]=b->spr[2]=S_TNT; b->hp=b->hp0=45; setmass(b,0.8f); }
static const int BSPR[6]={S_C_RED,S_C_BLUE,S_C_YELLOW,S_C_BLACK,S_C_WHITE,S_C_BIG}; static const float BDENS[6]={1.5f,1.0f,1.3f,1.7f,1.4f,2.4f}; static const float BRAD[6]={0.62f,0.56f,0.62f,0.64f,0.60f,0.50f};
static Body*bird(World*w,int t,float x,float y,float vx,float vy){ Body*b=newbody(w); if(!b) return 0; b->kind=K_BIRD; b->shape=SH_CIRCLE; b->btype=t; b->r=SPR[BSPR[t]].ow*BRAD[t]; b->x=x; b->y=y; b->vx=vx; b->vy=vy;
  b->spr[0]=BSPR[t]; b->spr[1]=BSPR[t]; b->spr[2]=BSPR[t]; b->hp=b->hp0=1e9f; setmass(b,BDENS[t]); b->fric=0.4f; return b; }
static void fxadd(World*w,int spr,float x,float y,float vx,float vy,float life,float sc,int text){ for(int i=0;i<MAXFX;i++) if(w->fx[i].life<=0){ Fx*f=&w->fx[i]; f->spr=spr;f->x=x;f->y=y;f->vx=vx;f->vy=vy;f->rot=0;f->vr=(rnd(w)-0.5f)*6;f->life=f->max=life;f->sc=sc;f->text=text; return; } }
/* ---------------- collision ---------------- */
static void verts(const Body*b,V2 v[4]){ float c=cosf(b->rot),s=sinf(b->rot); static const float hx[4]={-1,1,1,-1},hy[4]={-1,-1,1,1};
  for(int i=0;i<4;i++){ float lx=hx[i]*b->hw,ly=hy[i]*b->hh; v[i]=v2(b->x+c*lx-s*ly,b->y+s*lx+c*ly); } }
static V2 enorm(const V2*v,int i){ V2 a=v[i],b=v[(i+1)&3]; V2 e=v2(b.x-a.x,b.y-a.y); float l=sqrtf(e.x*e.x+e.y*e.y); return v2(e.y/l,-e.x/l); }
static float maxsep(const V2*A,const V2*B,int*edge){ float best=-1e9f; for(int i=0;i<4;i++){ V2 n=enorm(A,i); float mn=1e9f; for(int j=0;j<4;j++){ float d=dot(n,v2(B[j].x-A[i].x,B[j].y-A[i].y)); if(d<mn)mn=d; } if(mn>best){best=mn;*edge=i;} } return best; }
static int c_poly(const Body*a,const Body*b,Ct*out){
  V2 A[4],B[4]; verts(a,A); verts(b,B); int ea,eb; float sa=maxsep(A,B,&ea); if(sa>0) return 0; float sb=maxsep(B,A,&eb); if(sb>0) return 0;
  const V2*R,*I; int re,flip; if(sb>sa+0.1f){R=B;I=A;re=eb;flip=1;} else {R=A;I=B;re=ea;flip=0;}
  V2 n=enorm(R,re); int ie=0; float md=1e9f; for(int i=0;i<4;i++){ float d=dot(n,enorm(I,i)); if(d<md){md=d;ie=i;} }
  V2 p0=I[ie],p1=I[(ie+1)&3]; V2 r0=R[re],r1=R[(re+1)&3]; V2 t=v2(r1.x-r0.x,r1.y-r0.y); float tl=sqrtf(dot(t,t)); t.x/=tl; t.y/=tl;
  float d0=dot(t,v2(p0.x-r0.x,p0.y-r0.y)), d1=dot(t,v2(p1.x-r0.x,p1.y-r0.y)); V2 e=v2(p1.x-p0.x,p1.y-p0.y);
  if(d0<0){ if(d1==d0) return 0; float k=(0-d0)/(d1-d0); p0=v2(p0.x+e.x*k,p0.y+e.y*k); d0=0; }
  if(d1<0){ float k=(0-d0)/(d1-d0); (void)k; }
  e=v2(p1.x-p0.x,p1.y-p0.y); d0=dot(t,v2(p0.x-r0.x,p0.y-r0.y)); d1=dot(t,v2(p1.x-r0.x,p1.y-r0.y));
  if(d1<0){ float k=(0-d0)/(d1-d0); p1=v2(p0.x+e.x*k,p0.y+e.y*k); }
  d0=dot(t,v2(p0.x-r0.x,p0.y-r0.y)); d1=dot(t,v2(p1.x-r0.x,p1.y-r0.y));
  if(d0>tl){ float k=(tl-d1)/(d0-d1); p0=v2(p1.x+(p0.x-p1.x)*k,p1.y+(p0.y-p1.y)*k); }
  d0=dot(t,v2(p0.x-r0.x,p0.y-r0.y)); d1=dot(t,v2(p1.x-r0.x,p1.y-r0.y));
  if(d1>tl){ float k=(tl-d0)/(d1-d0); p1=v2(p0.x+(p1.x-p0.x)*k,p0.y+(p1.y-p0.y)*k); }
  int cnt=0; V2 pts[2]={p0,p1};
  for(int k=0;k<2;k++){ float s=dot(n,v2(pts[k].x-r0.x,pts[k].y-r0.y)); if(s<=1.0f){ out[cnt].sep=s; out[cnt].n=flip?v2(-n.x,-n.y):n; out[cnt].p=v2(pts[k].x-n.x*s*0.5f,pts[k].y-n.y*s*0.5f); out[cnt].id=re*16+ie*2+k+flip*100; cnt++; } }
  return cnt; }
static int c_circ_circ(const Body*a,const Body*b,Ct*o){ V2 d=v2(b->x-a->x,b->y-a->y); float l=sqrtf(dot(d,d)),rs=a->r+b->r; if(l>=rs) return 0; V2 n=l>1e-4f?v2(d.x/l,d.y/l):v2(0,1);
  o->n=n; o->sep=l-rs; o->p=v2(a->x+n.x*(a->r+o->sep*0.5f),a->y+n.y*(a->r+o->sep*0.5f)); o->id=0; return 1; }
static int c_box_circ(const Body*bx,const Body*ci,Ct*o){ float c=cosf(bx->rot),s=sinf(bx->rot); V2 d=v2(ci->x-bx->x,ci->y-bx->y); V2 l=v2(c*d.x+s*d.y,-s*d.x+c*d.y);
  V2 q=v2(l.x<-bx->hw?-bx->hw:(l.x>bx->hw?bx->hw:l.x), l.y<-bx->hh?-bx->hh:(l.y>bx->hh?bx->hh:l.y)); V2 df=v2(l.x-q.x,l.y-q.y); float dist=sqrtf(dot(df,df)); V2 nl;
  if(dist<1e-4f){ float px=bx->hw-fabsf(l.x),py=bx->hh-fabsf(l.y); if(px<py) nl=v2(l.x>0?1:-1,0),dist=-px; else nl=v2(0,l.y>0?1:-1),dist=-py; q=v2(l.x,l.y); }
  else { nl=v2(df.x/dist,df.y/dist); if(dist>ci->r) return 0; }
  V2 n=v2(c*nl.x-s*nl.y,s*nl.x+c*nl.y); o->n=v2(-n.x,-n.y); /* box -> circle is +n, but contact normal convention A->B with A=box */ o->n=n;
  o->sep=dist-ci->r; o->p=v2(ci->x-n.x*ci->r,ci->y-n.y*ci->r); o->id=0; return 1; }
static int collide(const Body*a,const Body*b,Ct*o){
  if(a->shape==SH_BOX&&b->shape==SH_BOX) return c_poly(a,b,o);
  if(a->shape==SH_CIRCLE&&b->shape==SH_CIRCLE) return c_circ_circ(a,b,o);
  if(a->shape==SH_BOX) return c_box_circ(a,b,o);
  int n=c_box_circ(b,a,o); if(n){ o->n=v2(-o->n.x,-o->n.y); } return n; }
/* ---------------- explosion ---------------- */
static void explode(World*w,float x,float y,float R,float impv,float dmg){
  fxadd(w,S_C_PUFF,x,y,0,0,0.5f,R/70.f,0); Q(w,A_TNT);
  for(int i=0;i<w->nb;i++){ Body*b=&w->b[i]; if(!b->alive||b->invm==0) continue; float dx=b->x-x,dy=b->y-y,d=sqrtf(dx*dx+dy*dy); if(d>R+ (b->shape==SH_CIRCLE?b->r:b->hw)) continue;
    float f=1-d/(R+1); if(f<0.1f)f=0.1f; float m=1/b->invm; float dv=impv*f/(0.4f+m*0.9f); if(d<1)d=1; b->vx+=dx/d*dv; b->vy+=dy/d*dv+dv*0.25f; if(b->kind!=K_BIRD) dq[i]+=dmg*f; } }
/* ---------------- destroy ---------------- */
static void destroy(World*w,int i){ Body*b=&w->b[i]; if(!b->alive) return; b->alive=0;
  if(b->kind==K_PIG){ w->score+=5000; w->pigs--; fxadd(w,S_C_PUFF,b->x,b->y,0,60,0.6f,1.1f,5000); Q(w,A_PIG_DIE); }
  else if(b->kind==K_BLOCK){ w->score+=PTS[b->mat]; fxadd(w,S_C_PUFF,b->x,b->y,0,40,0.4f,0.6f,PTS[b->mat]); for(int k=0;k<3;k++) fxadd(w,S_C_FEATHER,b->x,b->y,(rnd(w)-0.5f)*400,200+rnd(w)*200,0.7f,0.6f,0);
    Q(w,b->mat==M_WOOD?A_WOOD_DIE:b->mat==M_ICE?A_ICE_DIE:A_STONE_DIE); }
  else if(b->kind==K_TNT){ w->score+=1000; explode(w,b->x,b->y,230,1100,140); }
  else if(b->kind==K_EGG){ explode(w,b->x,b->y,170,800,90); } }
/* ---------------- step ---------------- */
static void step(World*w,float h){
  int n=w->nb; V2 g=v2(0,-GRAV);
  for(int i=0;i<n;i++){ Body*b=&w->b[i]; dq[i]=0; if(!b->alive||b->invm==0) continue; b->vy+=g.y*h; b->vx*=1-0.05f*h; b->w*=1-0.9f*h; b->age++; }
  /* ground as virtual static plane handled in contacts below via kinematic body */
  static Body ground; memset(&ground,0,sizeof ground); ground.alive=1; ground.shape=SH_BOX; ground.hw=6000; ground.hh=300; ground.x=1500; ground.y=-300; ground.kind=K_GROUND; ground.fric=0.8f;
  Arb*t=arbOld; arbOld=arb; arb=t; narbOld=narb; narb=0;
  for(int pass=0;pass<2;pass++) for(int i=0;i<n;i++){ Body*A=&w->b[i]; if(!A->alive) continue; int jmax=pass==0?n:1; for(int jj=(pass==0?i+1:0);jj<jmax;jj++){
      Body*B=pass==0?&w->b[jj]:&ground; if(pass==0&&!B->alive) continue; if(A->invm==0&&B->invm==0) continue; if(A->kind==K_BIRD&&B->kind==K_BIRD) continue;
      float ra=A->shape==SH_BOX?sqrtf(A->hw*A->hw+A->hh*A->hh):A->r, rb=B->shape==SH_BOX?sqrtf(B->hw*B->hw+B->hh*B->hh):B->r;
      if(pass==0){ float dx=A->x-B->x,dy=A->y-B->y; if(dx*dx+dy*dy>(ra+rb+4)*(ra+rb+4)) continue; } else { if(A->y-ra>6) continue; }
      Ct c[2]; int cn; if(pass==1){ cn=collide(&ground,A,c); /* ground is body "a" */ } else cn=collide(A,B,c); if(!cn) continue; if(narb>=1500) continue;
      Arb*r=&arb[narb++]; r->a=pass==0?i:-1; r->b=pass==0?jj:i; r->n=cn; for(int k=0;k<cn;k++){ r->c[k]=c[k]; r->c[k].Pn=r->c[k].Pt=0; }
      for(int o=0;o<narbOld;o++) if(arbOld[o].a==r->a&&arbOld[o].b==r->b) for(int k=0;k<cn;k++) for(int m=0;m<arbOld[o].n;m++) if(arbOld[o].c[m].id==r->c[k].id){ r->c[k].Pn=arbOld[o].c[m].Pn; r->c[k].Pt=arbOld[o].c[m].Pt; }
      A->hit=1; B->hit=1; } }
  /* pre-step */
  for(int a=0;a<narb;a++){ Arb*r=&arb[a]; Body*A=r->a<0?&ground:&w->b[r->a],*B=&w->b[r->b]; for(int k=0;k<r->n;k++){ Ct*c=&r->c[k];
      c->r1=v2(c->p.x-A->x,c->p.y-A->y); c->r2=v2(c->p.x-B->x,c->p.y-B->y); V2 n=c->n; float rn1=dot(c->r1,n),rn2=dot(c->r2,n);
      float kn=A->invm+B->invm+A->invI*(dot(c->r1,c->r1)-rn1*rn1)+B->invI*(dot(c->r2,c->r2)-rn2*rn2); c->mN=1/kn;
      V2 tg=v2(n.y,-n.x); float rt1=dot(c->r1,tg),rt2=dot(c->r2,tg); float kt=A->invm+B->invm+A->invI*(dot(c->r1,c->r1)-rt1*rt1)+B->invI*(dot(c->r2,c->r2)-rt2*rt2); c->mT=1/kt;
      float s=c->sep+2.0f; c->bias=-0.12f/h*(s<0?s:0); if(c->bias>240) c->bias=240;
      V2 dv=v2(B->vx-B->w*c->r2.y-A->vx+A->w*c->r1.y, B->vy+B->w*c->r2.x-A->vy-A->w*c->r1.x); float vn=dot(dv,n);
      if(vn<-260 && !(c->Pn>0)){ /* impact */
        float ma=A->invm>0?1/A->invm:1e9f,mb=B->invm>0?1/B->invm:1e9f; float em=(ma*mb)/(ma+mb); float d=(-vn-260)*em*0.5f;
        if(r->a>=0&&A->kind!=K_BIRD) dq[r->a]+=d*(B->kind==K_BIRD?1.f:0.8f); if(B->kind!=K_BIRD) dq[r->b]+=d*(A->kind==K_BIRD?1.f:0.8f);
        if(w->sndcool<=0&&-vn>350){ w->sndcool=0.05f; Body*s2=(B->kind==K_BIRD)?(r->a>=0?A:B):B; if(B->kind==K_BIRD||A->kind==K_BIRD) Q(w,A_BIRD_HIT);
          else Q(w,s2->kind==K_PIG?A_PIG_HIT:s2->mat==M_WOOD?A_WOOD_HIT:s2->mat==M_ICE?A_ICE_HIT:A_STONE_HIT); } }
      V2 P=v2(c->Pn*n.x+c->Pt*tg.x,c->Pn*n.y+c->Pt*tg.y);
      A->vx-=A->invm*P.x; A->vy-=A->invm*P.y; A->w-=A->invI*crs(c->r1,P); B->vx+=B->invm*P.x; B->vy+=B->invm*P.y; B->w+=B->invI*crs(c->r2,P); } }
  for(int it=0;it<18;it++) for(int a=0;a<narb;a++){ Arb*r=&arb[a]; Body*A=r->a<0?&ground:&w->b[r->a],*B=&w->b[r->b]; float fr=sqrtf(A->fric*B->fric);
    for(int k=0;k<r->n;k++){ Ct*c=&r->c[k]; V2 n=c->n; V2 dv=v2(B->vx-B->w*c->r2.y-A->vx+A->w*c->r1.y, B->vy+B->w*c->r2.x-A->vy-A->w*c->r1.x);
      float vn=dot(dv,n); float dPn=c->mN*(-vn+c->bias); float Pn0=c->Pn; c->Pn=Pn0+dPn; if(c->Pn<0)c->Pn=0; dPn=c->Pn-Pn0;
      V2 P=v2(dPn*n.x,dPn*n.y); A->vx-=A->invm*P.x; A->vy-=A->invm*P.y; A->w-=A->invI*crs(c->r1,P); B->vx+=B->invm*P.x; B->vy+=B->invm*P.y; B->w+=B->invI*crs(c->r2,P);
      dv=v2(B->vx-B->w*c->r2.y-A->vx+A->w*c->r1.y, B->vy+B->w*c->r2.x-A->vy-A->w*c->r1.x); V2 tg=v2(n.y,-n.x); float vt=dot(dv,tg); float dPt=-c->mT*vt; float mx=fr*c->Pn; float Pt0=c->Pt; c->Pt=Pt0+dPt; if(c->Pt<-mx)c->Pt=-mx; if(c->Pt>mx)c->Pt=mx; dPt=c->Pt-Pt0;
      P=v2(dPt*tg.x,dPt*tg.y); A->vx-=A->invm*P.x; A->vy-=A->invm*P.y; A->w-=A->invI*crs(c->r1,P); B->vx+=B->invm*P.x; B->vy+=B->invm*P.y; B->w+=B->invI*crs(c->r2,P); } }
  for(int i=0;i<n;i++){ Body*b=&w->b[i]; if(!b->alive||b->invm==0) continue; if(b->hit&&b->kind!=K_BIRD&&fabsf(b->vx)+fabsf(b->vy)<26&&fabsf(b->w)<0.6f){ b->vx*=0.5f; b->vy*=0.5f; b->w*=0.5f; if(fabsf(b->vx)+fabsf(b->vy)<4&&fabsf(b->w)<0.08f){b->vx=b->vy=b->w=0;} } b->x+=b->vx*h; b->y+=b->vy*h; b->rot+=b->w*h; }
  /* damage */
  for(int i=0;i<w->nb;i++){ Body*b=&w->b[i]; if(!b->alive||b->kind==K_BIRD||b->kind==K_GROUND) continue; if(dq[i]>0){ float before=b->hp/b->hp0; b->hp-=dq[i]; if(b->hp<=0) destroy(w,i); else if(before>0.4f&&b->hp/b->hp0<=0.4f&&w->sndcool<=0.03f) Q(w,b->kind==K_PIG?A_PIG_DMG:A_WOOD_DMG); } }
  for(int i=0;i<w->nb;i++){ Body*b=&w->b[i]; if(!b->alive) continue; if(b->y<-400||b->x<-900||b->x>5000){ if(b->kind==K_PIG) destroy(w,i); else b->alive=0; }
    if(b->kind==K_EGG&&b->hit&&b->age>10){ destroy(w,i); } }
}
/* ---------------- public ---------------- */
void screen_to_world(const World*w,float sx,float sy,float*wx,float*wy){ *wx=sx/w->cam.zoom+w->cam.camx; *wy=(372-sy)/w->cam.zoom; }
void world_to_screen(const World*w,float x,float y,float*sx,float*sy){ *sx=(x-w->cam.camx)*w->cam.zoom; *sy=372-y*w->cam.zoom; }
static int launch_birds(World*w){ return w->bird_i<w->nbirds; }
void world_step(World*w,float dt){
  if(dt<=0) return; w->nsnd=0; if(w->sndcool>0) w->sndcool-=dt; w->t+=dt;
  float hmax=1.f/120; int n=(int)ceilf(dt/hmax); if(n<1)n=1; if(n>4)n=4; for(int s=0;s<n;s++){ for(int i=0;i<w->nb;i++) w->b[i].hit=0; step(w,dt/n); }
  for(int i=0;i<MAXFX;i++){ Fx*f=&w->fx[i]; if(f->life<=0) continue; f->life-=dt; f->x+=f->vx*dt; f->y+=f->vy*dt; f->vy-=(f->text?0:900)*dt; f->rot+=f->vr*dt; }
  /* black bird fuse, egg etc */
  for(int i=0;i<w->nb;i++){ Body*b=&w->b[i]; if(!b->alive||b->kind!=K_BIRD) continue; if(b->btype==BD_BLACK){ if(b->fuse>0){ b->fuse-=dt; if(b->fuse<=0){ b->alive=0; explode(w,b->x,b->y,260,1500,200); } } else if(b->hit&&b->age>20) b->fuse=1.0f; } }
  /* settle detection */
  float mv=0; for(int i=0;i<w->nb;i++){ Body*b=&w->b[i]; if(!b->alive||b->invm==0) continue; float s=fabsf(b->vx)+fabsf(b->vy)+fabsf(b->w)*20; if(s>mv) mv=s; }
  if(mv<14) w->still+=dt; else w->still=0;
  int flying=0; for(int i=0;i<w->nb;i++) if(w->b[i].alive&&w->b[i].kind==K_BIRD) flying=1;
  if(w->ps==PS_WON||w->ps==PS_LOST) w->endtimer+=dt;
  if(w->ps==PS_FLY||w->ps==PS_WAIT){ w->endtimer+=dt;
    if(w->ps==PS_FLY && (!flying || w->endtimer>7 || (w->still>0.8f&&w->endtimer>1.5f))){ w->ps=PS_WAIT; w->endtimer=0; }
    if(w->ps==PS_WAIT && (w->still>0.9f||w->endtimer>5)){
      for(int i=0;i<w->nb;i++) if(w->b[i].alive&&w->b[i].kind==K_BIRD) w->b[i].alive=0;
      if(w->pigs<=0){ w->score+=10000*(w->nbirds-w->bird_i); w->ps=PS_WON; w->endtimer=0; w->stars=1+(w->score>=w->maxscore*0.45f)+(w->score>=w->maxscore*0.65f); Q(w,A_WIN); }
      else if(launch_birds(w)){ w->ps=PS_AIM; w->dragging=0; w->pull_x=w->pull_y=0; }
      else { w->ps=PS_LOST; w->endtimer=0; Q(w,A_LOSE); } } }
  if((w->ps==PS_FLY||w->ps==PS_WAIT)&&w->pigs<=0&&w->endtimer>1.2f&&w->still>0.5f&&w->ps!=PS_WON){ w->endtimer=5; }
}
#define SLX 0.f
#define SLY 118.f
static void ability(World*w){ if(w->ability_used||w->cur<0) return; Body*b=&w->b[w->cur]; if(!b->alive||b->kind!=K_BIRD) return; w->ability_used=1;
  float sp=sqrtf(b->vx*b->vx+b->vy*b->vy); float ang=atan2f(b->vy,b->vx);
  switch(b->btype){
   case BD_BLUE: for(int k=-1;k<=1;k+=2){ Body*c=bird(w,BD_BLUE,b->x,b->y+k*8,cosf(ang+k*0.22f)*sp,sinf(ang+k*0.22f)*sp); if(c) c->age=5; } Q(w,A_SUPER); break;
   case BD_YELLOW: b->vx*=2.3f; b->vy*=2.0f; Q(w,A_SUPER); break;
   case BD_BLACK: b->fuse=0.01f; break;
   case BD_WHITE: { Body*e=newbody(w); if(e){ e->kind=K_EGG; e->shape=SH_CIRCLE; e->r=SPR[S_C_EGG].ow*0.4f; e->x=b->x; e->y=b->y-30; e->vx=b->vx*0.5f; e->vy=-500; e->spr[0]=e->spr[1]=e->spr[2]=S_C_EGG; e->hp=e->hp0=1e9f; setmass(e,2.5f); }
      b->vy=700; b->vx*=1.15f; Q(w,A_SUPER); } break;
   default: break; } }
void world_control(World*w,const Pad*p,float cx,float cy,int alt,float dt){
  Cam*c=&w->cam; float wx,wy; screen_to_world(w,cx,cy,&wx,&wy);
  /* zoom: right stick up/down */
  float oldz=c->zoom; c->zoom-=p->ry*0.7f*dt; if(c->zoom<0.34f)c->zoom=0.34f; if(c->zoom>0.95f)c->zoom=0.95f; if(c->zoom!=oldz) c->camx+=320/oldz-320/c->zoom;
  float restx=SLX,resty=SLY+25;
  if(w->ps==PS_AIM){
    if(p->pressed){ float dx=wx-restx,dy=wy-resty; if(alt|| dx*dx+dy*dy<110*110){ w->dragging=1; Q(w,A_STRETCH); } }
    if(w->dragging){ float px,py;
      if(alt){ px=p->lx*115; py=-p->ly*115; } else { px=wx-restx; py=wy-resty; }
      float l=sqrtf(px*px+py*py); if(l>115){ px*=115/l; py*=115/l; } w->pull_x=px; w->pull_y=py;
      if(p->released){ w->dragging=0; if(l>28 && launch_birds(w)){ int t=w->birds[w->bird_i++]; Body*b=bird(w,t,restx+px,resty+py,-px*LAUNCH_K,-py*LAUNCH_K); if(b){ w->cur=(int)(b-w->b); w->ps=PS_FLY; w->endtimer=0; w->ability_used=0; w->still=0; Q(w,A_LAUNCH); if(t==BD_RED||t==BD_BIG) Q(w,A_RED_YELL); } w->pull_x=w->pull_y=0; }
        else { w->pull_x=w->pull_y=0; } } }
    else { /* pan with cursor at the edges */
      if(cx<24) c->camx-=500*dt/c->zoom*0.6f; if(cx>616) c->camx+=500*dt/c->zoom*0.6f; }
  } else if(w->ps==PS_FLY){ if(p->pressed) ability(w); }
  /* camera follow */
  float target=c->camx;
  if(w->ps==PS_FLY||w->ps==PS_WAIT){ float bx=-1e9f; for(int i=0;i<w->nb;i++) if(w->b[i].alive&&w->b[i].kind==K_BIRD&&w->b[i].x>bx) bx=w->b[i].x; if(bx>-1e8f) target=bx-250/c->zoom; c->camx+=(target-c->camx)*(4*dt>1.f?1.f:4*dt); }
  else if(w->ps==PS_AIM&&!w->dragging&&w->t<0.01f) c->camx=-120/c->zoom;
  if(c->camx<-300/c->zoom) c->camx=-300/c->zoom; if(c->camx>2400-640/c->zoom) c->camx=2400-640/c->zoom; }
/* ---------------- levels (Tutorial episode, 15 levels; layouts reconstructed from the walkthrough video) ---------------- */
const int NLEVELS=15;
#define POSTH 85.f
#define BEAMT 22.f
static void house(World*w,float x,int floors,int mp,int mb,int pigmask,int toppig){
  for(int f=0;f<floors;f++){ float yb=f*(POSTH+BEAMT); blk(w,KL_SHORT,mp,x-72,yb,1); blk(w,KL_SHORT,mp,x+72,yb,1); blk(w,KL_MED,mb,x,yb+POSTH,0); if(pigmask&(1<<f)) pig(w,x,yb); }
  if(toppig) pig(w,x,floors*(POSTH+BEAMT)); }
static const int LB[15][6]={ {BD_RED,BD_RED,BD_RED,-1},{BD_RED,BD_RED,BD_RED,BD_RED,-1},{BD_RED,BD_RED,BD_BLUE,-1},{BD_YELLOW,BD_YELLOW,BD_YELLOW,-1},{BD_BLUE,BD_BLUE,BD_BLUE,BD_RED,-1},
 {BD_BLACK,BD_BLACK,BD_RED,-1},{BD_WHITE,BD_WHITE,BD_RED,BD_YELLOW,-1},{BD_RED,BD_YELLOW,BD_BLUE,BD_BLACK,-1},{BD_YELLOW,BD_YELLOW,BD_BLACK,BD_RED,BD_BLUE,-1},{BD_BIG,BD_RED,BD_YELLOW,BD_BLUE,-1},
 {BD_BLACK,BD_WHITE,BD_YELLOW,BD_BLUE,BD_RED,-1},{BD_BIG,BD_BLACK,BD_YELLOW,BD_WHITE,BD_BLUE,-1},{BD_RED,BD_YELLOW,BD_BLUE,BD_BLACK,BD_WHITE,-1},{BD_BIG,BD_BIG,BD_BLACK,BD_YELLOW,BD_BLUE,BD_WHITE},{BD_BLACK,BD_BLACK,BD_YELLOW,BD_BIG,BD_WHITE,BD_BLUE} };
int level_birds(int lv,int*out){ int n=0; for(int i=0;i<6&&LB[lv][i]>=0;i++) out[n++]=LB[lv][i]; return n; }
void world_load(World*w,int lv){
  memset(w,0,sizeof*w); w->level=lv; w->rng=1234u+lv*77; w->cam.zoom=0.6f; w->cam.camx=-120/0.6f; w->ps=PS_AIM; w->cur=-1; w->slingx=SLX; w->slingy=SLY;
  w->nbirds=level_birds(lv,w->birds);
  switch(lv){
   case 0: house(w,1000,1,M_WOOD,M_WOOD,0,1); blk(w,KL_SSQ,M_ICE,1000,0,0); break;
   case 1: for(int k=0;k<3;k++) blk(w,KL_BLK,M_STONE,900,k*POSTH,1); pig(w,900,3*POSTH); house(w,1120,1,M_WOOD,M_WOOD,0,1); break;
   case 2: house(w,1000,2,M_WOOD,M_WOOD,1,1); blk(w,KL_SSQ,M_ICE,1160,0,0); blk(w,KL_SSQ,M_ICE,1160,43,0); break;
   case 3: house(w,950,2,M_ICE,M_ICE,1,1); house(w,1200,1,M_ICE,M_WOOD,0,1); break;
   case 4: house(w,900,1,M_WOOD,M_STONE,1,0); house(w,1150,2,M_ICE,M_WOOD,0,1); tnt(w,1330,0); break;
   case 5: blk(w,KL_LONG,M_STONE,950,0,0); house(w,950,2,M_STONE,M_STONE,0,1); house(w,1230,1,M_WOOD,M_WOOD,1,1); break;
   case 6: house(w,950,2,M_WOOD,M_ICE,1,1); house(w,1220,2,M_ICE,M_WOOD,0,1); blk(w,KL_CIRC,M_STONE,1380,0,0); break;
   case 7: house(w,900,2,M_WOOD,M_WOOD,3,1); tnt(w,1060,0); house(w,1240,2,M_ICE,M_STONE,1,1); break;
   case 8: house(w,900,3,M_WOOD,M_WOOD,1,1); house(w,1180,2,M_STONE,M_STONE,2,1); blk(w,KL_SSQ,M_ICE,1340,0,0); break;
   case 9: house(w,880,2,M_STONE,M_WOOD,3,1); house(w,1160,3,M_WOOD,M_ICE,1,1); tnt(w,1330,0); break;
   case 10: house(w,860,3,M_ICE,M_ICE,3,1); house(w,1140,3,M_WOOD,M_STONE,1,1); tnt(w,1310,0); blk(w,KL_CIRC,M_WOOD,1360,0,0); break;
   case 11: house(w,850,3,M_STONE,M_STONE,3,1); house(w,1130,2,M_WOOD,M_WOOD,3,1); house(w,1360,1,M_ICE,M_ICE,0,1); break;
   case 12: house(w,860,3,M_WOOD,M_ICE,5,1); tnt(w,1020,0); house(w,1180,3,M_STONE,M_WOOD,1,1); break;
   case 13: house(w,840,3,M_STONE,M_ICE,7,1); house(w,1100,3,M_WOOD,M_STONE,3,1); house(w,1360,2,M_ICE,M_WOOD,1,1); tnt(w,1520,0); break;
   default: house(w,830,3,M_STONE,M_STONE,7,1); house(w,1090,3,M_WOOD,M_ICE,7,1); house(w,1350,3,M_STONE,M_WOOD,5,1); tnt(w,1530,0); blk(w,KL_CIRC,M_STONE,1590,0,0); break; }
  w->pigs0=w->pigs; int tot=0; for(int i=0;i<w->nb;i++){ Body*b=&w->b[i]; if(b->kind==K_BLOCK) tot+=PTS[b->mat]; else if(b->kind==K_PIG) tot+=5000; else if(b->kind==K_TNT) tot+=1000; }
  w->maxscore=tot+10000*(w->nbirds>1?w->nbirds-1:0);
  for(int s=0;s<60;s++) step(w,1.f/120); for(int i=0;i<w->nb;i++){ w->b[i].vx=w->b[i].vy=w->b[i].w=0; w->b[i].age=0; } w->score=0; w->nsnd=0; w->still=0; }
