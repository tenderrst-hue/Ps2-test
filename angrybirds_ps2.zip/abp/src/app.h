#ifndef APP_H
#define APP_H
#include "game.h"
typedef enum { SC_SPLASH, SC_MENU, SC_EPISODES, SC_LEVELS, SC_PLAY, SC_SETTINGS, SC_CREDITS } Screen;
typedef struct { Screen sc; float t; float cx,cy; int music_on, mountains_on, ctrl_alt; int stars[15]; int sel_level; int paused; World w; int music_cur;
  float credit_y; int credit_run; int snd_out[16], nsnd_out, want_music; int clicked; } App;
void app_init(App*a); void app_update(App*a,const Pad*p,float dt); void app_draw(App*a);
#endif
