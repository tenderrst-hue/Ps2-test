#include "game.h"
#include <stdio.h>
#include <math.h>
static int alive(World*w,int k){ int n=0; for(int i=0;i<w->nb;i++) if(w->b[i].alive&&w->b[i].kind==k) n++; return n; }
int main(void){
  int ok=1;
  for(int lv=0;lv<NLEVELS;lv++){ World*w=&(World){0}; static World W; w=&W; world_load(w,lv); float x0[MAXB],y0[MAXB]; for(int i=0;i<w->nb;i++){x0[i]=w->b[i].x;y0[i]=w->b[i].y;}
    int blocks=alive(w,K_BLOCK),pigs=w->pigs; for(int s=0;s<60*6;s++) world_step(w,1.f/60);
    float md=0; int lost=0; for(int i=0;i<w->nb;i++){ if(!w->b[i].alive){lost++;continue;} float d=fabsf(w->b[i].x-x0[i])+fabsf(w->b[i].y-y0[i]); if(d>md)md=d; }
    printf("L%02d blocks=%d pigs=%d -> after 6s idle: lost=%d maxdrift=%.1f score=%d\n",lv+1,blocks,pigs,lost,md,w->score); if(lost||md>12) ok=0; }
  /* reachability: sweep pull vectors and see best result on each level with 1st bird */
  for(int lv=0;lv<NLEVELS;lv++){ int best=0,bp=0; float ba=0,bl=0;
    for(int ang=5;ang<=70;ang+=5) for(int pl=60;pl<=115;pl+=11){ static World W; World*w=&W; world_load(w,lv); Pad p={0}; float a=ang*3.14159f/180;
      p.pressed=1; w->dragging=0; /* drag with alt scheme */
      p.lx=-cosf(a)*pl/115.f; p.ly=sinf(a)*pl/115.f; world_control(w,&p,0,0,1,1/60.f); p.pressed=0; p.released=1; world_control(w,&p,0,0,1,1/60.f); p.released=0;
      for(int s=0;s<60*14&&w->ps!=PS_AIM&&w->ps!=PS_WON&&w->ps!=PS_LOST;s++){ world_step(w,1.f/60); world_control(w,&p,0,0,1,1/60.f); }
      int killed=w->pigs0-w->pigs; if(killed>best||(killed==best&&w->score>bp)){best=killed;bp=w->score;ba=ang;bl=pl;} }
    printf("L%02d best single shot: pigs killed %d/%d score %d (angle %.0f pull %.0f)\n",lv+1,best,0,bp,ba,bl); }
  puts(ok?"IDLE STABILITY OK":"IDLE STABILITY FAIL"); return ok?0:1; }
