#ifndef GFX_PS2_H
#define GFX_PS2_H
void gfx_ps2_init(void); int gfx_ps2_is_pal(void);
#endif
