#ifndef AUDIO_H
#define AUDIO_H
void audio_init(void); void audio_sfx(int id); void audio_music(int id); void audio_update(void);
#endif
