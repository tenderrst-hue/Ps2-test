#ifndef GFX_H
#define GFX_H
#define RGBA(r,g,b,a) (((unsigned)(r)<<24)|((unsigned)(g)<<16)|((unsigned)(b)<<8)|(unsigned)(a))
void gfx_begin(void); void gfx_end(void);
void gfx_spr(int spr,float cx,float cy,float w,float h,float rot,unsigned rgba);   /* centre + size in screen px (640x448) */
void gfx_rect(float x0,float y0,float x1,float y1,unsigned rgba);
void gfx_tri(float x0,float y0,float x1,float y1,float x2,float y2,unsigned rgba);
#endif
