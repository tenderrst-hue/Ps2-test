#ifndef GAME_H
#define GAME_H
#include "assets.h"
#define MAXB 160
#define LV_GRAV 1800.f
#define LAUNCH_K 16.f
#define MAXFX 96
typedef struct { float x,y; } V2;
enum { SH_BOX, SH_CIRCLE };
enum { K_BLOCK, K_PIG, K_BIRD, K_GROUND, K_TNT, K_EGG };
enum { M_WOOD, M_ICE, M_STONE };
enum { BD_RED, BD_BLUE, BD_YELLOW, BD_BLACK, BD_WHITE, BD_BIG };
typedef struct {
  float x,y,rot,vx,vy,w, hw,hh,r, invm,invI, fric, hp,hp0;
  int shape,kind,mat,alive,spr[3],btype,used,flying,age,hit,grp; float srot,fuse;
} Body;
typedef struct { int spr; float x,y,vx,vy,rot,vr,life,max,sc; int a0; int text; } Fx;
typedef enum { PS_AIM, PS_FLY, PS_WAIT, PS_WON, PS_LOST } PState;
typedef struct { float zoom, camx, camy; } Cam;
typedef struct {
  Body b[MAXB]; int nb; Fx fx[MAXFX];
  int birds[8], nbirds, bird_i; int cur; PState ps; float t, settle; int score, pigs, pigs0, level, stars, maxscore;
  float pull_x, pull_y; int dragging; float slingx, slingy; Cam cam; float camtx;
  int snd[16], nsnd; unsigned rng; float endtimer; int ability_used, nfly, hasdone; float sndcool, still; float panx;
} World;
typedef struct { float lx,ly,rx,ry; int down, pressed, released, start, up, dn, lf, rt; } Pad;
extern const int NLEVELS;
void world_load(World*w,int level);
void world_step(World*w,float dt);
void world_control(World*w,const Pad*p,float cx,float cy,int alt,float dt);  /* cx,cy: cursor in screen px */
void screen_to_world(const World*w,float sx,float sy,float*wx,float*wy);
void world_to_screen(const World*w,float x,float y,float*sx,float*sy);
int  level_birds(int level,int*out);
extern int snd_queue[16];
#endif
