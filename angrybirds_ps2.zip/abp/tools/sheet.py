import sys,glob,os
from PIL import Image,ImageDraw
def contact(d,out,cell=96,cols=12,bg=(150,200,235)):
    fs=sorted(glob.glob(d+'/*.png')); rows=(len(fs)+cols-1)//cols
    S=Image.new('RGB',(cols*cell,rows*cell),bg); dr=ImageDraw.Draw(S)
    for i,f in enumerate(fs):
        im=Image.open(f).convert('RGBA'); s=min((cell-6)/im.width,(cell-6)/im.height,1.0)
        im=im.resize((max(1,int(im.width*s)),max(1,int(im.height*s))),Image.LANCZOS)
        x,y=(i%cols)*cell,(i//cols)*cell; S.paste(im,(x+3,y+3),im); dr.text((x+2,y+2),str(i),fill=(255,0,0))
    S.save(out); return S.size
if __name__=='__main__': print(contact(sys.argv[1],sys.argv[2],int(sys.argv[3]) if len(sys.argv)>3 else 96,int(sys.argv[4]) if len(sys.argv)>4 else 12))
