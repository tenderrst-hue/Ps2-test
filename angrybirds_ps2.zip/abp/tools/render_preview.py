#!/usr/bin/env python3
"""Renders the host draw list with the exact PS2 atlases (quantized, downscaled) to PNG frames."""
import sys, json, math, re
from PIL import Image, ImageDraw
import numpy as np
P=sys.argv[1]; frames_txt=sys.argv[2]; outdir=sys.argv[3]
d=json.load(open(P+'/data/sprites.json')); tab=d['table']
AN=['blk','chr','ui','bg','spl','fnt']; at=[Image.open(f'{P}/data/prev_{a}.png').convert('RGBA') for a in AN]
cache={}
def sprite(i):
    if i not in cache:
        n,a,x,y,w,h,ow,oh=tab[i]; cache[i]=at[a].crop((x,y,x+w,y+h))
    return cache[i]
frames=[];cur=None;name=None
for ln in open(frames_txt):
    if ln.startswith('N '): name=ln.split()[1]
    elif ln.startswith('F'):
        cur=[];frames.append([None,cur])
    elif cur is not None: cur.append(ln.split())
    if ln.startswith('N ') and frames is not None: pending=name
# frame names: 'N' precedes the F of its draw
names=[];fl=[]
cur=None;pend=None
for ln in open(frames_txt):
    if ln.startswith('N '): pend=ln.split()[1]
    elif ln.startswith('F'): cur=[]; fl.append((pend,cur)); pend=None
    elif cur is not None: cur.append(ln.split())
def col(h): v=int(h,16); return ((v>>24)&255,(v>>16)&255,(v>>8)&255,v&255)
def render(cmds):
    S=2; cv=Image.new('RGBA',(640*S,448*S),(0,0,0,255))
    for c in cmds:
        if c[0]=='R':
            x0,y0,x1,y1=[float(v)*S for v in c[1:5]]; r,g,b,a=col(c[5]); ov=Image.new('RGBA',(max(1,int(x1-x0)),max(1,int(y1-y0))),(r,g,b,a))
            if x1>x0 and y1>y0: cv.alpha_composite(ov,(int(x0),int(y0))) if a==255 else cv.paste(Image.alpha_composite(cv.crop((int(x0),int(y0),int(x0)+ov.width,int(y0)+ov.height)),ov),(int(x0),int(y0)))
        elif c[0]=='T':
            p=[float(v)*S for v in c[1:7]]; r,g,b,a=col(c[7]); ov=Image.new('RGBA',cv.size,(0,0,0,0)); ImageDraw.Draw(ov).polygon([(p[0],p[1]),(p[2],p[3]),(p[4],p[5])],fill=(r,g,b,a)); cv.alpha_composite(ov)
        elif c[0]=='S':
            i=int(c[1]); cx,cy,w,h,rot=[float(v) for v in c[2:7]]; r,g,b,a=col(c[7]); w*=S;h*=S;cx*=S;cy*=S
            if w<1 or h<1: continue
            im=sprite(i).resize((max(1,int(round(w))),max(1,int(round(h)))),Image.LANCZOS)
            if (r,g,b,a)!=(255,255,255,255):
                arr=np.asarray(im).astype(float); arr[...,0]*=r/255; arr[...,1]*=g/255; arr[...,2]*=b/255; arr[...,3]*=a/255; im=Image.fromarray(arr.astype(np.uint8),'RGBA')
            if abs(rot)>1e-3: im=im.rotate(-math.degrees(rot),resample=Image.BICUBIC,expand=True)
            cv.alpha_composite(im,(int(round(cx-im.width/2)),int(round(cy-im.height/2)))) if (cx-im.width/2>=0 and cy-im.height/2>=0 and cx+im.width/2<=cv.width and cy+im.height/2<=cv.height) else cv.paste(im,(int(round(cx-im.width/2)),int(round(cy-im.height/2))),im)
    return cv.resize((640,448),Image.LANCZOS).convert('RGB')
import os; os.makedirs(outdir,exist_ok=True)
for n,cmds in fl:
    render(cmds).save(f'{outdir}/{n}.png'); print('rendered',n,len(cmds))
