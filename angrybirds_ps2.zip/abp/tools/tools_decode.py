import lzma,struct,numpy as np
from PIL import Image
def un7z(path):
    d=open(path,'rb').read(); nho,nhs=struct.unpack('<QQ',d[12:28]); packed=d[32:32+nho]
    dec=lzma.LZMADecompressor(format=lzma.FORMAT_RAW,filters=[{'id':lzma.FILTER_LZMA1,'dict_size':0x1000000,'lc':3,'lp':0,'pb':2}])
    return dec.decompress(packed)
def rgba4444(buf,w,h):
    a=np.frombuffer(buf[:w*h*2],dtype='<u2').reshape(h,w)
    r=((a>>12)&15)*17; g=((a>>8)&15)*17; b=((a>>4)&15)*17; al=(a&15)*17
    return Image.fromarray(np.dstack([r,g,b,al]).astype(np.uint8),'RGBA')
def split_stream(o):
    sp=[];p=0
    while p+40<=len(o):
        L=int.from_bytes(o[p:p+4],'big')
        if L<40 or p+L>len(o)+1: break
        hs=int.from_bytes(o[p+4:p+6],'big'); w=int.from_bytes(o[p+6:p+8],'big'); h=int.from_bytes(o[p+8:p+10],'big')
        px=o[p+hs:p+hs+w*h*2]
        if len(px)<w*h*2 or w==0 or h==0: break
        sp.append(rgba4444(px,w,h)); p+=L
    return sp
def read_pvr(path):
    d=open(path,'rb').read(); h,w=struct.unpack('<II',d[24:32]); ms=struct.unpack('<I',d[48:52])[0]
    return rgba4444(d[52+ms:],w,h)
def slice_atlas(im,gap=4,minarea=60):
    import numpy as np
    from scipy import ndimage as ndi
    a=np.asarray(im)[...,3]>16
    lab,n=ndi.label(ndi.binary_dilation(a,iterations=gap))
    boxes=[]
    for sl in ndi.find_objects(lab):
        y0,y1,x0,x1=sl[0].start,sl[0].stop,sl[1].start,sl[1].stop
        if (y1-y0)*(x1-x0)>=minarea: boxes.append((x0,y0,x1,y1))
    boxes.sort(key=lambda b:(b[1]//40,b[0]))
    return boxes
