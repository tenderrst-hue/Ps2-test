#!/usr/bin/env python3
"""Builds PS2 assets from extracted Angry Birds sprites: smooth-downscaled 8-bit (T8+CLUT) atlases + mono 11 kHz audio.
usage: build_assets.py <work dir with out/spr, out/atl> <apk assets dir> <project dir>"""
import sys, os, struct, subprocess, glob, json
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
W, A, P = sys.argv[1], sys.argv[2], sys.argv[3]
S = lambda d,i: Image.open(f'{W}/out/spr/{d}/{i:03d}.png').convert('RGBA')
T = lambda d,i: Image.open(f'{W}/out/atl/{d}/{i:03d}.png').convert('RGBA')
spr = []   # (name, atlas, image, scale)
def add(name, atlas, im, sc=0.5): spr.append((name, atlas, im, sc))
# ---- blocks: kind -> material -> 3 damage states
K = {'LONG':{'W':[8,13,9],'I':[3,5,6],'S':[7,10,12]},'MED':{'W':[24,29,26],'I':[16,23,25],'S':[15,18,28]},
     'SHORT':{'W':[50,60,71],'I':[51,58,65],'S':[56,64,68]},'BLK':{'W':[53,61,66],'I':[52,59,70],'S':[49,57,69]},
     'SQ':{'W':[79,89,92],'I':[85,86,88],'S':[91,93,95]},'TRI':{'W':[75,77,84],'I':[72,73,76],'S':[80,81,83]},
     'SSQ':{'W':[178,180,183],'I':[167,171,174],'S':[165,168,170]},'CIRC':{'W':[120,122,123],'I':[124,125,126],'S':[116,117,119]}}
for k,m in K.items():
    for mt,ids in m.items():
        for n,i in enumerate(ids): add(f'B_{k}_{mt}{n}','blk',S('INGAME_BLOCKS_3_1',i))
add('TNT','blk',S('INGAME_BLOCKS_1_1',87))
# ---- characters
for nm,i in (('RED',91),('RED_HIT',93),('BLUE',56),('YELLOW',80),('BLACK',62),('WHITE',45),('BIG',40),('PIG',17),('PIG_HIT',22),('EGG',89),('PUFF',92),('FEATHER',101)):
    add('C_'+nm,'chr',S('INGAME_BIRDS_1',i))
add('C_PIG_HURT','chr',S('INGAME_PIGS_NEW_SHEET_0_1',54)); add('C_SLING_STEM','chr',S('INGAME_BIRDS_1',6)); add('C_SLING_ARM','chr',S('INGAME_BIRDS_1',21))
add('C_STAR','chr',T('menu1',16),0.35)
# ---- UI
add('U_LOGO','ui',T('menu1',0),0.72); add('U_STAR','ui',T('menu1',16),0.5); add('U_STAR_OFF','ui',T('menu1',27),0.5)
for nm,i in (('BACK',23),('PLAY',50),('RESTART',7),('LIST',17),('SOUND',26),('MOUNT',31),('INFO',49),('BLANK',45),('NEXT',10),('MENU',15),('PAD',36)):
    add('U_'+nm,'ui',T('buttons',i),0.45)
add('U_LOCK','ui',T('ls1',2),0.45); add('U_TILE','ui',T('ls1',21),0.4); add('U_TILE_G','ui',T('ls1',18),0.4)
add('U_EGG','ui',T('menu2',2),0.45); add('U_PIGFACE','ui',T('menu2',3),0.3)
cards=Image.open(f'{W}/out/atl/cards.png').convert('RGBA'); cw,ch=cards.width/7,cards.height/2
for n,(r,c) in enumerate([(1,0),(0,0),(0,1),(0,2),(0,3),(0,4),(0,5),(0,6)]):
    add(f'U_CARD{n}','ui',cards.crop((int(c*cw),int(r*ch),int((c+1)*cw),int((r+1)*ch))),0.33)
def gear(sz=160):
    im=Image.new('RGBA',(sz*4,sz*4),(0,0,0,0)); d=ImageDraw.Draw(im); c=sz*2; import math
    d.ellipse((c-c*0.97,c-c*0.97,c+c*0.97,c+c*0.97),fill=(250,160,20,255),outline=(255,255,255,255),width=14)
    pts=[]; n=8
    for k in range(n*4):
        a=2*math.pi*k/(n*4); r=c*(0.62 if (k//2)%2==0 else 0.46); pts.append((c+r*math.cos(a),c+r*math.sin(a)))
    d.polygon(pts,fill=(255,255,255,255)); d.ellipse((c-c*0.2,c-c*0.2,c+c*0.2,c+c*0.2),fill=(250,160,20,255))
    return im.resize((sz,sz),Image.LANCZOS)
add('U_GEAR','ui',gear(),0.5)
# ---- backgrounds
th=T('th1',0).crop((0,0,482,292)); add('BG_SKY','spl',th.resize((256,160),Image.LANCZOS),1.0)
par=Image.open(f'{W}/out/atl/par1.png').convert('RGBA')
def tint(im,rgb,a=1.0):
    r=np.asarray(im).astype(float); m=r[...,3:4]/255; o=np.zeros_like(r); o[...,:3]=np.array(rgb); o[...,3:4]=r[...,3:4]*a; return Image.fromarray(o.astype(np.uint8),'RGBA')
add('BG_HILLS','bg',tint(par.crop((0,0,484,46)),(112,168,128),1.0),0.5)
add('BG_GRASS_D','bg',par.crop((0,50,450,103)),0.5); add('BG_GRASS','bg',par.crop((0,121,336,146)),0.5)
add('BG_STUMP','bg',tint(par.crop((333,110,395,222)),(122,86,48),1.0),0.5)
add('SPLASH','spl',Image.open(f'{W}/out/atl/splash.png').convert('RGBA').resize((256,192),Image.LANCZOS),1.0)
# ---- font (original AngryBirdsText)
FONT=ImageFont.truetype(f'{A}/fonts/AngryBirdsText-Regular.ttf',44); GL={}
for ch in range(32,127):
    im=Image.new('RGBA',(64,64),(0,0,0,0)); d=ImageDraw.Draw(im); d.text((6,4),chr(ch),font=FONT,fill=(255,255,255,255),stroke_width=3,stroke_fill=(20,20,40,255))
    bb=im.getbbox(); adv=int(FONT.getlength(chr(ch)))
    if bb: add(f'F_{ch}','fnt',im.crop((bb[0],0,bb[2],64)),1.0)
    else: add(f'F_{ch}','fnt',Image.new('RGBA',(max(2,adv//2),4),(0,0,0,0)),1.0)
    GL[ch]=(bb[0] if bb else 0)
# ---- pack
atlas_ids={'blk':0,'chr':1,'ui':2,'bg':3,'spl':4,'fnt':5}
def pack(items,width):
    x=y=rowh=0; pos=[]
    for it in items:
        w,h=it.size; w+=2; h+=2
        if x+w>width: x=0; y+=rowh; rowh=0
        pos.append((x+1,y+1)); x+=w; rowh=max(rowh,h)
    H=1
    while H<y+rowh: H*=2
    return pos,H
table=[]; os.makedirs(P+'/data',exist_ok=True); prev={}
for an,aid in atlas_ids.items():
    items=[s for s in spr if s[1]==an]; ims=[]
    for name,_,im,sc in items:
        w=max(2,round(im.width*sc)); h=max(2,round(im.height*sc)); ims.append((im.resize((w,h),Image.LANCZOS),im.size))
    width={'blk':512,'chr':512,'ui':512,'bg':512,'spl':256,'fnt':512}[an]
    pos,H=pack([a for a,_ in ims],width); canvas=Image.new('RGBA',(width,H),(0,0,0,0))
    for (im,_),(x,y) in zip(ims,pos): canvas.paste(im,(x,y))
    q=canvas.quantize(colors=255,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.FLOYDSTEINBERG if an=='spl' else Image.Dither.NONE)
    pal=q.getpalette('RGBA')[:255*4]; idx=np.asarray(q).astype(np.uint8)
    pal=np.array(pal,dtype=np.uint8).reshape(-1,4); clut=np.zeros((256,4),np.uint8); clut[:len(pal)]=pal
    clut[:,3]=(clut[:,3].astype(int)*128//255).astype(np.uint8)      # GS alpha 0..0x80
    # transparent pixels -> index 255 (fully transparent entry)
    a=np.asarray(canvas)[...,3]; idx=np.where(a<8,255,idx).astype(np.uint8); clut[255]=(0,0,0,0)
    sw=np.arange(256); sw=(sw&0xE7)|((sw&0x08)<<1)|((sw&0x10)>>1); clut_sw=np.zeros_like(clut); clut_sw[sw]=clut   # CSM1 swizzle
    open(f'{P}/data/tex_{an}.bin','wb').write(clut_sw.tobytes()+idx.tobytes())
    # preview atlas as the PS2 will see it
    prev_img=np.zeros((H,width,4),np.uint8); full=clut.copy(); full[:,3]=(clut[:,3].astype(int)*255//128).clip(0,255); prev_img=full[idx]
    Image.fromarray(prev_img,'RGBA').save(f'{P}/data/prev_{an}.png')
    for (name,_,_,_),(im,osz),(x,y) in zip(items,ims,pos): table.append((name,aid,x,y,im.width,im.height,osz[0],osz[1]))
    print(an,width,H,len(items),'sprites',(width*H+1024)//1024,'KB')
names=[t[0] for t in table]
with open(P+'/src/assets.h','w') as f:
    f.write('/* generated by tools/build_assets.py */\n#ifndef ASSETS_H\n#define ASSETS_H\ntypedef struct { unsigned char atlas; unsigned short x,y,w,h; unsigned short ow,oh; } Spr;\n')
    f.write('enum {\n'+''.join(f' S_{n.replace("-","_")},\n' for n in names)+' S_COUNT };\nextern const Spr SPR[S_COUNT];\n')
    f.write('#define NATLAS 6\nextern const unsigned short ATLAS_W[NATLAS], ATLAS_H[NATLAS];\n#endif\n')
aw=[512,512,512,512,256,512]; ah={}
for t in table: pass
hs=[]; 
for an,aid in atlas_ids.items(): hs.append(Image.open(f'{P}/data/prev_{an}.png').height)
with open(P+'/src/assets.c','w') as f:
    f.write('#include "assets.h"\nconst Spr SPR[S_COUNT]={\n'+''.join('{%d,%d,%d,%d,%d,%d,%d},\n'%t[1:] for t in table)+'};\n')
    f.write('const unsigned short ATLAS_W[NATLAS]={%s}, ATLAS_H[NATLAS]={%s};\n'%(','.join(map(str,aw)),','.join(map(str,hs))))
json.dump({'names':names,'table':table},open(P+'/data/sprites.json','w'))
# ---- audio (mono 11025 Hz s16)
SF=A+'/data/audio/sfx/'; MU=A+'/data/audio/music/'
def pcm(path,maxsec=None):
    cmd=['ffmpeg','-v','error','-i',path,'-ac','1','-ar','11025']+(['-t',str(maxsec)] if maxsec else [])+['-f','s16le','-']
    return subprocess.run(cmd,capture_output=True,check=True).stdout
def first(pref): return sorted(f for f in os.listdir(SF) if f.startswith(pref))[0]
SFX=[('STRETCH','slingshot streched'),('LAUNCH','bird_06_flying'),('RED_YELL','redbird_yell01'),('WOOD_HIT','wood collision a1'),('WOOD_HIT2','wood collision a3'),
 ('WOOD_DMG','wood damage a1'),('WOOD_DIE','wood destroyed a1'),('ICE_HIT','ice light collision a1'),('ICE_HIT2','ice light collision a4'),('ICE_DIE','light destroyed a1'),
 ('STONE_HIT','rock collision a1'),('STONE_DIE','rock destroyed a1'),('PIG_HIT','piglette collision a1'),('PIG_DMG','piglette damage a1'),('PIG_DIE','piglette destroyed'),
 ('PIG_OINK','piglette oink a1'),('BIRD_HIT','bird 01 collision a1'),('BIRD_HIT2','bird 02 collision a1'),('TNT','tnt box explodes'),('STAR1','star_1'),('STAR2','star_2'),('STAR3','star_3'),
 ('WIN','level clear military a1'),('LOSE','level failed piglets a1'),('START','level start military a1'),('SEL','menu select'),('OK','menu confirm'),('BACK','menu back'),('SUPER','super_shot')]
blob=b''; atab=[]
for nm,pre in SFX:
    try: fn=first(pre)
    except IndexError: print('missing sfx',pre); atab.append((nm,len(blob)//2,0)); continue
    d=pcm(SF+fn,2.5); atab.append((nm,len(blob)//2,len(d)//2)); blob+=d
MUS=[('MUS_MENU','title_theme.ogg',68),('MUS_GAME','ambient_green_jungleish.ogg',68),('MUS_WIN','level_complete.ogg',4)]
for nm,fn,mx in MUS:
    d=pcm(MU+fn,mx); atab.append((nm,len(blob)//2,len(d)//2)); blob+=d
open(P+'/data/audio.bin','wb').write(blob)
with open(P+'/src/audio_tab.h','w') as f:
    f.write('#ifndef AUDIO_TAB_H\n#define AUDIO_TAB_H\ntypedef struct { unsigned int off, len; } Snd;\nenum {\n'+''.join(f' A_{n},\n' for n,_,_ in atab)+' A_COUNT };\nextern const Snd SND[A_COUNT];\n#endif\n')
open(P+'/src/audio_tab.c','w').write('#include "audio_tab.h"\nconst Snd SND[A_COUNT]={\n'+''.join('{%d,%d},\n'%(o,l) for _,o,l in atab)+'};\n')
print('audio',len(blob)/1e6,'MB', len(atab),'clips')
