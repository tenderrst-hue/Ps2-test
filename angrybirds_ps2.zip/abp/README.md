# Angry Birds - Tutorial episode - PlayStation 2 fan port (VPlayStation2FanPort / PlayStation2Port:VLaD)
Native EE homebrew (C, PS2SDK + gsKit + audsrv). 15 Tutorial levels, other episodes locked ("Coming Soon").
No ads, no shop, English only. Settings: Music on/off, Credits, Mountains on/off, Controls (Mouse / Stick).

## Controls
- Left stick (or D-pad): move the mouse cursor.   Right stick up/down: ZOOM camera.   X: click / interact.
- Slingshot (MOUSE scheme): put the cursor on the bird, HOLD X, move the cursor LEFT/DOWN to pull back, release X to fire.
- X while the bird flies: its special ability.  START: pause.
- Credits: X starts/stops the scroll, cursor on the back arrow + X exits.
- Settings > Controls > STICK: the left stick aims directly while X is held (for those who dislike the mouse).

## Build
docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest sh -c "apk add make && make"   -> ANGRYBIRDS.ELF
or push to GitHub: .github/workflows/build.yml builds it and uploads the ELF as an artifact.
Run in PCSX2 (System > Run ELF) or on real hardware (uLaunchELF / PS2Link / FreeMCBoot).

## Rebuild assets (needs the original APK, extracted with tools/tools_decode.py)
python3 tools/build_assets.py <work> <apk/assets> .      (sprites -> smooth 8-bit atlases, audio -> mono 11 kHz)
Host tests: gcc src/game.c src/assets.c src/audio_tab.c src/host_phys.c -lm  (physics stability), host_auto.c (autoplay all levels).

NOTE: all art/sound belong to Rovio Entertainment. Keep this repository private; do not redistribute the assets.
